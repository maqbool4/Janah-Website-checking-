import React, { useEffect, useState } from 'react';
import { dataStore } from '../lib/dataStore';
import { PortfolioProject } from '../lib/types';
import { ArrowRight, MessageCircle } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';
import { SEO } from '../components/SEO';

export default function Portfolio() {
  const navigate = useNavigate();
  const [projects, setProjects] = useState<PortfolioProject[]>(() => dataStore.getPortfolioSync().filter(p => p.is_active));

  useEffect(() => {
    dataStore.getPortfolio().then(res => setProjects(res.filter(p => p.is_active)));
  }, []);

  const whatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent("Hi Janah Studio, I'd like to discuss a custom portfolio project.")}`;

  return (
    <div className="space-y-16 pb-20 pt-8">
      <SEO
        title="Our Work & Case Studies | Janah Studio Web Projects"
        description="Browse recent client website projects, e-commerce stores, and high-converting landing pages built by Janah Studio."
        keywords="web design portfolio, client website examples, ecommerce portfolio, business website case studies, web development showcase"
        canonicalPath="/portfolio"
      />
      
      {/* Title Section */}
      <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] pt-2 pb-10 sm:pb-14 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30">
        <div className="relative z-10 max-w-3xl space-y-2">
          <AnimatedHeading
            text="Our Portfolio"
            as="h1"
            className="text-4xl sm:text-5xl font-extrabold text-[#17202A] tracking-tight leading-tight"
          />
          <div className="w-36 h-3 mt-1 mb-2">
            <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
              <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <defs>
                <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#30E1CE" />
                  <stop offset="50%" stopColor="#1876C7" />
                  <stop offset="100%" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <AnimatedDescription
            text="Discover a curated collection of live client websites and demonstration projects crafted by Janah Studio. From modern business platforms and robust e-commerce stores to elegant portfolio websites, each build highlights our dedication to responsive layouts, fast load speeds, and intuitive user experiences."
            className="text-sm sm:text-base text-[#66727D] leading-relaxed"
            delay={0.2}
          />
        </div>
      </section>

      {/* Project Grid */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {projects.length === 0 ? (
            <div className="py-16 flex flex-col items-center justify-center space-y-3">
              <div className="w-8 h-8 rounded-full border-2 border-[#1876C7] border-t-transparent animate-spin" />
              <p className="text-sm text-[#66727D]">Loading projects...</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
              {projects.slice(0, 4).map((project, idx) => (
                <AnimatedSection key={project.id} direction={idx % 2 === 0 ? "left" : "right"} delay={idx * 0.06}>
                  <div 
                    className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 backdrop-blur-md rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none overflow-hidden border border-[#30E1CE]/30 shadow-lg hover:shadow-xl transition-all duration-300 group flex flex-col cursor-pointer hover:-translate-y-0.5 h-full"
                    onClick={() => project.project_url && project.project_url !== '#' && window.open(project.project_url, '_blank')}
                  >
                    <div className="relative aspect-[16/10] overflow-hidden bg-gray-100">
                      <img 
                        src={project.image_url} 
                        alt={project.project_name} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="eager"
                      />
                      <span className={`absolute top-2 left-2 px-2 py-0.5 rounded-full text-[9px] sm:text-[10px] font-bold shadow-xs ${project.project_type === 'Demo' ? 'bg-[#30E1CE] text-[#17202A]' : 'bg-[#1876C7] text-white'}`}>
                        {project.project_type === 'Demo' ? 'Demo' : 'Client Project'}
                      </span>
                    </div>
                    <div className="p-4 flex flex-col flex-grow space-y-2 text-left">
                      <span className="text-[10px] font-bold text-[#1876C7] uppercase tracking-wider block truncate">{project.category}</span>
                      <h3 className="text-sm font-bold text-[#17202A] leading-snug group-hover:text-[#1876C7] transition-colors truncate">{project.project_name}</h3>
                      <p className="text-xs text-[#66727D] leading-relaxed line-clamp-2">{project.short_description}</p>
                    </div>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          )}
        </section>
      </AnimatedSection>

      {/* Final CTA Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none pt-4 pb-10 sm:pb-14 px-8 sm:px-16 text-center space-y-3 shadow-2xl relative overflow-hidden border border-[#30E1CE]/30">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#30E1CE]/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <AnimatedHeading
            text="Have a Project in Mind?"
            as="h2"
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#17202A]"
          />
          <AnimatedDescription
            text="Let's bring your vision to life with a professional website or online store built around your goals."
            className="text-sm sm:text-base text-[#66727D] max-w-xl mx-auto leading-relaxed"
            delay={0.15}
          />

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <Button
              variant="primary"
              onClick={() => navigate('/contact')}
              className="px-6 shrink-0"
            >
              <span>Start Project</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>

            <Button
              variant="chat"
              onClick={() => window.open(whatsappUrl, '_blank')}
              className="px-6 shrink-0"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>
          </div>
        </div>
      </section>
      </AnimatedSection>

    </div>
  );
}
