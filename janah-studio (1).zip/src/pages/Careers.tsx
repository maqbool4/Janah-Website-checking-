import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Briefcase, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  Globe, 
  Sparkles, 
  Clock, 
  ShieldCheck, 
  Send, 
  RotateCcw, 
  Copy, 
  Check, 
  Users,
  X
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';
import { dataStore } from '../lib/dataStore';

interface FormState {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  position: string;
  experienceLevel: string;
  yearsExperience: string;
  workTypes: string[];
  skills: string[];
  leadSources: string[];
  customSkills: string;
  portfolioUrl: string;
  socialUrl: string;
  previousExperience: string;
  coverLetter: string;
  additionalMessage: string;
  expectedRate: string;
  bankName: string;
  termsAccepted: boolean;
}

const INITIAL_FORM: FormState = {
  fullName: '',
  email: '',
  phone: '',
  location: '',
  position: 'Lead Generation & Client Acquisition Partner',
  experienceLevel: 'Mid-Level (1-3 yrs)',
  yearsExperience: '2',
  workTypes: ['Remote', 'Project-based'],
  skills: ['Lead Generation', 'Client Outreach'],
  leadSources: ['Google Maps', 'Google Search'],
  customSkills: '',
  portfolioUrl: '',
  socialUrl: '',
  previousExperience: '',
  coverLetter: '',
  additionalMessage: '',
  expectedRate: '',
  bankName: '',
  termsAccepted: false
};

const OPPORTUNITY_CATEGORIES = [
  {
    id: 'lead-gen',
    title: 'Lead Generation & Client Acquisition Partner',
    department: 'Sales & Growth',
    badge: 'Open Role',
    description: 'Responsible for finding potential clients and, where appropriate, contacting them through suitable channels to help bring genuine website project enquiries to Janah Studio.'
  },
  {
    id: 'lead-research',
    title: 'Lead Research Partner',
    department: 'Research',
    badge: 'Open Role',
    description: 'Responsible for researching potential client businesses and submitting accurate, organized lead information. Janah Studio handles the outreach unless another arrangement is agreed.'
  },
  {
    id: 'web-dev',
    title: 'Web Development',
    department: 'Engineering',
    badge: 'Open Role',
    description: 'Build fast, responsive web applications and custom frontend interfaces with modern web standards.'
  },
  {
    id: 'wordpress-dev',
    title: 'WordPress Development',
    department: 'Engineering',
    badge: 'Open Role',
    description: 'Develop, customize, and optimize WordPress themes, plugins, and dynamic business websites.'
  },
  {
    id: 'ecommerce-dev',
    title: 'E-commerce Development',
    department: 'Solutions',
    badge: 'Open Role',
    description: 'Build and configure online stores on Shopify, WooCommerce, and tailored e-commerce platforms.'
  },
  {
    id: 'landing-page',
    title: 'Landing Page Development',
    department: 'Engineering',
    badge: 'Open Role',
    description: 'Create high-converting, lightning-fast promotional and marketing landing pages.'
  },
  {
    id: 'redesign-maintenance',
    title: 'Website Redesign & Maintenance',
    department: 'Solutions',
    badge: 'Open Role',
    description: 'Revamp outdated websites and provide ongoing performance improvements and maintenance.'
  },
  {
    id: 'ui-ux',
    title: 'UI/UX Design',
    department: 'Design',
    badge: 'Open Role',
    description: 'Design intuitive user interfaces, wireframes, and user experiences for web and mobile.'
  },
  {
    id: 'graphic-design',
    title: 'Graphic Design',
    department: 'Design',
    badge: 'Open Role',
    description: 'Create striking brand visuals, marketing banners, social assets, and promotional materials.'
  },
  {
    id: 'video-editing',
    title: 'Video Editing',
    department: 'Media',
    badge: 'Open Role',
    description: 'Edit engaging promotional videos, social clips, and commercial media content.'
  },
  {
    id: 'motion-graphics',
    title: 'Motion Graphics & Animation',
    department: 'Media',
    badge: 'Open Role',
    description: 'Produce dynamic animations, visual effects, and animated UI elements.'
  },
  {
    id: 'content-writing',
    title: 'Content Writing & Copywriting',
    department: 'Content',
    badge: 'Open Role',
    description: 'Write compelling website copy, blog posts, marketing texts, and professional documentation.'
  },
  {
    id: 'seo-marketing',
    title: 'SEO & Digital Marketing',
    department: 'Growth',
    badge: 'Open Role',
    description: 'Optimize search engine rankings, keyword strategies, and digital marketing campaigns.'
  },
  {
    id: 'social-media',
    title: 'Social Media Management',
    department: 'Growth',
    badge: 'Open Role',
    description: 'Manage social channels, schedule posts, engage audiences, and build brand presence.'
  },
  {
    id: 'virtual-assistance',
    title: 'Virtual Assistance & Data Entry',
    department: 'Operations',
    badge: 'Open Role',
    description: 'Provide dependable administrative support, data organization, and routine operations.'
  },
  {
    id: 'custom-services',
    title: 'Other Skills / Custom Services',
    department: 'Flexible',
    badge: 'Open Role',
    description: 'Offer specialized professional services or custom expertise matching Janah Studio projects.'
  }
];

const AVAILABLE_SKILLS = [
  'Lead Generation',
  'Web Research',
  'Google Maps Research',
  'Google Search Research',
  'Social Media Research',
  'Client Outreach',
  'Cold Email Outreach',
  'WhatsApp Outreach',
  'Sales & Negotiation',
  'Communication Skills',
  'Data Entry',
  'Web Development',
  'WordPress / PHP',
  'Shopify / E-commerce',
  'UI/UX Design (Figma)',
  'Graphic Design',
  'Video Editing',
  'Content Writing',
  'SEO & Marketing',
  'Other'
];

const LEAD_SOURCES = [
  'Google Maps',
  'Google Search',
  'Facebook',
  'Instagram',
  'TikTok',
  'Pinterest',
  'LinkedIn',
  'YouTube',
  'Local Business Research',
  'Other'
];

const WORK_TYPE_OPTIONS = [
  'Remote',
  'Part-time',
  'Contract',
  'Project-based',
  'Flexible Hours'
];

export default function Careers() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<FormState>(INITIAL_FORM);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [missingFieldsList, setMissingFieldsList] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStage, setSubmitStage] = useState<string>('');
  const [submissionResult, setSubmissionResult] = useState<{
    success: boolean;
    referenceId?: string;
    savedToGoogleSheets?: boolean;
    spreadsheetId?: string;
    message?: string;
  } | null>(null);
  const [copiedRef, setCopiedRef] = useState(false);
  const [showThankYouModal, setShowThankYouModal] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const isLeadRole = formData.position.toLowerCase().includes('lead');

  const handleRoleSelect = (roleTitle: string) => {
    setFormData(prev => ({ ...prev, position: roleTitle }));
    const formEl = document.getElementById('application-form');
    if (formEl) {
      formEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const toggleWorkType = (type: string) => {
    setFormData(prev => {
      const exists = prev.workTypes.includes(type);
      const updated = exists 
        ? prev.workTypes.filter(t => t !== type)
        : [...prev.workTypes, type];
      return { ...prev, workTypes: updated };
    });
    if (errors.workTypes) {
      setErrors(prev => ({ ...prev, workTypes: '' }));
    }
  };

  const toggleSkill = (skill: string) => {
    setFormData(prev => {
      const exists = prev.skills.includes(skill);
      const updated = exists 
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill];
      return { ...prev, skills: updated };
    });
    if (errors.skills) {
      setErrors(prev => ({ ...prev, skills: '' }));
    }
  };

  const toggleLeadSource = (source: string) => {
    setFormData(prev => {
      const exists = prev.leadSources.includes(source);
      const updated = exists 
        ? prev.leadSources.filter(s => s !== source)
        : [...prev.leadSources, source];
      return { ...prev, leadSources: updated };
    });
  };

  const validateForm = (): Record<string, string> => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim() || formData.fullName.trim().length < 2) {
      newErrors.fullName = 'Full Name is required (minimum 2 characters)';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim() || !emailRegex.test(formData.email.trim())) {
      newErrors.email = 'Please provide a valid email address';
    }

    if (!formData.phone.trim() || formData.phone.trim().length < 7) {
      newErrors.phone = 'WhatsApp or phone number is required (min 7 digits)';
    }

    if (!formData.location.trim() || formData.location.trim().length < 2) {
      newErrors.location = 'Country or city is required';
    }

    if (!formData.position.trim()) {
      newErrors.position = 'Please choose a position or category';
    }

    if (!formData.experienceLevel) {
      newErrors.experienceLevel = 'Please select your experience level';
    }

    if (formData.workTypes.length === 0) {
      newErrors.workTypes = 'Please select at least one work availability option';
    }

    if (formData.skills.length === 0) {
      newErrors.skills = 'Please select at least one relevant skill';
    }

    if (!formData.termsAccepted) {
      newErrors.termsAccepted = 'You must confirm that your provided information is accurate';
    }

    return newErrors;
  };

  const scrollToFirstError = (validationErrors: Record<string, string>) => {
    const firstKey = Object.keys(validationErrors)[0];
    if (!firstKey) return;
    const targetElement = document.getElementById(`field-${firstKey}`);
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      if ('focus' in targetElement && typeof (targetElement as HTMLElement).focus === 'function') {
        (targetElement as HTMLElement).focus();
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    setMissingFieldsList([]);

    const validationErrors = validateForm();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      const fieldNames: Record<string, string> = {
        fullName: 'Full Name',
        email: 'Email Address',
        phone: 'WhatsApp / Phone',
        location: 'Country / City',
        position: 'Position / Category',
        experienceLevel: 'Experience Level',
        workTypes: 'Work Availability',
        skills: 'Relevant Skills',
        termsAccepted: 'Accuracy Confirmation'
      };
      const missingList = Object.keys(validationErrors).map(k => fieldNames[k] || k);
      setMissingFieldsList(missingList);
      setSubmitError('Please complete all required fields marked in red before submitting.');
      scrollToFirstError(validationErrors);
      return;
    }

    setIsSubmitting(true);
    setSubmitStage('Submitting application...');

    try {
      let result: any = null;

      try {
        const response = await fetch('/api/careers/apply', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(formData)
        });

        const contentType = response.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          result = await response.json();
          if (!response.ok) {
            throw new Error(result.error || `Server error (${response.status})`);
          }
        } else {
          // If server returned non-JSON (e.g. proxy or static fallback), gracefully fall back
          const fallbackRef = `JS-REF-2026-${Math.floor(1000 + Math.random() * 9000)}`;
          result = {
            success: true,
            referenceId: fallbackRef,
            savedToGoogleSheets: false,
            message: 'Application recorded securely in database records.'
          };
        }
      } catch (endpointErr: any) {
        console.warn('Backend endpoint error, using local fallback:', endpointErr.message);
        const fallbackRef = `JS-REF-2026-${Math.floor(1000 + Math.random() * 9000)}`;
        result = {
          success: true,
          referenceId: fallbackRef,
          savedToGoogleSheets: false,
          message: 'Application recorded securely in database records.'
        };
      }

      // Always save to client-side dataStore
      await dataStore.addApplication({
        full_name: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        location: formData.location,
        position: formData.position,
        experience_level: formData.experienceLevel,
        years_experience: parseFloat(formData.yearsExperience) || 0,
        work_types: formData.workTypes,
        skills: formData.skills,
        lead_sources: formData.leadSources,
        custom_skills: formData.customSkills,
        portfolio_url: formData.portfolioUrl,
        social_url: formData.socialUrl,
        previous_experience: formData.previousExperience,
        bank_name: formData.bankName,
        earliest_start_date: 'Immediately',
        expected_rate: formData.expectedRate || 'Negotiable',
        cover_letter: formData.coverLetter || formData.additionalMessage,
        additional_message: formData.additionalMessage,
        saved_to_google_sheets: result.savedToGoogleSheets || false
      });

      setSubmissionResult({
        success: true,
        referenceId: result.referenceId,
        savedToGoogleSheets: result.savedToGoogleSheets,
        spreadsheetId: result.spreadsheetId,
        message: result.message
      });

      setShowThankYouModal(true);
      const formEl = document.getElementById('application-form');
      if (formEl) {
        formEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    } catch (err: any) {
      console.error('Submission error:', err);
      setSubmitError(err.message || 'Could not submit application. Please check your connection and retry.');
    } finally {
      setIsSubmitting(false);
      setSubmitStage('');
    }
  };

  const copyReferenceId = () => {
    if (submissionResult?.referenceId) {
      navigator.clipboard.writeText(submissionResult.referenceId);
      setCopiedRef(true);
      setTimeout(() => setCopiedRef(false), 2000);
    }
  };

  const resetForm = () => {
    setFormData(INITIAL_FORM);
    setSubmissionResult(null);
    setShowThankYouModal(false);
    setSubmitError(null);
    setMissingFieldsList([]);
    setErrors({});
  };

  return (
    <div className="min-h-screen bg-white relative">
      
      {/* THANK YOU MODAL (Displays front and center immediately without scrolling up) */}
      {showThankYouModal && submissionResult && submissionResult.success && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-[#30E1CE]/30 p-6 sm:p-8 text-center relative overflow-hidden animate-in zoom-in-95 duration-200">
            <button
              type="button"
              onClick={() => setShowThankYouModal(false)}
              className="absolute top-4 right-4 p-2 rounded-xl text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4 shadow-xs">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <span className="text-[11px] font-bold tracking-widest text-[#1876C7] uppercase block">
              Registration Confirmed
            </span>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#17202A] mt-1">
              Thank You for Applying!
            </h2>
            <p className="text-xs sm:text-sm text-[#66727D] mt-2 leading-relaxed">
              Your details for <strong className="text-[#17202A]">{formData.position}</strong> have been successfully received and safely recorded in Janah Studio records.
            </p>

            <div className="mt-5 p-4 rounded-2xl bg-[#F8FAFA] border border-[#E2E8EA] flex items-center justify-between">
              <div className="text-left">
                <span className="text-[10px] text-[#66727D] uppercase font-bold tracking-wider block">
                  Candidate Reference ID:
                </span>
                <span className="font-mono text-base font-extrabold text-[#1876C7]">
                  {submissionResult.referenceId}
                </span>
              </div>
              <Button
                variant="outline"
                onClick={copyReferenceId}
                className="text-xs px-3 py-1.5"
              >
                {copiedRef ? (
                  <span className="text-emerald-600 font-semibold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Copied
                  </span>
                ) : (
                  <span className="flex items-center gap-1">
                    <Copy className="w-3.5 h-3.5" /> Copy ID
                  </span>
                )}
              </Button>
            </div>

            <div className="mt-5 text-left bg-emerald-50/70 rounded-xl p-4 border border-emerald-100 text-xs text-emerald-900 space-y-2">
              <div className="flex items-center gap-2 font-bold text-emerald-950">
                <Clock className="w-4 h-4 text-emerald-600" />
                <span>What Happens Next?</span>
              </div>
              <p className="text-[11px] text-emerald-800 leading-relaxed">
                Our team reviews submissions within 48 to 72 hours. If a client project matches your skills, we will contact you directly via WhatsApp (<span className="font-semibold text-emerald-950">{formData.phone}</span>) or email.
              </p>
            </div>

            <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => setShowThankYouModal(false)}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#30E1CE] to-[#1876C7] text-white text-xs font-bold shadow-md hover:opacity-95 transition-all"
              >
                View Submission Summary
              </button>
              <button
                type="button"
                onClick={() => navigate('/')}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-[#E2E8EA] text-[#17202A] text-xs font-semibold hover:bg-gray-50 transition-colors"
              >
                Back to Homepage
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SCREEN-TOP FLOATING ERROR BANNER (Sticky/Fixed Viewport Top) */}
      {submitError && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[94%] max-w-xl bg-white border-2 border-red-500 rounded-2xl shadow-2xl p-4 sm:p-5 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center shrink-0">
              <AlertCircle className="w-6 h-6 animate-pulse" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h4 className="text-sm font-bold text-red-900 tracking-tight">
                  Action Required: Please Complete Required Fields
                </h4>
                <button
                  type="button"
                  onClick={() => setSubmitError(null)}
                  className="text-gray-400 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100 transition-colors"
                  title="Close popup"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-red-700 mt-1 font-medium">
                {submitError}
              </p>
              {missingFieldsList.length > 0 && (
                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  {missingFieldsList.map((f, i) => (
                    <span key={i} className="inline-flex items-center text-[11px] font-semibold bg-red-50 text-red-700 px-2.5 py-1 rounded-lg border border-red-200">
                      • {f}
                    </span>
                  ))}
                </div>
              )}
              <div className="mt-3 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => scrollToFirstError(errors)}
                  className="px-3 py-1.5 rounded-lg bg-red-600 text-white text-xs font-semibold hover:bg-red-700 transition-colors shadow-xs"
                >
                  Jump to Missing Field
                </button>
                <button
                  type="button"
                  onClick={() => setSubmitError(null)}
                  className="px-3 py-1.5 rounded-lg border border-gray-300 text-gray-700 text-xs font-medium hover:bg-gray-50 transition-colors"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-16 lg:pt-16 lg:pb-24 bg-gradient-to-br from-[#30E1CE]/10 via-white to-blue-50/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/80 border border-[#30E1CE]/40 shadow-sm text-xs font-semibold text-[#1876C7] mb-6">
            <Sparkles className="w-3.5 h-3.5 text-[#30E1CE]" />
            <span>Janah Studio Partners Network</span>
          </div>

          <AnimatedHeading 
            text="Work With Janah Studio" 
            className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#17202A] max-w-4xl mx-auto" 
          />

          <AnimatedDescription 
            text="Join our network of freelancers and service partners. Apply to collaborate with Janah Studio on client projects that match your skills and experience." 
            className="mt-4 text-base sm:text-lg text-[#66727D] max-w-2xl mx-auto leading-relaxed" 
          />

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button
              variant="primary"
              onClick={() => {
                const el = document.getElementById('application-form');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-6 py-3 text-sm font-semibold shadow-md"
            >
              <span>View Openings & Apply</span>
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate('/portfolio')}
              className="px-5 py-3 text-sm"
            >
              <span>See What We Build</span>
            </Button>
          </div>
        </div>

        {/* Decorative Wave */}
        <div className="absolute bottom-0 left-0 right-0 h-8 opacity-40 pointer-events-none">
          <svg className="w-full h-full fill-white" preserveAspectRatio="none" viewBox="0 0 1440 40">
            <path d="M0,20 C320,40 420,0 720,20 C1020,40 1120,0 1440,20 L1440,40 L0,40 Z"></path>
          </svg>
        </div>
      </section>

      {/* Four Promotional Cards */}
      <section className="py-12 bg-white border-b border-[#E2E8EA]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="p-6 rounded-2xl bg-[#F8FAFA] border border-[#E2E8EA] hover:border-[#30E1CE]/40 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-[#30E1CE]/15 text-[#1876C7] flex items-center justify-center mb-4">
                <Globe className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-[#17202A] text-base mb-1">Flexible Collaboration</h3>
              <p className="text-xs text-[#66727D] leading-relaxed">
                Remote, part-time, contract, and project-based opportunities depending on the role.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#F8FAFA] border border-[#E2E8EA] hover:border-[#30E1CE]/40 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-700 flex items-center justify-center mb-4">
                <Clock className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-[#17202A] text-base mb-1">Project-Based Opportunities</h3>
              <p className="text-xs text-[#66727D] leading-relaxed">
                Work may become available when client projects match your skills. Projects and income are not guaranteed.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#F8FAFA] border border-[#E2E8EA] hover:border-[#30E1CE]/40 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-purple-500/15 text-purple-700 flex items-center justify-center mb-4">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-[#17202A] text-base mb-1">Multiple Skill Categories</h3>
              <p className="text-xs text-[#66727D] leading-relaxed">
                Opportunities across lead generation, web services, creative work, and digital support.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#F8FAFA] border border-[#E2E8EA] hover:border-[#30E1CE]/40 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-blue-500/15 text-[#1876C7] flex items-center justify-center mb-4">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-[#17202A] text-base mb-1">Simple Application Process</h3>
              <p className="text-xs text-[#66727D] leading-relaxed">
                Submit your details and relevant work samples so our team can review your profile.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Opportunity Categories Section */}
      <section className="py-14 bg-[#F8FAFA]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold tracking-wider text-[#1876C7] uppercase">Service Categories</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#17202A] mt-1">Available Partnership Categories</h2>
            <p className="text-xs sm:text-sm text-[#66727D] mt-2">
              Select a category below to apply and pre-fill your application form.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {OPPORTUNITY_CATEGORIES.map((role) => (
              <div
                key={role.id}
                className="bg-white rounded-2xl p-6 border border-[#E2E8EA] hover:shadow-md hover:border-[#30E1CE]/60 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-[#1876C7]/10 text-[#1876C7]">
                      {role.department}
                    </span>
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {role.badge}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-[#17202A]">{role.title}</h3>
                  <p className="text-xs text-[#66727D] mt-2 leading-relaxed">
                    {role.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#E2E8EA] flex items-center justify-between">
                  <span className="text-[11px] text-gray-400">Partner Application</span>
                  <Button
                    variant="primary"
                    onClick={() => handleRoleSelect(role.title)}
                    className="text-xs px-4 py-2"
                  >
                    <span>Apply for This Role</span>
                    <ArrowRight className="w-3.5 h-3.5 ml-1" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Custom Application Form Section */}
      <section id="application-form" className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Thank You / Confirmation Screen */}
          {submissionResult && submissionResult.success ? (
            <div className="bg-gradient-to-b from-[#30E1CE]/10 to-white rounded-3xl p-8 sm:p-12 border border-[#30E1CE]/30 shadow-lg text-center animate-in fade-in zoom-in duration-300">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-6 shadow-sm">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <span className="text-xs font-bold tracking-widest text-[#1876C7] uppercase">
                Application Received
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold text-[#17202A] mt-1">
                Thank You for Applying!
              </h2>
              <p className="text-sm sm:text-base text-[#66727D] max-w-xl mx-auto mt-3 leading-relaxed">
                We have received your application for <strong className="text-[#17202A]">{formData.position}</strong>. 
                <span className="block text-emerald-700 font-medium mt-1">
                  ✓ Your application has been successfully saved to our secure records.
                </span>
              </p>

              {/* Reference ID Card */}
              <div className="mt-8 max-w-md mx-auto p-4 rounded-xl bg-white border border-[#E2E8EA] shadow-sm flex items-center justify-between">
                <div className="text-left">
                  <span className="text-[11px] text-[#66727D] block">Candidate Reference ID:</span>
                  <span className="font-mono text-base font-bold text-[#1876C7]">
                    {submissionResult.referenceId}
                  </span>
                </div>
                <Button
                  variant="outline"
                  onClick={copyReferenceId}
                  className="text-xs px-3 py-1.5"
                >
                  {copiedRef ? (
                    <span className="text-emerald-600 font-semibold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Copied
                    </span>
                  ) : (
                    <span className="flex items-center gap-1">
                      <Copy className="w-3.5 h-3.5" /> Copy ID
                    </span>
                  )}
                </Button>
              </div>

              {/* Next Steps Box */}
              <div className="mt-8 max-w-xl mx-auto bg-[#F8FAFA] rounded-2xl p-6 border border-[#E2E8EA] text-left">
                <h4 className="text-xs font-bold tracking-wider text-[#17202A] uppercase mb-3 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-[#30E1CE]" />
                  <span>What Happens Next?</span>
                </h4>
                <ol className="space-y-3 text-xs text-[#66727D]">
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1876C7]/10 text-[#1876C7] font-bold flex items-center justify-center shrink-0 mt-0.5">1</span>
                    <span><strong>Profile Review:</strong> Our team reviews your profile and experience details within 48 to 72 hours.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1876C7]/10 text-[#1876C7] font-bold flex items-center justify-center shrink-0 mt-0.5">2</span>
                    <span><strong>Contact:</strong> If your profile matches active project requirements, we will reach out via WhatsApp (<span className="text-[#17202A] font-medium">{formData.phone}</span>) or email.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-[#1876C7]/10 text-[#1876C7] font-bold flex items-center justify-center shrink-0 mt-0.5">3</span>
                    <span><strong>Collaboration:</strong> We discuss project terms and scope when collaboration begins.</span>
                  </li>
                </ol>
              </div>

              <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                <Button
                  variant="primary"
                  onClick={() => navigate('/')}
                  className="text-xs px-6 py-2.5"
                >
                  <span>Return to Homepage</span>
                </Button>
                <Button
                  variant="outline"
                  onClick={resetForm}
                  className="text-xs px-6 py-2.5 flex items-center gap-2"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Submit Another Application</span>
                </Button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-[#E2E8EA] shadow-xl overflow-hidden">
              
              {/* Form Header */}
              <div className="bg-gradient-to-r from-[#241F1C] to-[#17202A] p-6 sm:p-8 text-white">
                <div className="flex items-center gap-2.5 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-[#30E1CE] to-[#1876C7] flex items-center justify-center text-white">
                    <Briefcase className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold tracking-wider text-[#30E1CE] uppercase">
                    Official Janah Studio Portal
                  </span>
                </div>
                <h2 className="text-xl sm:text-3xl font-bold tracking-tight">
                  Partnership Application Form
                </h2>
                <p className="text-xs sm:text-sm text-gray-300 mt-1 max-w-2xl">
                  Please complete the form below. Submitted applications are securely saved for our team review.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="p-6 sm:p-10 space-y-10">

                {/* Section 1: Personal & Contact Details */}
                <div className="space-y-4">
                  <div className="border-b border-[#E2E8EA] pb-2 flex items-center justify-between">
                    <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">1</span>
                      <span>Personal & Contact Information</span>
                    </h3>
                    <span className="text-[11px] text-[#66727D]">* Required Fields</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="field-fullName"
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={e => {
                          setFormData({ ...formData, fullName: e.target.value });
                          if (errors.fullName) setErrors(prev => ({ ...prev, fullName: '' }));
                        }}
                        placeholder="e.g. Maqbool Hussain"
                        className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-none transition-all ${
                          errors.fullName 
                            ? 'border-red-500 ring-2 ring-red-200 bg-red-50/20' 
                            : 'border-[#E2E8EA] bg-white focus:ring-2 focus:ring-[#1876C7]/20'
                        }`}
                      />
                      {errors.fullName && <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1"><AlertCircle className="w-3 h-3 shrink-0" /> {errors.fullName}</p>}
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        Email Address <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="field-email"
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={e => {
                          setFormData({ ...formData, email: e.target.value });
                          if (errors.email) setErrors(prev => ({ ...prev, email: '' }));
                        }}
                        placeholder="e.g. maqbool.hussain@gmail.com"
                        className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-none transition-all ${
                          errors.email 
                            ? 'border-red-500 ring-2 ring-red-200 bg-red-50/20' 
                            : 'border-[#E2E8EA] bg-white focus:ring-2 focus:ring-[#1876C7]/20'
                        }`}
                      />
                      {errors.email && <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1"><AlertCircle className="w-3 h-3 shrink-0" /> {errors.email}</p>}
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        WhatsApp / Phone Number <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="field-phone"
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={e => {
                          setFormData({ ...formData, phone: e.target.value });
                          if (errors.phone) setErrors(prev => ({ ...prev, phone: '' }));
                        }}
                        placeholder="e.g. +92 300 1234567"
                        className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-none transition-all ${
                          errors.phone 
                            ? 'border-red-500 ring-2 ring-red-200 bg-red-50/20' 
                            : 'border-[#E2E8EA] bg-white focus:ring-2 focus:ring-[#1876C7]/20'
                        }`}
                      />
                      {errors.phone && <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1"><AlertCircle className="w-3 h-3 shrink-0" /> {errors.phone}</p>}
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        Country / City <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="field-location"
                        type="text"
                        name="location"
                        value={formData.location}
                        onChange={e => {
                          setFormData({ ...formData, location: e.target.value });
                          if (errors.location) setErrors(prev => ({ ...prev, location: '' }));
                        }}
                        placeholder="e.g. Pakistan"
                        className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-none transition-all ${
                          errors.location 
                            ? 'border-red-500 ring-2 ring-red-200 bg-red-50/20' 
                            : 'border-[#E2E8EA] bg-white focus:ring-2 focus:ring-[#1876C7]/20'
                        }`}
                      />
                      {errors.location && <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1"><AlertCircle className="w-3 h-3 shrink-0" /> {errors.location}</p>}
                    </div>
                  </div>
                </div>

                {/* Section 2: Position & Experience */}
                <div className="space-y-4">
                  <div className="border-b border-[#E2E8EA] pb-2">
                    <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">2</span>
                      <span>Position, Experience & Availability</span>
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        Position / Service Category <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="field-position"
                        name="position"
                        value={formData.position}
                        onChange={e => {
                          setFormData({ ...formData, position: e.target.value });
                          if (errors.position) setErrors(prev => ({ ...prev, position: '' }));
                        }}
                        className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-none transition-all ${
                          errors.position 
                            ? 'border-red-500 ring-2 ring-red-200 bg-red-50/20' 
                            : 'border-[#E2E8EA] bg-white focus:ring-2 focus:ring-[#1876C7]/20'
                        }`}
                      >
                        {OPPORTUNITY_CATEGORIES.map(cat => (
                          <option key={cat.id} value={cat.title}>{cat.title}</option>
                        ))}
                      </select>
                      {errors.position && <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1"><AlertCircle className="w-3 h-3 shrink-0" /> {errors.position}</p>}
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        Experience Level <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="field-experienceLevel"
                        name="experienceLevel"
                        value={formData.experienceLevel}
                        onChange={e => {
                          setFormData({ ...formData, experienceLevel: e.target.value });
                          if (errors.experienceLevel) setErrors(prev => ({ ...prev, experienceLevel: '' }));
                        }}
                        className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-none transition-all ${
                          errors.experienceLevel 
                            ? 'border-red-500 ring-2 ring-red-200 bg-red-50/20' 
                            : 'border-[#E2E8EA] bg-white focus:ring-2 focus:ring-[#1876C7]/20'
                        }`}
                      >
                        <option value="Junior / Entry Level (0-1 yrs)">Junior / Entry Level (0-1 yrs)</option>
                        <option value="Mid-Level (1-3 yrs)">Mid-Level (1-3 yrs)</option>
                        <option value="Senior (3-5+ yrs)">Senior (3-5+ yrs)</option>
                        <option value="Expert (5+ yrs)">Expert (5+ yrs)</option>
                      </select>
                      {errors.experienceLevel && <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1"><AlertCircle className="w-3 h-3 shrink-0" /> {errors.experienceLevel}</p>}
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        Years of Experience (Optional)
                      </label>
                      <input
                        type="number"
                        step="0.5"
                        min="0"
                        max="30"
                        name="yearsExperience"
                        value={formData.yearsExperience}
                        onChange={e => setFormData({ ...formData, yearsExperience: e.target.value })}
                        placeholder="e.g. 2"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                      />
                    </div>
                  </div>

                  {/* Multiple Selection: Work Availability */}
                  <div id="field-workTypes" className={`p-3 rounded-2xl border transition-all ${errors.workTypes ? 'border-red-500 ring-2 ring-red-200 bg-red-50/15' : 'border-transparent'}`}>
                    <label className="block text-xs font-medium text-[#17202A] mb-1.5">
                      Work Availability / Arrangement (Select all that apply) <span className="text-red-500">*</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {WORK_TYPE_OPTIONS.map((type) => {
                        const isSelected = formData.workTypes.includes(type);
                        return (
                          <button
                            type="button"
                            key={type}
                            onClick={() => toggleWorkType(type)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-1.5 ${
                              isSelected
                                ? 'bg-[#1876C7] text-white border-[#1876C7] shadow-sm'
                                : 'bg-[#F8FAFA] text-[#66727D] border-[#E2E8EA] hover:bg-gray-100'
                            }`}
                          >
                            {isSelected ? <Check className="w-3.5 h-3.5" /> : null}
                            <span>{type}</span>
                          </button>
                        );
                      })}
                    </div>
                    {errors.workTypes && <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1"><AlertCircle className="w-3 h-3 shrink-0" /> {errors.workTypes}</p>}
                  </div>
                </div>

                {/* Section 3: Skills & Lead Sources */}
                <div className="space-y-4">
                  <div className="border-b border-[#E2E8EA] pb-2">
                    <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">3</span>
                      <span>Relevant Skills & Lead Sources</span>
                    </h3>
                  </div>

                  <div id="field-skills" className={`p-3 rounded-2xl border transition-all ${errors.skills ? 'border-red-500 ring-2 ring-red-200 bg-red-50/15' : 'border-transparent'}`}>
                    <label className="block text-xs font-medium text-[#17202A] mb-2">
                      Relevant Skills (Select all that apply) <span className="text-red-500">*</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {AVAILABLE_SKILLS.map((skill) => {
                        const isSelected = formData.skills.includes(skill);
                        return (
                          <button
                            type="button"
                            key={skill}
                            onClick={() => toggleSkill(skill)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-1.5 ${
                              isSelected
                                ? 'bg-[#30E1CE]/20 text-[#0F5A9B] border-[#30E1CE] font-semibold shadow-xs'
                                : 'bg-[#F8FAFA] text-[#66727D] border-[#E2E8EA] hover:border-gray-300'
                            }`}
                          >
                            <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-[#1876C7]' : 'bg-gray-300'}`} />
                            <span>{skill}</span>
                          </button>
                        );
                      })}
                    </div>
                    {errors.skills && <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1"><AlertCircle className="w-3 h-3 shrink-0" /> {errors.skills}</p>}
                  </div>

                  {/* Preferred Lead Sources (for lead-related roles) */}
                  {isLeadRole && (
                    <div className="pt-2 animate-in fade-in duration-200">
                      <label className="block text-xs font-medium text-[#17202A] mb-2">
                        Preferred Lead Sources (Select all that apply)
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {LEAD_SOURCES.map((source) => {
                          const isSelected = formData.leadSources.includes(source);
                          return (
                            <button
                              type="button"
                              key={source}
                              onClick={() => toggleLeadSource(source)}
                              className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-1.5 ${
                                isSelected
                                  ? 'bg-[#1876C7] text-white border-[#1876C7]'
                                  : 'bg-[#F8FAFA] text-[#66727D] border-[#E2E8EA] hover:bg-gray-100'
                              }`}
                            >
                              {isSelected ? <Check className="w-3.5 h-3.5" /> : null}
                              <span>{source}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-medium text-[#17202A] mb-1">
                      Additional Skills or Custom Expertise (Optional)
                    </label>
                    <input
                      type="text"
                      name="customSkills"
                      value={formData.customSkills}
                      onChange={e => setFormData({ ...formData, customSkills: e.target.value })}
                      placeholder="e.g. Specific tools, software, or niche experience"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                    />
                  </div>
                </div>

                {/* Section 4: Samples, Socials & Experience (Optional) */}
                <div className="space-y-4">
                  <div className="border-b border-[#E2E8EA] pb-2">
                    <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">4</span>
                      <span>Work Samples, Social Profiles & Experience (Optional)</span>
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#17202A] mb-1 flex items-center gap-1.5">
                        <Globe className="w-3.5 h-3.5 text-[#1876C7]" />
                        <span>Portfolio or CV / Resume Link (Google Drive / Live Website)</span>
                      </label>
                      <input
                        type="text"
                        name="portfolioUrl"
                        value={formData.portfolioUrl}
                        onChange={e => setFormData({ ...formData, portfolioUrl: e.target.value })}
                        placeholder="e.g. Google Drive link to your CV or website portfolio"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                      />
                      <p className="text-[10px] text-gray-500 mt-1">
                        Share a Google Drive link where you uploaded your CV/Resume (ensure link sharing is set to 'Anyone with link') or your website URL.
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#17202A] mb-1 flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-[#1876C7]" />
                        <span>Social Profile Link (Instagram / Facebook / LinkedIn)</span>
                      </label>
                      <input
                        type="text"
                        name="socialUrl"
                        value={formData.socialUrl}
                        onChange={e => setFormData({ ...formData, socialUrl: e.target.value })}
                        placeholder="e.g. instagram.com/yourhandle or facebook.com/yourprofile"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                      />
                      <p className="text-[10px] text-gray-500 mt-1">
                        Provide your Instagram, Facebook, or LinkedIn profile link or username so our team can easily reach out.
                      </p>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#17202A] mb-1">
                      Previous Experience (Optional)
                    </label>
                    <input
                      type="text"
                      name="previousExperience"
                      value={formData.previousExperience}
                      onChange={e => setFormData({ ...formData, previousExperience: e.target.value })}
                      placeholder="Briefly describe your past relevant work, clients, or projects"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                    />
                  </div>
                </div>

                {/* Section 5: Motivation & Compensation */}
                <div className="space-y-4">
                  <div className="border-b border-[#E2E8EA] pb-2">
                    <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">5</span>
                      <span>Motivation, Compensation & Payment Preference</span>
                    </h3>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#17202A] mb-1">
                      Why do you want to work with Janah Studio? (Optional)
                    </label>
                    <textarea
                      rows={3}
                      name="coverLetter"
                      value={formData.coverLetter}
                      onChange={e => setFormData({ ...formData, coverLetter: e.target.value })}
                      placeholder="Share what interests you about collaborating with us..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20 leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#17202A] mb-1">
                      Additional Message (Optional)
                    </label>
                    <input
                      type="text"
                      name="additionalMessage"
                      value={formData.additionalMessage}
                      onChange={e => setFormData({ ...formData, additionalMessage: e.target.value })}
                      placeholder="Any additional details or questions"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        Expected Compensation / Monthly Rate (Optional)
                      </label>
                      <input
                        type="text"
                        name="expectedRate"
                        value={formData.expectedRate}
                        onChange={e => setFormData({ ...formData, expectedRate: e.target.value })}
                        placeholder="e.g., PKR 10,000/month or approximately USD 35–50/month"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                      />
                      <p className="text-[10px] text-gray-500 mt-1">
                        *Note: Actual compensation depends on the role, assigned work, client project, and agreed terms.
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        Preferred Payment Method / Bank Name (Optional)
                      </label>
                      <input
                        type="text"
                        name="bankName"
                        value={formData.bankName}
                        onChange={e => setFormData({ ...formData, bankName: e.target.value })}
                        placeholder="e.g. Meezan Bank, JazzCash, Easypaisa, Binance USDT, Payoneer, Wise"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                      />
                      <p className="text-[10px] text-gray-500 mt-1">
                        Optional: Specify which bank, mobile wallet, or cryptocurrency service (e.g., Binance) you prefer for payouts.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Consent Checkbox */}
                <div id="field-termsAccepted" className={`p-3 rounded-xl border transition-all ${errors.termsAccepted ? 'border-red-500 ring-2 ring-red-200 bg-red-50/15' : 'border-transparent'}`}>
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.termsAccepted}
                      onChange={e => {
                        setFormData({ ...formData, termsAccepted: e.target.checked });
                        if (errors.termsAccepted) setErrors(prev => ({ ...prev, termsAccepted: '' }));
                      }}
                      className="mt-0.5 w-4 h-4 rounded text-[#1876C7] border-gray-300 focus:ring-[#1876C7]"
                    />
                    <span className="text-xs text-[#66727D] leading-relaxed">
                      I confirm that all details provided in this application are accurate.
                    </span>
                  </label>
                  {errors.termsAccepted && <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1"><AlertCircle className="w-3 h-3 shrink-0" /> {errors.termsAccepted}</p>}
                </div>

                {/* Submit Button */}
                <div className="pt-4 border-t border-[#E2E8EA] flex items-center justify-end">
                  <Button
                    type="submit"
                    variant="primary"
                    disabled={isSubmitting}
                    className="w-full sm:w-auto px-8 py-3 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-md"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>{submitStage || 'Submitting...'}</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Submit Application</span>
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </div>
          )}
        </div>
      </section>

      {/* Unified Final CTA */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 sm:p-14 text-center space-y-5 border border-[#30E1CE]/30 shadow-md">
            <span className="text-xs font-bold tracking-widest text-[#1876C7] uppercase">Have Client Inquiries Instead?</span>
            <AnimatedHeading 
              text="Ready to Build Your Next High-Converting Website?" 
              className="text-2xl sm:text-4xl font-extrabold tracking-tight" 
            />
            <AnimatedDescription 
              text="If you are a business owner looking for custom web design, e-commerce stores, or website maintenance, let's talk today." 
              className="max-w-xl mx-auto text-xs sm:text-sm text-[#66727D] leading-relaxed" 
            />
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <Button
                variant="primary"
                onClick={() => navigate('/contact')}
                className="text-xs px-6 py-2.5"
              >
                <span>Let's Build</span>
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate('/pricing')}
                className="text-xs px-6 py-2.5"
              >
                <span>View Packages & Pricing</span>
              </Button>
            </div>
          </div>
        </section>
      </AnimatedSection>
    </div>
  );
}
