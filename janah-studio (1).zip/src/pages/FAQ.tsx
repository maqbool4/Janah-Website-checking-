import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageCircle, ArrowRight, Plus, Minus, HelpCircle } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { dataStore } from '../lib/dataStore';
import { FaqItem } from '../lib/types';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';
import { SEO } from '../components/SEO';

export default function FAQ() {
  const navigate = useNavigate();
  const whatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent("Hi Janah Studio, I have a question regarding website development.")}`;
  const [faqs, setFaqs] = useState<FaqItem[]>(() => dataStore.getFaqsSync().filter(f => f.is_active));
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [openFaqId, setOpenFaqId] = useState<string | null>(null);

  useEffect(() => {
    dataStore.getFaqs().then(res => setFaqs(res.filter(f => f.is_active)));
  }, []);

  const allCategories = Array.from(new Set(faqs.map(f => f.category).filter(Boolean)));
  const categories = ['All', ...allCategories];

  const filteredFaqs = faqs.filter(f => {
    return selectedCategory === 'All' || f.category === selectedCategory;
  });

  // Group by category if 'All' is selected
  const categoriesList = selectedCategory === 'All' 
    ? allCategories
    : [selectedCategory];

  return (
    <div className="space-y-16 pb-20 pt-2">
      <SEO
        title="Frequently Asked Questions (FAQ) | Janah Studio"
        description="Find clear answers about our web development services, pricing, project timelines, hosting, revisions, and maintenance support."
        keywords="website FAQ, web development questions, small business website FAQs, Janah Studio questions, web design process"
        canonicalPath="/faq"
        structuredData={{
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": faqs.slice(0, 15).map(f => ({
            "@type": "Question",
            "name": f.question,
            "acceptedAnswer": {
              "@type": "Answer",
              "text": f.answer
            }
          }))
        }}
      />
      
      {/* Hero */}
      <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] pt-2 pb-10 sm:pb-14 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30">
        <div className="relative z-10 max-w-3xl space-y-2">
          <AnimatedHeading
            text="Frequently Asked Questions"
            as="h1"
            className="text-4xl sm:text-5xl font-extrabold text-[#17202A] tracking-tight leading-tight"
          />
          <div className="w-36 h-3 mt-1 mb-2">
            <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
              <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <defs>
                <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#30E1CE" />
                  <stop offset="50%" stopColor="#1876C7" />
                  <stop offset="100%" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <AnimatedDescription
            text="Find clear answers about our services, pricing, projects, maintenance, and website development process."
            className="text-base sm:text-lg text-[#66727D] leading-relaxed"
            delay={0.2}
          />
        </div>
      </section>

      {/* FAQs List */}
      <AnimatedSection>
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Category Horizontal Slider */}
        <div className="flex items-center gap-2 overflow-x-auto whitespace-nowrap pb-2 pt-1 scrollbar-none px-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-[#30E1CE] to-[#1876C7] text-white shadow-md'
                  : 'bg-white text-[#66727D] border border-[#E2E8EA] hover:border-[#1876C7]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {faqs.length === 0 ? (
          <div className="text-center py-16 bg-[#F8FAFA] rounded-3xl border border-[#E2E8EA] space-y-3">
            <h3 className="text-lg font-bold text-[#17202A]">No Questions Listed Yet</h3>
            <p className="text-xs text-[#66727D] max-w-md mx-auto">Have a specific question about your project? Contact us directly on WhatsApp and we will answer right away.</p>
            <div className="pt-2">
              <Button
                variant="chat"
                onClick={() => window.open(whatsappUrl, '_blank')}
                className="px-6"
              >
                <MessageCircle className="w-4 h-4 text-white" />
                <span>WhatsApp</span>
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            {categoriesList.map((catName) => {
              const catFaqs = filteredFaqs.filter(f => (f.category || 'General') === catName);
              if (catFaqs.length === 0) return null;

              return (
                <div key={catName} className="space-y-3">
                  <h3 className="text-lg font-bold text-[#17202A] border-b border-[#E2E8EA] pb-2 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#1876C7]"></span>
                    <span>{catName}</span>
                  </h3>

                  <div className="space-y-2.5">
                    {catFaqs.map((faq) => {
                      const isOpen = openFaqId === faq.id;
                      return (
                        <div key={faq.id} className="bg-white rounded-xl border border-[#E2E8EA] shadow-xs overflow-hidden transition-all">
                          <button
                            onClick={() => setOpenFaqId(isOpen ? null : faq.id)}
                            className="w-full px-5 py-3.5 text-left flex items-center justify-between gap-3 focus:outline-none"
                          >
                            <span className="text-xs sm:text-sm font-bold text-[#17202A]">{faq.question}</span>
                            <span className="w-6 h-6 rounded-full bg-[#1876C7]/10 text-[#1876C7] flex items-center justify-center shrink-0 transition-transform">
                              {isOpen ? <Minus className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                            </span>
                          </button>
                          {isOpen && (
                            <div className="px-5 pb-4 pt-0 text-xs sm:text-sm text-[#66727D] leading-relaxed border-t border-[#E2E8EA]/40 mt-1">
                              {faq.answer}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
      </AnimatedSection>

      {/* Final CTA Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none pt-4 pb-10 sm:pb-14 px-8 sm:px-16 text-center space-y-3 shadow-2xl relative overflow-hidden border border-[#30E1CE]/30">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#30E1CE]/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <AnimatedHeading
            text="Have a Specific Question?"
            as="h2"
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#17202A]"
          />
          <AnimatedDescription
            text="Ask us directly on WhatsApp and get a prompt response."
            className="text-sm sm:text-base text-[#66727D] max-w-xl mx-auto leading-relaxed"
            delay={0.15}
          />

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <Button
              variant="chat"
              onClick={() => window.open(whatsappUrl, '_blank')}
              className="px-6 shrink-0"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>

            <Button
              variant="outline"
              onClick={() => navigate('/contact')}
              className="px-6 shrink-0 border-[#1876C7] text-[#1876C7]"
            >
              <span>Contact Us</span>
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </Button>
          </div>
        </div>
      </section>
      </AnimatedSection>

    </div>
  );
}
