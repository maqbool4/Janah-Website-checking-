import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { MessageCircle, ArrowRight, ShieldCheck, FileText, Lock, Cookie } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';

export default function Legal() {
  const location = useLocation();
  const navigate = useNavigate();
  const path = location.pathname;

  let title = 'Privacy Policy';
  let desc = 'Information about how personal information is collected, used, stored, and protected when you use Janah Studio.';
  let badge = 'PRIVACY POLICY';
  let IconComponent = Lock;

  if (path === '/terms') {
    title = 'Terms of Service';
    desc = 'Terms and conditions governing the provision of website development, e-commerce creation, and support services by Janah Studio.';
    badge = 'TERMS & CONDITIONS';
    IconComponent = FileText;
  } else if (path === '/cookie-policy') {
    title = 'Cookie Policy';
    desc = 'Information regarding how cookies and similar tracking technologies are utilized on the Janah Studio website.';
    badge = 'COOKIE POLICY';
    IconComponent = Cookie;
  }

  const whatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent("Hi Janah Studio, I have a legal or project inquiry.")}`;

  return (
    <div className="space-y-16 pb-20 pt-2">
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] pt-2 pb-10 sm:pb-14 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30">
        <div className="relative z-10 max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1876C7]/10 text-xs font-bold text-[#1876C7] uppercase tracking-wider mb-1">
            <IconComponent className="w-3.5 h-3.5 text-[#1876C7]" />
            <span>{badge}</span>
          </div>

          <AnimatedHeading
            text={title}
            as="h1"
            className="text-4xl sm:text-5xl font-extrabold text-[#17202A] tracking-tight leading-tight"
          />
          <div className="w-36 h-3 mt-1 mb-2">
            <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
              <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <defs>
                <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#30E1CE" />
                  <stop offset="50%" stopColor="#1876C7" />
                  <stop offset="100%" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <AnimatedDescription
            text={desc}
            className="text-base sm:text-lg text-[#66727D] leading-relaxed"
            delay={0.2}
          />
        </div>
      </section>

      {/* Content Section */}
      <AnimatedSection>
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 bg-white rounded-3xl p-8 sm:p-12 border border-[#E2E8EA] shadow-lg">
          
          {path === '/privacy-policy' && (
            <div className="space-y-8 text-sm text-[#17202A] leading-relaxed">
              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  1. Information We Collect
                </h2>
                <p className="text-[#66727D] pl-4">
                  When you interact with Janah Studio, fill out project inquiry forms, or contact us via WhatsApp and email, we collect information you provide directly. This includes your full name, business or brand name, email address, WhatsApp telephone number, project specifications, budget range, and timeline preferences.
                </p>
              </div>

              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  2. How We Use Your Information
                </h2>
                <p className="text-[#66727D] pl-4">
                  The information we gather is used exclusively to:
                </p>
                <ul className="list-disc pl-10 space-y-1.5 text-[#66727D]">
                  <li>Communicate with you regarding website development and e-commerce projects.</li>
                  <li>Provide accurate quotes, proposals, and tailored service scope documents.</li>
                  <li>Deliver contracted website design, maintenance, and support services.</li>
                  <li>Improve our client onboarding experience and service quality.</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  3. Data Security & Storage
                </h2>
                <p className="text-[#66727D] pl-4">
                  We maintain strict administrative, technical, and physical safeguards to protect your personal information and project data. Project submissions are encrypted in transit and at rest with role-based access controls to prevent unauthorized access.
                </p>
              </div>

              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  4. Third-Party Sharing
                </h2>
                <p className="text-[#66727D] pl-4">
                  We do not sell, trade, or rent your personal information to third parties. Trusted service providers assisting us in operating our infrastructure are bound by confidentiality obligations.
                </p>
              </div>

              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  5. Contact Us
                </h2>
                <p className="text-[#66727D] pl-4">
                  If you have any questions, concerns, or requests regarding this Privacy Policy, please reach out to us at <a href="mailto:janahstudio.official@gmail.com" className="text-[#1876C7] font-semibold underline">janahstudio.official@gmail.com</a>.
                </p>
              </div>
            </div>
          )}

          {path === '/terms' && (
            <div className="space-y-8 text-sm text-[#17202A] leading-relaxed">
              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  1. Scope of Services
                </h2>
                <p className="text-[#66727D] pl-4">
                  Janah Studio provides professional website development, e-commerce store setup, landing page creation, website redesigns, personal portfolios, and ongoing maintenance support as agreed upon in project proposals.
                </p>
              </div>

              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  2. Payments & Project Milestones
                </h2>
                <p className="text-[#66727D] pl-4">
                  A 50% initial deposit is generally required to secure project scheduling and begin design and development work. The remaining 50% balance is due upon project completion and client review, prior to final launch and handover.
                </p>
              </div>

              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  3. Revisions & Approvals
                </h2>
                <p className="text-[#66727D] pl-4">
                  Standard website development packages include specified revision rounds. Each revision round consists of a consolidated list of feedback. Additional features or scope changes outside the initial agreement may be billed separately. Written client approval is required before final launch.
                </p>
              </div>

              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  4. Domain, Hosting & Third-Party Accounts
                </h2>
                <p className="text-[#66727D] pl-4">
                  Clients are responsible for registering and maintaining ownership of their domain names, web hosting accounts, and third-party payment gateways. Janah Studio provides technical configuration and setup assistance.
                </p>
              </div>

              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  5. Intellectual Property
                </h2>
                <p className="text-[#66727D] pl-4">
                  Upon full and final payment, the client receives ownership rights to the final customized website deliverables created for their business.
                </p>
              </div>
            </div>
          )}

          {path === '/cookie-policy' && (
            <div className="space-y-8 text-sm text-[#17202A] leading-relaxed">
              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  1. What Are Cookies?
                </h2>
                <p className="text-[#66727D] pl-4">
                  Cookies are small text files placed on your computer or mobile device when you visit a website. They are widely used to make websites work efficiently, as well as to provide reporting information to site owners.
                </p>
              </div>

              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  2. How We Use Cookies
                </h2>
                <p className="text-[#66727D] pl-4">
                  Janah Studio uses cookies for:
                </p>
                <ul className="list-disc pl-10 space-y-1.5 text-[#66727D]">
                  <li>Essential site navigation and security.</li>
                  <li>Remembering user preferences and UI state.</li>
                  <li>Maintaining secure administrative dashboard authentication sessions.</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h2 className="text-xl font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  3. Managing Cookies
                </h2>
                <p className="text-[#66727D] pl-4">
                  You can control and manage cookies through your web browser settings. Disabling certain cookies may impact the functionality of specific website features.
                </p>
              </div>
            </div>
          )}

        </section>
      </AnimatedSection>

      {/* Final CTA Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none pt-4 pb-10 sm:pb-14 px-8 sm:px-16 text-center space-y-3 shadow-2xl relative overflow-hidden border border-[#30E1CE]/30">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#30E1CE]/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <AnimatedHeading
            text="Ready to Build Your Website?"
            as="h2"
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#17202A]"
          />
          <AnimatedDescription
            text="Let’s discuss your business, goals, and project needs. Get started with Janah Studio today."
            className="text-sm sm:text-base text-[#66727D] max-w-xl mx-auto leading-relaxed"
            delay={0.15}
          />

          <div className="flex flex-row flex-nowrap items-center justify-center gap-2 sm:gap-4 pt-4 overflow-x-auto pb-1">
            <Button
              variant="primary"
              onClick={() => navigate('/contact')}
              className="px-6 sm:px-8 shrink-0"
            >
              <span>Let’s Build</span>
              <ArrowRight className="w-4 h-4" />
            </Button>

            <Button
              variant="chat"
              onClick={() => window.open(whatsappUrl, '_blank')}
              className="px-6 sm:px-8 shrink-0"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>
          </div>
        </div>
      </section>
      </AnimatedSection>

    </div>
  );
}
