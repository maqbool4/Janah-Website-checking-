import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Code } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-3xl p-8 sm:p-12 border border-[#E2E8EA] shadow-xl text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-[#30E1CE] to-[#1876C7] flex items-center justify-center mx-auto text-white font-bold shadow-md">
          <Code className="w-8 h-8" />
        </div>
        
        <div className="space-y-2">
          <h1 className="text-3xl font-extrabold text-[#17202A]">Page Not Found</h1>
          <p className="text-sm text-[#66727D] leading-relaxed">
            The page you're looking for could not be found.
          </p>
        </div>

        <Link
          to="/"
          className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#30E1CE] to-[#1876C7] text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 hover:opacity-95 transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
}
