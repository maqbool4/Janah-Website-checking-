import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MessageCircle, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';
import { SEO } from '../components/SEO';

export default function About() {
  const navigate = useNavigate();
  const whatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent("Hi Janah Studio, I'd like to talk about a website project.")}`;

  return (
    <div className="space-y-16 pb-20 pt-8">
      <SEO
        title="About Janah Studio – Mission, Craft & Modern Web Solutions"
        description="Learn about Janah Studio, our mission to build reliable, high-performing websites and e-commerce stores for small businesses with complete client ownership."
        keywords="about Janah Studio, web design agency, website studio Pakistan, custom web developer, small business websites"
        canonicalPath="/about"
      />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] pt-2 pb-10 sm:pb-14 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30">
        <div className="relative z-10 max-w-3xl space-y-2">
          <AnimatedHeading
            text="About Janah Studio"
            as="h1"
            className="text-4xl sm:text-5xl font-extrabold text-[#17202A] tracking-tight leading-tight"
          />
          <div className="w-36 h-3 mt-1 mb-2">
            <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
              <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <defs>
                <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#30E1CE" />
                  <stop offset="50%" stopColor="#1876C7" />
                  <stop offset="100%" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <AnimatedDescription
            text="Janah Studio is a web development studio helping small businesses and individuals establish a professional online presence. We create business websites, online stores, landing pages, and personal portfolio websites tailored to different needs, goals, and audiences."
            className="text-base sm:text-lg text-[#66727D] leading-relaxed"
            delay={0.2}
          />
          <div className="flex flex-wrap gap-4 pt-2">
            <Link to="/contact">
              <Button variant="navy-blue" className="flex items-center gap-2">
                <span>Let’s Build</span>
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
              <Button variant="chat" className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-white" />
                <span>Chat Us</span>
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        <AnimatedSection direction="left">
          <div className="bg-white rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#E2E8EA] shadow-sm space-y-6 h-full">
            <p className="text-[#66727D] leading-relaxed">
              Our approach combines practical solutions, responsive development, clear communication, and user-friendly experiences. We aim to make website development straightforward while helping clients present their businesses, services, and work professionally online.
            </p>
            <p className="text-[#66727D] leading-relaxed">
              Whether you are launching a business, showcasing your skills, or improving an existing website, Janah Studio works with you to build a website suited to your requirements.
            </p>
          </div>
        </AnimatedSection>
        
        {/* Our Approach */}
        <AnimatedSection direction="right">
          <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#30E1CE]/30 shadow-xl space-y-6 h-full">
          <AnimatedHeading
            text="Our Approach"
            as="h2"
            className="text-2xl font-bold text-[#17202A]"
          />
          <div className="grid grid-cols-1 gap-4">
            {[
              { title: 'Designed Around Your Goals', desc: 'Every project begins with understanding your needs, target audience, and objectives.' },
              { title: 'Professional and User-Friendly', desc: 'We focus on clear content, intuitive navigation, and professional presentation.' },
              { title: 'Responsive Across Devices', desc: 'We develop websites to provide a consistent experience across devices.' },
              { title: 'Built for Online Growth', desc: 'We establish a practical foundation for your online presence.' },
              { title: 'Clear Communication', desc: 'We discuss requirements and keep you informed throughout the process.' },
            ].map((item, i) => (
              <div key={i} className="bg-white/70 rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#30E1CE]/30 shadow-sm">
                <h3 className="text-sm font-bold text-[#17202A] mb-1">{item.title}</h3>
                <p className="text-xs text-[#66727D] leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
          </div>
        </AnimatedSection>
      </section>

      {/* Final CTA Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none pt-4 pb-10 sm:pb-14 px-8 sm:px-16 text-center space-y-3 shadow-2xl relative overflow-hidden border border-[#30E1CE]/30">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#30E1CE]/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <AnimatedHeading
            text="Let's Build Your Online Presence"
            as="h2"
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#17202A]"
          />
          <AnimatedDescription
            text="Partner with Janah Studio to create a professional website that helps your business stand out and grow."
            className="text-sm sm:text-base text-[#66727D] max-w-xl mx-auto leading-relaxed"
            delay={0.15}
          />

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <Button
              variant="primary"
              onClick={() => navigate('/contact')}
              className="px-6 shrink-0"
            >
              <span>Start Project</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>

            <Button
              variant="chat"
              onClick={() => window.open(whatsappUrl, '_blank')}
              className="px-6 shrink-0"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>
          </div>
        </div>
      </section>
      </AnimatedSection>

    </div>
  );
}
