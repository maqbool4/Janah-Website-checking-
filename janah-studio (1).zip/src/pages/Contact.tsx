import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  CheckCircle2, 
  MessageCircle, 
  Mail, 
  Phone, 
  Send, 
  AlertCircle, 
  X, 
  Sparkles, 
  Globe, 
  Check, 
  HelpCircle,
  Briefcase,
  Layers,
  Calendar,
  DollarSign
} from 'lucide-react';
import { dataStore } from '../lib/dataStore';
import { ContactSubmission } from '../lib/types';
import { Button } from '../components/ui/Button';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';
import { SEO } from '../components/SEO';

interface ContactFormData {
  name: string;
  business_name: string;
  email: string;
  whatsapp_phone: string;
  enquiry_type: string;
  service: string;
  service_other_description: string;
  project_description: string;
  goals: string[];
  goals_other: string;
  features_needed: string[];
  features_other: string;
  has_existing_website: 'Yes' | 'No' | 'Not Sure' | '';
  existing_website_url: string;
  budget: string;
  custom_budget: string;
  timeline: string;
  timeline_other: string;
  additional_info: string;
}

export default function Contact() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    business_name: '',
    email: '',
    whatsapp_phone: '',
    enquiry_type: 'Start a New Project',
    service: 'Website Development',
    service_other_description: '',
    project_description: '',
    goals: [],
    goals_other: '',
    features_needed: [],
    features_other: '',
    has_existing_website: '',
    existing_website_url: '',
    budget: '',
    custom_budget: '',
    timeline: '',
    timeline_other: '',
    additional_info: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [showThankYouModal, setShowThankYouModal] = useState(false);
  const [savedEnquirySummary, setSavedEnquirySummary] = useState<string>('');

  // Fixed Janah Studio contact links
  const generalWhatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent("Hi Janah Studio, I'd like to discuss a website project.")}`;
  const studioEmail = "janahstudio.official@gmail.com";

  // Enquiry Type Options
  const ENQUIRY_TYPES = [
    'Start a New Project',
    'Get a Price Estimate',
    'Improve or Fix an Existing Website',
    'Existing Client Support',
    'General Question',
    'Partnership or Collaboration',
    'Affiliate Program',
    'Something Else'
  ];

  // Core Services & Additional Needs
  const CORE_SERVICES = [
    'Website Development',
    'E-commerce Development',
    'Landing Page Development',
    'Portfolio Website Development',
    'Website Redesign',
    'Website Maintenance & Support'
  ];

  const ADDITIONAL_NEEDS = [
    'Technical Issue or Website Fix',
    'Website Setup, Domain or Hosting',
    'Performance or Mobile Improvements',
    'Other Service / Something Else',
    "I'm Not Sure Yet"
  ];

  // Goals
  const GOAL_OPTIONS = [
    'Build an Online Presence',
    'Get More Customers or Enquiries',
    'Sell Products Online',
    'Showcase My Work or Portfolio',
    'Improve an Existing Website',
    'Improve Website Performance',
    'Fix a Technical Problem',
    'Other',
    "I'm Not Sure Yet"
  ];

  // Features
  const FEATURE_OPTIONS = [
    'Contact Form',
    'WhatsApp Integration',
    'Online Payments',
    'Product Catalogue or Online Store',
    'Booking or Appointment System',
    'Gallery or Portfolio',
    'Blog or Articles',
    'Customer Login or Accounts',
    'Analytics or Tracking',
    'Other Feature',
    'Not Sure Yet'
  ];

  // Budget Options (Exact)
  const BUDGET_OPTIONS = [
    'Under PKR 5,000',
    'PKR 5,000–10,000',
    'PKR 10,000–20,000',
    'PKR 20,000–30,000',
    'PKR 30,000–50,000',
    'PKR 50,000–75,000',
    'Custom Budget',
    "I'm Not Sure Yet"
  ];

  // Timeline Options
  const TIMELINE_OPTIONS = [
    'As Soon As Possible',
    'Within 1–2 Weeks',
    'Within 3–4 Weeks',
    'Within 1–2 Months',
    'Flexible / No Fixed Deadline',
    'Other'
  ];

  // Determine if enquiry is project-oriented
  const isProjectEnquiry = [
    'Start a New Project',
    'Get a Price Estimate',
    'Improve or Fix an Existing Website',
    'Something Else'
  ].includes(formData.enquiry_type);

  // Toggle multi-select goals
  const toggleGoal = (goal: string) => {
    setFormData(prev => {
      const exists = prev.goals.includes(goal);
      const updated = exists ? prev.goals.filter(g => g !== goal) : [...prev.goals, goal];
      return { ...prev, goals: updated };
    });
  };

  // Toggle multi-select features
  const toggleFeature = (feature: string) => {
    setFormData(prev => {
      const exists = prev.features_needed.includes(feature);
      const updated = exists ? prev.features_needed.filter(f => f !== feature) : [...prev.features_needed, feature];
      return { ...prev, features_needed: updated };
    });
  };

  // Construct message for WhatsApp / Email
  const buildEnquirySummaryMessage = (data: ContactFormData): string => {
    const lines: string[] = [];
    lines.push('Website Enquiry — Janah Studio');
    lines.push('━━━━━━━━━━━━━━━━━━━━');
    lines.push(`Enquiry Type: ${data.enquiry_type}`);
    lines.push(`Full Name: ${data.name}`);
    if (data.business_name?.trim()) lines.push(`Business / Brand: ${data.business_name.trim()}`);
    lines.push(`Email Address: ${data.email}`);
    if (data.whatsapp_phone?.trim()) lines.push(`WhatsApp / Phone: ${data.whatsapp_phone.trim()}`);
    lines.push('');

    if (data.service) {
      lines.push(`Service Required: ${data.service}`);
      if (data.service === 'Other Service / Something Else' && data.service_other_description?.trim()) {
        lines.push(`Service Description: ${data.service_other_description.trim()}`);
      }
    }

    if (data.project_description?.trim()) {
      lines.push('');
      lines.push(`Project Description / Message:\n${data.project_description.trim()}`);
    }

    if (data.goals && data.goals.length > 0) {
      lines.push('');
      lines.push('Your Goals:');
      data.goals.forEach(g => {
        if (g === 'Other' && data.goals_other?.trim()) {
          lines.push(`• Other: ${data.goals_other.trim()}`);
        } else {
          lines.push(`• ${g}`);
        }
      });
    }

    if (data.features_needed && data.features_needed.length > 0) {
      lines.push('');
      lines.push('Features Needed:');
      data.features_needed.forEach(f => {
        if (f === 'Other Feature' && data.features_other?.trim()) {
          lines.push(`• Other: ${data.features_other.trim()}`);
        } else {
          lines.push(`• ${f}`);
        }
      });
    }

    if (data.has_existing_website) {
      lines.push('');
      lines.push(`Existing Website: ${data.has_existing_website}${data.has_existing_website === 'Yes' && data.existing_website_url ? ` (${data.existing_website_url.trim()})` : ''}`);
    }

    if (data.budget) {
      lines.push('');
      const budgetDisplay = data.budget === 'Custom Budget' && data.custom_budget?.trim() 
        ? `Custom Budget: ${data.custom_budget.trim()}`
        : data.budget;
      lines.push(`Estimated Budget: ${budgetDisplay}`);
    }

    if (data.timeline) {
      lines.push('');
      const timelineDisplay = data.timeline === 'Other' && data.timeline_other?.trim()
        ? `Other: ${data.timeline_other.trim()}`
        : data.timeline;
      lines.push(`Preferred Timeline: ${timelineDisplay}`);
    }

    if (data.additional_info?.trim()) {
      lines.push('');
      lines.push(`Additional Information:\n${data.additional_info.trim()}`);
    }

    return lines.join('\n');
  };

  // Validation
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Please enter your full name.';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address (e.g. name@domain.com).';
    }

    if (!formData.enquiry_type) {
      newErrors.enquiry_type = 'Please select an enquiry type.';
    }

    // Project enquiries require service & description
    if (isProjectEnquiry) {
      if (!formData.service) {
        newErrors.service = 'Please select which service you need.';
      } else if (formData.service === 'Other Service / Something Else' && !formData.service_other_description.trim()) {
        newErrors.service_other_description = 'Please describe the required service.';
      }

      if (!formData.project_description.trim()) {
        newErrors.project_description = 'Please tell us about your project requirements.';
      }
    } else {
      // General or non-project enquiries require their message/question
      if (!formData.project_description.trim()) {
        newErrors.project_description = 'Please enter your enquiry or message details.';
      }
    }

    // Validate website URL if provided
    if (formData.has_existing_website === 'Yes' && formData.existing_website_url.trim()) {
      const url = formData.existing_website_url.trim();
      const urlPattern = /^(https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/.*)?$/;
      if (!urlPattern.test(url)) {
        newErrors.existing_website_url = 'Please enter a valid website address (e.g. yourwebsite.com or https://yourwebsite.com).';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    if (!validateForm()) {
      // Scroll to top of form
      const el = document.getElementById('contact-form-container');
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }

    setIsSubmitting(true);

    try {
      // Construct submission payload
      const submissionPayload: Omit<ContactSubmission, 'id' | 'created_at' | 'status'> = {
        name: formData.name.trim(),
        business_name: formData.business_name.trim() || undefined,
        email: formData.email.trim(),
        whatsapp_phone: formData.whatsapp_phone.trim() || undefined,
        enquiry_type: formData.enquiry_type,
        service: isProjectEnquiry ? formData.service : undefined,
        service_other_description: (isProjectEnquiry && formData.service === 'Other Service / Something Else') ? formData.service_other_description.trim() : undefined,
        project_description: formData.project_description.trim(),
        goals: isProjectEnquiry && formData.goals.length > 0 ? formData.goals : undefined,
        goals_other: (isProjectEnquiry && formData.goals_other.trim()) ? formData.goals_other.trim() : undefined,
        features_needed: isProjectEnquiry && formData.features_needed.length > 0 ? formData.features_needed : undefined,
        features_other: (isProjectEnquiry && formData.features_other.trim()) ? formData.features_other.trim() : undefined,
        has_existing_website: isProjectEnquiry && formData.has_existing_website ? formData.has_existing_website : undefined,
        existing_website_url: (isProjectEnquiry && formData.has_existing_website === 'Yes' && formData.existing_website_url.trim()) ? formData.existing_website_url.trim() : undefined,
        budget: isProjectEnquiry && formData.budget ? formData.budget : undefined,
        custom_budget: (isProjectEnquiry && formData.budget === 'Custom Budget' && formData.custom_budget.trim()) ? formData.custom_budget.trim() : undefined,
        timeline: isProjectEnquiry && formData.timeline ? formData.timeline : undefined,
        timeline_other: (isProjectEnquiry && formData.timeline === 'Other' && formData.timeline_other.trim()) ? formData.timeline_other.trim() : undefined,
        additional_info: formData.additional_info.trim() || undefined
      };

      // Save to database & server
      await dataStore.saveSubmission(submissionPayload);

      // Build prepared message for modal
      const summaryMsg = buildEnquirySummaryMessage(formData);
      setSavedEnquirySummary(summaryMsg);

      // Open Thank You Pop-up
      setShowThankYouModal(true);
    } catch (err: any) {
      console.error('Contact submission error:', err);
      setSubmitError('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // WhatsApp & Email Redirect Handlers from modal
  const openPreparedWhatsApp = () => {
    const encoded = encodeURIComponent(savedEnquirySummary);
    window.open(`https://wa.me/923295430114?text=${encoded}`, '_blank');
  };

  const openPreparedEmail = () => {
    const subject = encodeURIComponent(`Website Enquiry — Janah Studio (${formData.name})`);
    const body = encodeURIComponent(savedEnquirySummary);
    window.location.href = `mailto:${studioEmail}?subject=${subject}&body=${body}`;
  };

  const resetForm = () => {
    setFormData({
      name: '',
      business_name: '',
      email: '',
      whatsapp_phone: '',
      enquiry_type: 'Start a New Project',
      service: 'Website Development',
      service_other_description: '',
      project_description: '',
      goals: [],
      goals_other: '',
      features_needed: [],
      features_other: '',
      has_existing_website: '',
      existing_website_url: '',
      budget: '',
      custom_budget: '',
      timeline: '',
      timeline_other: '',
      additional_info: ''
    });
    setErrors({});
    setShowThankYouModal(false);
  };

  return (
    <div className="space-y-16 pb-20 pt-2">
      <SEO
        title="Contact Janah Studio – Start Your Website Project"
        description="Tell us about your website needs and project goals. We review your enquiry and provide clear recommendations via WhatsApp and email."
        keywords="contact Janah Studio, hire web developer, website development enquiry, start website project, web consultation"
        canonicalPath="/contact"
        structuredData={{
          "@context": "https://schema.org",
          "@type": "ContactPage",
          "name": "Contact Janah Studio",
          "url": "https://janahstudio.com/contact",
          "description": "Start a website development project or enquire about custom websites with Janah Studio."
        }}
      />
      
      {/* 1. Hero Heading Section */}
      <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] pt-2 pb-10 sm:pb-14 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30">
        <div className="relative z-10 max-w-3xl space-y-2">
          <AnimatedHeading
            text="Let's Talk About Your Website Project"
            as="h1"
            className="text-4xl sm:text-5xl font-extrabold text-[#17202A] tracking-tight leading-tight"
          />
          <div className="w-36 h-3 mt-1 mb-2">
            <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
              <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <defs>
                <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#30E1CE" />
                  <stop offset="50%" stopColor="#1876C7" />
                  <stop offset="100%" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <AnimatedDescription
            text="Tell us about your business, your website needs, and what you want to achieve. We'll review your enquiry and contact you about the next steps."
            className="text-base sm:text-lg text-[#66727D] leading-relaxed"
            delay={0.2}
          />
        </div>
      </section>

      {/* 2. Form Section */}
      <AnimatedSection>
        <section id="contact-form-container" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-3xl border border-[#E2E8EA] shadow-xl overflow-hidden">
            
            {/* Form Top Banner */}
            <div className="bg-gradient-to-r from-[#241F1C] to-[#17202A] p-6 sm:p-8 text-white">
              <div className="flex items-center gap-2.5 mb-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-[#30E1CE] to-[#1876C7] flex items-center justify-center text-white">
                  <Briefcase className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold tracking-wider text-[#30E1CE] uppercase">
                  Janah Studio Enquiry Form
                </span>
              </div>
              <h2 className="text-xl sm:text-3xl font-bold tracking-tight">
                Project & Service Enquiry
              </h2>
              <p className="text-xs sm:text-sm text-gray-300 mt-1 max-w-2xl">
                Please provide your details below. We typically respond within 24–48 hours with project insights.
              </p>
            </div>

            {/* Error Banner */}
            {submitError && (
              <div className="mx-6 sm:mx-10 mt-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span>{submitError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="p-6 sm:p-10 space-y-9">

              {/* SECTION A: Your Details */}
              <div className="space-y-4">
                <div className="border-b border-[#E2E8EA] pb-2 flex items-center justify-between">
                  <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">1</span>
                    <span>Your Details</span>
                  </h3>
                  <span className="text-[11px] text-[#66727D]">* Required Fields</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Full Name */}
                  <div>
                    <label className="block text-xs font-medium text-[#17202A] mb-1">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={e => {
                        setFormData({ ...formData, name: e.target.value });
                        if (errors.name) setErrors(prev => ({ ...prev, name: '' }));
                      }}
                      placeholder="e.g. Muhammad Ahmad"
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-none transition-all ${
                        errors.name 
                          ? 'border-red-500 ring-2 ring-red-100 bg-red-50/20' 
                          : 'border-[#E2E8EA] bg-white focus:ring-2 focus:ring-[#1876C7]/20 focus:border-[#1876C7]'
                      }`}
                    />
                    {errors.name && (
                      <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1">
                        <AlertCircle className="w-3 h-3 shrink-0" /> {errors.name}
                      </p>
                    )}
                  </div>

                  {/* Business / Brand Name */}
                  <div>
                    <label className="block text-xs font-medium text-[#17202A] mb-1">
                      Business / Brand Name <span className="text-[#66727D] font-normal">(Optional)</span>
                    </label>
                    <input
                      type="text"
                      name="business_name"
                      value={formData.business_name}
                      onChange={e => setFormData({ ...formData, business_name: e.target.value })}
                      placeholder="e.g. Acme Studio or Brand Name"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20 focus:border-[#1876C7] transition-all"
                    />
                  </div>

                  {/* Email Address */}
                  <div>
                    <label className="block text-xs font-medium text-[#17202A] mb-1">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={e => {
                        setFormData({ ...formData, email: e.target.value });
                        if (errors.email) setErrors(prev => ({ ...prev, email: '' }));
                      }}
                      placeholder="e.g. ahmad@example.com"
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-none transition-all ${
                        errors.email 
                          ? 'border-red-500 ring-2 ring-red-100 bg-red-50/20' 
                          : 'border-[#E2E8EA] bg-white focus:ring-2 focus:ring-[#1876C7]/20 focus:border-[#1876C7]'
                      }`}
                    />
                    {errors.email && (
                      <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1">
                        <AlertCircle className="w-3 h-3 shrink-0" /> {errors.email}
                      </p>
                    )}
                  </div>

                  {/* WhatsApp / Phone Number */}
                  <div>
                    <label className="block text-xs font-medium text-[#17202A] mb-1">
                      WhatsApp / Phone Number <span className="text-[#66727D] font-normal">(Optional)</span>
                    </label>
                    <input
                      type="text"
                      name="whatsapp_phone"
                      value={formData.whatsapp_phone}
                      onChange={e => setFormData({ ...formData, whatsapp_phone: e.target.value })}
                      placeholder="e.g. +92 300 1234567"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20 focus:border-[#1876C7] transition-all"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION B: Enquiry Type */}
              <div className="space-y-4">
                <div className="border-b border-[#E2E8EA] pb-2">
                  <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">2</span>
                    <span>What Is Your Enquiry About? <span className="text-red-500">*</span></span>
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
                  {ENQUIRY_TYPES.map((type) => {
                    const isSelected = formData.enquiry_type === type;
                    return (
                      <button
                        type="button"
                        key={type}
                        onClick={() => {
                          setFormData({ ...formData, enquiry_type: type });
                          if (errors.enquiry_type) setErrors(prev => ({ ...prev, enquiry_type: '' }));
                        }}
                        className={`p-3 rounded-xl border text-left text-xs font-semibold transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-gradient-to-r from-[#30E1CE]/15 to-[#1876C7]/15 border-[#1876C7] text-[#1876C7] shadow-xs'
                            : 'bg-white border-[#E2E8EA] text-[#17202A] hover:bg-[#F8FAFA] hover:border-gray-300'
                        }`}
                      >
                        <span>{type}</span>
                        {isSelected && <Check className="w-4 h-4 text-[#1876C7] shrink-0 ml-1" />}
                      </button>
                    );
                  })}
                </div>
                {errors.enquiry_type && (
                  <p className="text-[11px] text-red-500 font-medium flex items-center gap-1">
                    <AlertCircle className="w-3 h-3 shrink-0" /> {errors.enquiry_type}
                  </p>
                )}
              </div>

              {/* SECTION C: Service Required (Conditionally shown/required for project enquiries) */}
              {isProjectEnquiry && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="border-b border-[#E2E8EA] pb-2">
                    <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">3</span>
                      <span>Which Service Do You Need? <span className="text-red-500">*</span></span>
                    </h3>
                  </div>

                  {/* Core Services Group */}
                  <div>
                    <span className="text-[11px] font-bold text-[#66727D] uppercase tracking-wider block mb-2">
                      Core Website Services
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                      {CORE_SERVICES.map((srv) => {
                        const isSelected = formData.service === srv;
                        return (
                          <button
                            type="button"
                            key={srv}
                            onClick={() => {
                              setFormData({ ...formData, service: srv });
                              if (errors.service) setErrors(prev => ({ ...prev, service: '' }));
                            }}
                            className={`p-3 rounded-xl border text-left text-xs font-semibold transition-all flex items-center justify-between ${
                              isSelected
                                ? 'bg-gradient-to-r from-[#30E1CE]/15 to-[#1876C7]/15 border-[#1876C7] text-[#1876C7] shadow-xs'
                                : 'bg-white border-[#E2E8EA] text-[#17202A] hover:bg-[#F8FAFA] hover:border-gray-300'
                            }`}
                          >
                            <span>{srv}</span>
                            {isSelected && <Check className="w-4 h-4 text-[#1876C7] shrink-0 ml-1" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Additional Needs Group */}
                  <div className="pt-2">
                    <span className="text-[11px] font-bold text-[#66727D] uppercase tracking-wider block mb-2">
                      Additional Support & Technical Needs
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                      {ADDITIONAL_NEEDS.map((need) => {
                        const isSelected = formData.service === need;
                        return (
                          <button
                            type="button"
                            key={need}
                            onClick={() => {
                              setFormData({ ...formData, service: need });
                              if (errors.service) setErrors(prev => ({ ...prev, service: '' }));
                            }}
                            className={`p-3 rounded-xl border text-left text-xs font-semibold transition-all flex items-center justify-between ${
                              isSelected
                                ? 'bg-gradient-to-r from-[#30E1CE]/15 to-[#1876C7]/15 border-[#1876C7] text-[#1876C7] shadow-xs'
                                : 'bg-white border-[#E2E8EA] text-[#17202A] hover:bg-[#F8FAFA] hover:border-gray-300'
                            }`}
                          >
                            <span>{need}</span>
                            {isSelected && <Check className="w-4 h-4 text-[#1876C7] shrink-0 ml-1" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Other service description */}
                  {formData.service === 'Other Service / Something Else' && (
                    <div className="mt-3 animate-in fade-in duration-200">
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        Please Describe the Required Service <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.service_other_description}
                        onChange={e => {
                          setFormData({ ...formData, service_other_description: e.target.value });
                          if (errors.service_other_description) setErrors(prev => ({ ...prev, service_other_description: '' }));
                        }}
                        placeholder="e.g. Custom API integration, web portal, or specific tool..."
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20 focus:border-[#1876C7]"
                      />
                      {errors.service_other_description && (
                        <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 shrink-0" /> {errors.service_other_description}
                        </p>
                      )}
                    </div>
                  )}

                  {errors.service && (
                    <p className="text-[11px] text-red-500 font-medium flex items-center gap-1">
                      <AlertCircle className="w-3 h-3 shrink-0" /> {errors.service}
                    </p>
                  )}
                </div>
              )}

              {/* SECTION D: Project Information (Or Enquiry Message for non-project types) */}
              <div className="space-y-4">
                <div className="border-b border-[#E2E8EA] pb-2">
                  <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">
                      {isProjectEnquiry ? '4' : '3'}
                    </span>
                    <span>
                      {isProjectEnquiry ? 'Tell Us About Your Project' : 'Tell Us About Your Enquiry'} <span className="text-red-500">*</span>
                    </span>
                  </h3>
                </div>

                {/* Multiline Project Description */}
                <div>
                  <textarea
                    rows={4}
                    name="project_description"
                    value={formData.project_description}
                    onChange={e => {
                      setFormData({ ...formData, project_description: e.target.value });
                      if (errors.project_description) setErrors(prev => ({ ...prev, project_description: '' }));
                    }}
                    placeholder={
                      isProjectEnquiry 
                        ? "Describe your business, what you need, and any important details about your project."
                        : "Describe your enquiry, question, or proposal in detail..."
                    }
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-none transition-all ${
                      errors.project_description 
                        ? 'border-red-500 ring-2 ring-red-100 bg-red-50/20' 
                        : 'border-[#E2E8EA] bg-white focus:ring-2 focus:ring-[#1876C7]/20 focus:border-[#1876C7]'
                    }`}
                  />
                  {errors.project_description && (
                    <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1">
                      <AlertCircle className="w-3 h-3 shrink-0" /> {errors.project_description}
                    </p>
                  )}
                </div>

                {/* Goals & Features (shown for project enquiries) */}
                {isProjectEnquiry && (
                  <div className="space-y-6 pt-2 animate-in fade-in duration-200">
                    {/* Your Goals */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs font-bold text-[#17202A]">
                          Your Goals <span className="text-[#66727D] font-normal">(Optional — select all that apply)</span>
                        </label>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {GOAL_OPTIONS.map((goal) => {
                          const isSelected = formData.goals.includes(goal);
                          return (
                            <button
                              type="button"
                              key={goal}
                              onClick={() => toggleGoal(goal)}
                              className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all flex items-center gap-1.5 ${
                                isSelected
                                  ? 'bg-[#1876C7] text-white border-[#1876C7] shadow-xs'
                                  : 'bg-white border-[#E2E8EA] text-[#66727D] hover:border-gray-300'
                              }`}
                            >
                              {isSelected && <Check className="w-3.5 h-3.5" />}
                              <span>{goal}</span>
                            </button>
                          );
                        })}
                      </div>

                      {formData.goals.includes('Other') && (
                        <div className="mt-2.5">
                          <input
                            type="text"
                            value={formData.goals_other}
                            onChange={e => setFormData({ ...formData, goals_other: e.target.value })}
                            placeholder="Please specify your other goal..."
                            className="w-full px-3.5 py-2 rounded-xl border border-[#E2E8EA] text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                          />
                        </div>
                      )}
                    </div>

                    {/* Features You Need */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-xs font-bold text-[#17202A]">
                          Features You Need <span className="text-[#66727D] font-normal">(Optional — select all that apply)</span>
                        </label>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {FEATURE_OPTIONS.map((feat) => {
                          const isSelected = formData.features_needed.includes(feat);
                          return (
                            <button
                              type="button"
                              key={feat}
                              onClick={() => toggleFeature(feat)}
                              className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all flex items-center gap-1.5 ${
                                isSelected
                                  ? 'bg-[#1876C7] text-white border-[#1876C7] shadow-xs'
                                  : 'bg-white border-[#E2E8EA] text-[#66727D] hover:border-gray-300'
                              }`}
                            >
                              {isSelected && <Check className="w-3.5 h-3.5" />}
                              <span>{feat}</span>
                            </button>
                          );
                        })}
                      </div>

                      {formData.features_needed.includes('Other Feature') && (
                        <div className="mt-2.5">
                          <input
                            type="text"
                            value={formData.features_other}
                            onChange={e => setFormData({ ...formData, features_other: e.target.value })}
                            placeholder="Please specify other feature..."
                            className="w-full px-3.5 py-2 rounded-xl border border-[#E2E8EA] text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* SECTION E: Existing Website (For project enquiries) */}
              {isProjectEnquiry && (
                <div className="space-y-4 animate-in fade-in duration-200">
                  <div className="border-b border-[#E2E8EA] pb-2">
                    <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">5</span>
                      <span>Do You Already Have a Website? <span className="text-[#66727D] font-normal lowercase">(Optional)</span></span>
                    </h3>
                  </div>

                  <div className="flex items-center gap-3">
                    {(['Yes', 'No', 'Not Sure'] as const).map((opt) => (
                      <button
                        type="button"
                        key={opt}
                        onClick={() => {
                          setFormData({ ...formData, has_existing_website: opt });
                          if (opt !== 'Yes') setFormData(prev => ({ ...prev, existing_website_url: '' }));
                        }}
                        className={`px-5 py-2 rounded-xl border text-xs font-semibold transition-all ${
                          formData.has_existing_website === opt
                            ? 'bg-[#1876C7] text-white border-[#1876C7] shadow-xs'
                            : 'bg-white border-[#E2E8EA] text-[#17202A] hover:bg-[#F8FAFA]'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>

                  {formData.has_existing_website === 'Yes' && (
                    <div className="mt-3 animate-in fade-in duration-200">
                      <label className="block text-xs font-medium text-[#17202A] mb-1">
                        Existing Website URL <span className="text-[#66727D] font-normal">(e.g. yourbusiness.com)</span>
                      </label>
                      <input
                        type="text"
                        value={formData.existing_website_url}
                        onChange={e => {
                          setFormData({ ...formData, existing_website_url: e.target.value });
                          if (errors.existing_website_url) setErrors(prev => ({ ...prev, existing_website_url: '' }));
                        }}
                        placeholder="https://yourwebsite.com"
                        className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-none transition-all ${
                          errors.existing_website_url 
                            ? 'border-red-500 ring-2 ring-red-100 bg-red-50/20' 
                            : 'border-[#E2E8EA] bg-white focus:ring-2 focus:ring-[#1876C7]/20 focus:border-[#1876C7]'
                        }`}
                      />
                      {errors.existing_website_url && (
                        <p className="text-[11px] text-red-500 mt-1 font-medium flex items-center gap-1">
                          <AlertCircle className="w-3 h-3 shrink-0" /> {errors.existing_website_url}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* SECTION F: Budget and Timeline (For project enquiries) */}
              {isProjectEnquiry && (
                <div className="space-y-6 animate-in fade-in duration-200">
                  <div className="border-b border-[#E2E8EA] pb-2">
                    <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">6</span>
                      <span>Budget & Timeline <span className="text-[#66727D] font-normal lowercase">(Optional)</span></span>
                    </h3>
                  </div>

                  {/* Estimated Budget */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-[#17202A]">
                      Estimated Budget
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {BUDGET_OPTIONS.map((bgt) => {
                        const isSelected = formData.budget === bgt;
                        return (
                          <button
                            type="button"
                            key={bgt}
                            onClick={() => {
                              setFormData({ ...formData, budget: bgt });
                              if (bgt !== 'Custom Budget') setFormData(prev => ({ ...prev, custom_budget: '' }));
                            }}
                            className={`p-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                              isSelected
                                ? 'bg-[#1876C7] text-white border-[#1876C7] shadow-xs'
                                : 'bg-white border-[#E2E8EA] text-[#17202A] hover:bg-[#F8FAFA]'
                            }`}
                          >
                            {bgt}
                          </button>
                        );
                      })}
                    </div>

                    {formData.budget === 'Custom Budget' && (
                      <div className="mt-2.5 animate-in fade-in duration-200">
                        <input
                          type="text"
                          value={formData.custom_budget}
                          onChange={e => setFormData({ ...formData, custom_budget: e.target.value })}
                          placeholder="Enter your budget or preferred currency (e.g. PKR 120,000 or $500 USD)..."
                          className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                        />
                      </div>
                    )}
                  </div>

                  {/* Preferred Timeline */}
                  <div className="space-y-2 pt-2">
                    <label className="block text-xs font-bold text-[#17202A]">
                      Preferred Timeline
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {TIMELINE_OPTIONS.map((time) => {
                        const isSelected = formData.timeline === time;
                        return (
                          <button
                            type="button"
                            key={time}
                            onClick={() => {
                              setFormData({ ...formData, timeline: time });
                              if (time !== 'Other') setFormData(prev => ({ ...prev, timeline_other: '' }));
                            }}
                            className={`p-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                              isSelected
                                ? 'bg-[#1876C7] text-white border-[#1876C7] shadow-xs'
                                : 'bg-white border-[#E2E8EA] text-[#17202A] hover:bg-[#F8FAFA]'
                            }`}
                          >
                            {time}
                          </button>
                        );
                      })}
                    </div>

                    {formData.timeline === 'Other' && (
                      <div className="mt-2.5 animate-in fade-in duration-200">
                        <input
                          type="text"
                          value={formData.timeline_other}
                          onChange={e => setFormData({ ...formData, timeline_other: e.target.value })}
                          placeholder="Please specify your desired timeline..."
                          className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* SECTION G: Additional Information */}
              <div className="space-y-3">
                <div className="border-b border-[#E2E8EA] pb-2">
                  <h3 className="text-sm font-bold tracking-wide uppercase text-[#17202A] flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#1876C7] text-white text-[10px] flex items-center justify-center font-bold">
                      {isProjectEnquiry ? '7' : '4'}
                    </span>
                    <span>Anything Else We Should Know? <span className="text-[#66727D] font-normal lowercase">(Optional)</span></span>
                  </h3>
                </div>

                <textarea
                  rows={3}
                  name="additional_info"
                  value={formData.additional_info}
                  onChange={e => setFormData({ ...formData, additional_info: e.target.value })}
                  placeholder="Any other requirements, questions, design preferences, or useful information..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20 focus:border-[#1876C7] transition-all"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <Button
                  type="submit"
                  variant="primary"
                  disabled={isSubmitting}
                  className="w-full py-4 text-sm font-bold shadow-lg"
                >
                  <span>{isSubmitting ? 'Submitting Enquiry...' : 'Submit Enquiry'}</span>
                  <Send className="w-4 h-4 ml-2" />
                </Button>
              </div>

            </form>
          </div>
        </section>
      </AnimatedSection>

      {/* 3. Direct Contact Information Section (Always Present) */}
      <AnimatedSection delay={0.1}>
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 text-center">
          <div className="bg-white rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#E2E8EA] shadow-sm space-y-6">
            <h3 className="text-xl font-bold text-[#17202A]">Prefer Direct Communication?</h3>
            <p className="text-xs sm:text-sm text-[#66727D] max-w-xl mx-auto leading-relaxed">
              If you have quick questions or prefer not to fill out the form, you can contact us directly via WhatsApp or email anytime.
            </p>

            {/* Action Buttons in One Row */}
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <a
                href={generalWhatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="chat" className="flex items-center gap-2 px-6">
                  <MessageCircle className="w-4 h-4 text-white" />
                  <span>WhatsApp</span>
                </Button>
              </a>

              <a
                href={`mailto:${studioEmail}`}
              >
                <Button variant="outline" className="flex items-center gap-2 px-6 border-[#1876C7] text-[#1876C7]">
                  <Mail className="w-4 h-4 text-[#1876C7]" />
                  <span>Email</span>
                </Button>
              </a>
            </div>

            {/* Structured Contact Details Rows */}
            <div className="pt-6 border-t border-[#E2E8EA] grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
              <div className="p-4 rounded-tl-2xl rounded-br-2xl rounded-tr-none rounded-bl-none bg-[#F8FAFA] border border-[#E2E8EA] flex items-center gap-3 text-left">
                <div className="w-10 h-10 rounded-full bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-[#66727D] uppercase tracking-wider block">WhatsApp Support</span>
                  <a href={generalWhatsappUrl} target="_blank" rel="noopener noreferrer" className="text-sm font-bold text-[#17202A] hover:text-[#1876C7]">
                    +92 329 543 0114
                  </a>
                </div>
              </div>

              <div className="p-4 rounded-tl-2xl rounded-br-2xl rounded-tr-none rounded-bl-none bg-[#F8FAFA] border border-[#E2E8EA] flex items-center gap-3 text-left">
                <div className="w-10 h-10 rounded-full bg-[#1876C7]/10 text-[#1876C7] flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold text-[#66727D] uppercase tracking-wider block">Official Email</span>
                  <a href={`mailto:${studioEmail}`} className="text-sm font-bold text-[#17202A] hover:text-[#1876C7] break-all">
                    {studioEmail}
                  </a>
                </div>
              </div>
            </div>

          </div>
        </section>
      </AnimatedSection>

      {/* 4. Contact Form Thank You Pop-up Modal (Section 7 & 8) */}
      {showThankYouModal && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-lg bg-white rounded-3xl border border-[#E2E8EA] shadow-2xl p-6 sm:p-8 text-center animate-in zoom-in-95 duration-200 max-h-[92vh] overflow-y-auto">
            
            {/* Top Close Button */}
            <button
              type="button"
              onClick={() => setShowThankYouModal(false)}
              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-xl transition-colors"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Success Icon */}
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-3 shadow-xs">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            {/* Title */}
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#17202A] tracking-tight">
              Thank You for Contacting Janah Studio!
            </h2>

            {/* Message Body */}
            <div className="space-y-2 mt-3 text-xs sm:text-sm text-[#66727D] leading-relaxed">
              <p>
                Your enquiry has been received successfully. Thank you for your time and for sharing your requirements with us.
              </p>
              <p className="font-medium text-[#17202A]">
                We'll review your enquiry and get back to you within 24–48 hours.
              </p>
              <p className="text-xs text-gray-500 pt-1">
                Need a faster response? Send your enquiry directly through WhatsApp or Email for a quicker response.
              </p>
            </div>

            {/* Prepared Actions: WhatsApp and Email Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mt-5">
              <button
                type="button"
                onClick={openPreparedWhatsApp}
                className="h-11 flex items-center justify-center gap-2 rounded-tl-[12px] rounded-br-[12px] bg-gradient-to-r from-[#25D366] to-[#128C7E] text-white text-xs font-bold shadow-[0_3px_0_#075E54] hover:brightness-105 active:translate-y-0.5 active:shadow-none transition-all cursor-pointer"
                title="Send Enquiry on WhatsApp"
              >
                <MessageCircle className="w-4 h-4 shrink-0" />
                <span>WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={openPreparedEmail}
                className="h-11 flex items-center justify-center gap-2 rounded-tl-[12px] rounded-br-[12px] bg-gradient-to-r from-[#1C2533] to-[#247BC1] text-white text-xs font-bold shadow-[0_3px_0_#000000] hover:brightness-105 active:translate-y-0.5 active:shadow-none transition-all cursor-pointer"
                title="Send Enquiry via Email"
              >
                <Mail className="w-4 h-4 shrink-0" />
                <span>Email</span>
              </button>
            </div>

            {/* Closing Text */}
            <div className="mt-5 pt-4 border-t border-[#E2E8EA] text-xs text-[#66727D] space-y-1">
              <p>
                If you have any additional questions, feel free to contact us directly.
              </p>
              <p className="font-semibold text-[#1876C7]">
                Thank you for choosing Janah Studio!
              </p>
            </div>

            {/* Dismiss Buttons */}
            <div className="mt-4 flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={resetForm}
                className="text-xs font-semibold text-gray-500 hover:text-gray-800 px-3 py-1.5 rounded-lg hover:bg-gray-100 transition-colors"
              >
                Submit Another Enquiry
              </button>
              <span className="text-gray-300">•</span>
              <button
                type="button"
                onClick={() => navigate('/')}
                className="text-xs font-semibold text-[#1876C7] hover:underline px-3 py-1.5"
              >
                Return to Homepage
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
