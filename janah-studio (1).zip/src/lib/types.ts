export interface ServiceItem {
  id: string;
  title: string;
  short_description: string;
  full_description: string;
  features: string[];
  order_index: number;
  is_active: boolean;
  image_url?: string;
}

export interface PricingPackage {
  id: string;
  package_name: string;
  starting_price: string;
  billing_type?: string;
  description: string;
  features: string[];
  order_index: number;
  is_active: boolean;
  category: 'website' | 'ecommerce' | 'maintenance' | 'custom';
}

export interface PortfolioProject {
  id: string;
  project_name: string;
  category: 'Websites' | 'E-commerce' | 'Landing Pages' | 'Redesigns' | 'Personal Portfolios' | 'Other';
  short_description: string;
  image_url: string;
  project_url?: string;
  project_type: 'Client Project' | 'Demo' | 'Concept';
  order_index: number;
  is_active: boolean;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: string;
  order_index: number;
  is_active: boolean;
}

export interface ContactSubmission {
  id: string;
  // A. Your Details
  name: string;
  business_name?: string;
  email: string;
  whatsapp_phone?: string;

  // B. Enquiry Type
  enquiry_type: string;

  // C. Service Required
  service?: string;
  service_other_description?: string;

  // D. Project Information
  project_description: string;
  goals?: string[] | string;
  goals_other?: string;
  features_needed?: string[] | string;
  features_other?: string;

  // E. Existing Website
  has_existing_website?: 'Yes' | 'No' | 'Not Sure';
  existing_website_url?: string;

  // F. Budget and Timeline
  budget?: string;
  custom_budget?: string;
  timeline?: string;
  timeline_other?: string;

  // G. Additional Information
  additional_info?: string;

  // Metadata
  status: 'New' | 'Contacted' | 'In Discussion' | 'Converted' | 'Closed';
  created_at: string;
}

export interface SiteSettings {
  business_name: string;
  contact_email: string;
  whatsapp_number: string;
  social_youtube?: string;
  social_facebook?: string;
  social_instagram?: string;
  social_tiktok?: string;
  global_cta_text: string;
  secondary_cta_text: string;
}

export interface TestimonialItem {
  id: string;
  quote: string;
  client_name: string;
  role: string;
  is_active: boolean;
}

export interface StoreProduct {
  id: string;
  name: string;
  price: number;
  original_price?: number;
  description: string;
  category: string;
  image_url: string;
  stock_quantity: number;
  in_stock: boolean;
  stock_status?: 'In Stock' | 'Low Stock' | 'Out of Stock';
  sku?: string;
  is_active: boolean;
  created_at: string;
}

export interface StoreOrderItem {
  product_id: string;
  product_name: string;
  price: number;
  quantity: number;
  image_url?: string;
}

export interface StoreOrder {
  id: string;
  order_number: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  shipping_address: string;
  city?: string;
  items: StoreOrderItem[];
  total_amount: number;
  payment_method: 'Cash on Delivery (COD)' | 'Bank Transfer' | 'Online Payment Gateway';
  status: 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
  tracking_number?: string;
  courier?: string;
  coupon_code?: string;
  discount_amount?: number;
  notes?: string;
  created_at: string;
}

export interface StoreCoupon {
  id: string;
  code: string;
  discount_percentage: number;
  is_active: boolean;
  min_order_amount?: number;
  expiry_date?: string;
}

export interface CareerApplication {
  id: string;
  reference_id: string;
  full_name: string;
  email: string;
  phone: string;
  location: string;
  position: string;
  experience_level: string;
  years_experience: number;
  work_types: string[];
  skills: string[];
  lead_sources?: string[];
  custom_skills?: string;
  portfolio_url?: string;
  social_url?: string;
  github_url?: string;
  linkedin_url?: string;
  previous_experience?: string;
  bank_name?: string;
  account_holder_name?: string;
  account_number?: string;
  earliest_start_date?: string;
  expected_rate?: string;
  cover_letter?: string;
  additional_message?: string;
  status: 'Pending' | 'Reviewing' | 'Shortlisted' | 'Interviewed' | 'Rejected' | 'Hired';
  saved_to_google_sheets: boolean;
  google_sheets_row?: number;
  created_at: string;
}

export interface GoogleSheetsConfig {
  spreadsheet_id: string;
  sheet_name: string;
  is_connected: boolean;
  connected_email?: string;
  spreadsheet_url?: string;
  last_synced_at?: string;
  total_synced_rows: number;
}
