export interface NotificationPreferences {
  email_on_new_submission: boolean;
  email_on_system_announcement: boolean;
  admin_notification_email: string;
  daily_digest: boolean;
}

export const DEFAULT_NOTIFICATION_PREFERENCES: NotificationPreferences = {
  email_on_new_submission: true,
  email_on_system_announcement: true,
  admin_notification_email: 'janahstudio.official@gmail.com',
  daily_digest: false,
};

export const emailService = {
  getPreferences(): NotificationPreferences {
    try {
      const stored = localStorage.getItem('janah_notification_preferences');
      return stored ? JSON.parse(stored) : DEFAULT_NOTIFICATION_PREFERENCES;
    } catch {
      return DEFAULT_NOTIFICATION_PREFERENCES;
    }
  },

  savePreferences(prefs: NotificationPreferences): void {
    try {
      localStorage.setItem('janah_notification_preferences', JSON.stringify(prefs));
    } catch (e) {
      console.error('Failed to save notification preferences', e);
    }
  },

  async sendEmailNotification(subject: string, message: string, recipient?: string): Promise<{ success: boolean; error?: string }> {
    const prefs = this.getPreferences();
    const targetEmail = recipient || prefs.admin_notification_email;

    try {
      // Simulate secure email dispatch via Supabase / Webhook / SMTP proxy
      console.log(`[Email Dispatch] Sending to ${targetEmail}: "${subject}" - "${message}"`);
      
      // Log notification event in local storage audit trail
      const logs = this.getNotificationLogs();
      const newLog = {
        id: `notif-${Date.now()}`,
        timestamp: new Date().toISOString(),
        subject,
        recipient: targetEmail,
        status: 'Sent'
      };
      localStorage.setItem('janah_notification_logs', JSON.stringify([newLog, ...logs.slice(0, 49)]));

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to send email' };
    }
  },

  getNotificationLogs(): Array<{ id: string; timestamp: string; subject: string; recipient: string; status: string }> {
    try {
      const logs = localStorage.getItem('janah_notification_logs');
      return logs ? JSON.parse(logs) : [];
    } catch {
      return [];
    }
  }
};
