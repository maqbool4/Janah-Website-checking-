import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://jvwsywbdczujbgsvxtti.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_5-1VmZeK-zJbQ8MG_-Zqkw_pVjQFt2p';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
