import { supabase } from './supabase';
import { emailService } from './emailService';
import { 
  INITIAL_SERVICES, 
  INITIAL_PRICING, 
  INITIAL_PORTFOLIO, 
  INITIAL_FAQS, 
  INITIAL_TESTIMONIALS, 
  INITIAL_SETTINGS,
  INITIAL_PRODUCTS,
  INITIAL_ORDERS,
  INITIAL_COUPONS
} from './seedData';
import { 
  ServiceItem, 
  PricingPackage, 
  PortfolioProject, 
  FaqItem, 
  TestimonialItem, 
  SiteSettings, 
  ContactSubmission,
  StoreProduct,
  StoreOrder,
  StoreCoupon,
  CareerApplication,
  GoogleSheetsConfig
} from './types';

// Helper for LocalStorage fallback
const getStorageItem = <T>(key: string, fallback: T): T => {
  try {
    const item = localStorage.getItem(`janah_${key}`);
    if (!item) {
      localStorage.setItem(`janah_${key}`, JSON.stringify(fallback));
      return fallback;
    }
    return JSON.parse(item);
  } catch {
    return fallback;
  }
};

const setStorageItem = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(`janah_${key}`, JSON.stringify(value));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('janah_store_updated', { detail: { key } }));
    }
  } catch (e) {
    console.error('Error saving to localStorage', e);
  }
};

// Helper to race async calls with instant fallback
const fastFetch = async <T>(fetcher: () => Promise<T>, fallback: T, timeoutMs: number = 500): Promise<T> => {
  try {
    return await Promise.race([
      fetcher(),
      new Promise<T>((_, reject) => setTimeout(() => reject(new Error('timeout')), timeoutMs))
    ]);
  } catch {
    return fallback;
  }
};

export const dataStore = {
  // Synchronous instant getters for immediate frame-0 rendering
  getServicesSync(): ServiceItem[] {
    return getStorageItem('services', INITIAL_SERVICES);
  },
  getPricingSync(): PricingPackage[] {
    return getStorageItem('pricing', INITIAL_PRICING);
  },
  getPortfolioSync(): PortfolioProject[] {
    return getStorageItem<PortfolioProject[]>('portfolio', INITIAL_PORTFOLIO);
  },
  getFaqsSync(): FaqItem[] {
    const stored = getStorageItem<FaqItem[]>('faqs', INITIAL_FAQS);
    if (!stored || stored.length < 50) {
      setStorageItem('faqs', INITIAL_FAQS);
      return INITIAL_FAQS;
    }
    return stored;
  },
  getTestimonialsSync(): TestimonialItem[] {
    return getStorageItem('testimonials', INITIAL_TESTIMONIALS);
  },
  getSettingsSync(): SiteSettings {
    return getStorageItem('settings', INITIAL_SETTINGS);
  },
  getSubmissionsSync(): ContactSubmission[] {
    const raw = getStorageItem<ContactSubmission[]>('submissions', []);
    // Clean obsolete dummy test submissions
    const filtered = (raw || []).filter(s => s && s.name !== 'Ahmad Khan' && s.id !== 'sub-1');
    if (raw && raw.length !== filtered.length) {
      setStorageItem('submissions', filtered);
    }
    return filtered;
  },
  getProductsSync(): StoreProduct[] {
    return getStorageItem<StoreProduct[]>('store_products', INITIAL_PRODUCTS);
  },
  getOrdersSync(): StoreOrder[] {
    return getStorageItem<StoreOrder[]>('store_orders', INITIAL_ORDERS);
  },
  getCouponsSync(): StoreCoupon[] {
    return getStorageItem<StoreCoupon[]>('store_coupons', INITIAL_COUPONS);
  },

  async getServices(): Promise<ServiceItem[]> {
    const fallback = this.getServicesSync();
    return fastFetch(async () => {
      const { data, error } = await supabase.from('services').select('*').order('order_index');
      if (error || !data || data.length === 0) return fallback;
      return data as ServiceItem[];
    }, fallback);
  },

  async saveServices(services: ServiceItem[]): Promise<void> {
    setStorageItem('services', services);
    try {
      // Attempt upserting to Supabase if table exists
      for (const s of services) {
        await supabase.from('services').upsert(s);
      }
    } catch (e) {
      console.log('Supabase sync note (services):', e);
    }
  },

  async getPricing(): Promise<PricingPackage[]> {
    const fallback = this.getPricingSync();
    return fastFetch(async () => {
      const { data, error } = await supabase.from('pricing_packages').select('*').order('order_index');
      if (error || !data || data.length === 0) return fallback;
      return data as PricingPackage[];
    }, fallback);
  },

  async savePricing(pricing: PricingPackage[]): Promise<void> {
    setStorageItem('pricing', pricing);
    try {
      for (const p of pricing) {
        await supabase.from('pricing_packages').upsert(p);
      }
    } catch (e) {
      console.log('Supabase sync note (pricing):', e);
    }
  },

  async getPortfolio(): Promise<PortfolioProject[]> {
    const fallback = this.getPortfolioSync();
    return fastFetch(async () => {
      const { data, error } = await supabase.from('portfolio_projects').select('*').order('order_index');
      if (error || !data || data.length === 0) {
        return fallback;
      }
      return data as PortfolioProject[];
    }, fallback);
  },

  async savePortfolio(portfolio: PortfolioProject[]): Promise<void> {
    setStorageItem('portfolio', portfolio);
    try {
      for (const p of portfolio) {
        await supabase.from('portfolio_projects').upsert(p);
      }
    } catch (e) {
      console.log('Supabase sync note (portfolio):', e);
    }
  },

  async getFaqs(): Promise<FaqItem[]> {
    const fallback = this.getFaqsSync();
    return fastFetch(async () => {
      const { data, error } = await supabase.from('faqs').select('*').order('order_index');
      if (error || !data || data.length < 50) return fallback;
      return data as FaqItem[];
    }, fallback);
  },

  async saveFaqs(faqs: FaqItem[]): Promise<void> {
    setStorageItem('faqs', faqs);
    try {
      for (const f of faqs) {
        await supabase.from('faqs').upsert(f);
      }
    } catch (e) {
      console.log('Supabase sync note (faqs):', e);
    }
  },

  async getTestimonials(): Promise<TestimonialItem[]> {
    const fallback = this.getTestimonialsSync();
    return fastFetch(async () => {
      const { data, error } = await supabase.from('testimonials').select('*');
      if (error || !data || data.length === 0) return fallback;
      return data as TestimonialItem[];
    }, fallback);
  },

  async saveTestimonials(testimonials: TestimonialItem[]): Promise<void> {
    setStorageItem('testimonials', testimonials);
    try {
      for (const t of testimonials) {
        await supabase.from('testimonials').upsert(t);
      }
    } catch (e) {
      console.log('Supabase sync note (testimonials):', e);
    }
  },

  async getSettings(): Promise<SiteSettings> {
    const fallback = this.getSettingsSync();
    return fastFetch(async () => {
      const { data, error } = await supabase.from('site_settings').select('*').single();
      if (error || !data) return fallback;
      return data as SiteSettings;
    }, fallback);
  },

  async saveSettings(settings: SiteSettings): Promise<void> {
    setStorageItem('settings', settings);
    try {
      await supabase.from('site_settings').upsert({ id: 1, ...settings });
    } catch (e) {
      console.log('Supabase sync note (settings):', e);
    }
  },

  async getSubmissions(): Promise<ContactSubmission[]> {
    const fallback = this.getSubmissionsSync();
    try {
      // 1. Try server endpoint
      const response = await fetch('/api/contact/submissions');
      if (response.ok) {
        const json = await response.json();
        if (Array.isArray(json.submissions)) {
          // Sync with local storage
          setStorageItem('submissions', json.submissions);
          return json.submissions as ContactSubmission[];
        }
      }
    } catch (e) {
      // Ignore network error and continue to Supabase / fallback
    }

    try {
      // 2. Try Supabase
      const { data, error } = await supabase.from('contact_submissions').select('*').order('created_at', { ascending: false });
      if (!error && data && data.length > 0) {
        setStorageItem('submissions', data);
        return data as ContactSubmission[];
      }
    } catch {
      // Fallback
    }

    return fallback;
  },

  async saveSubmission(submission: Omit<ContactSubmission, 'id' | 'created_at' | 'status'>): Promise<{ success: boolean; id: string }> {
    const newSub: ContactSubmission = {
      ...submission,
      id: `enq-${Date.now()}`,
      status: 'New',
      created_at: new Date().toISOString()
    };
    
    // Save to local storage immediately
    const current = this.getSubmissionsSync();
    setStorageItem('submissions', [newSub, ...current]);

    // Save to server-side endpoint
    try {
      const resp = await fetch('/api/contact/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSub)
      });
      if (resp.ok) {
        const resJson = await resp.json();
        if (resJson.id) newSub.id = resJson.id;
      }
    } catch (err) {
      console.warn('Server contact submit note:', err);
    }

    // Try Supabase insert
    try {
      await supabase.from('contact_submissions').insert([newSub]);
    } catch (e) {
      console.warn('Supabase submission note:', e);
    }

    // Trigger Email Notification if enabled
    try {
      const prefs = emailService.getPreferences();
      if (prefs.email_on_new_submission) {
        await emailService.sendEmailNotification(
          `New Enquiry: ${newSub.name} - ${newSub.enquiry_type}`,
          `Enquiry Type: ${newSub.enquiry_type}\nName: ${newSub.name}\nEmail: ${newSub.email}\nPhone: ${newSub.whatsapp_phone || 'None'}\nService: ${newSub.service || 'None'}\nDescription: ${newSub.project_description}`
        );
      }
    } catch (e) {
      console.warn('Email notify error:', e);
    }

    return { success: true, id: newSub.id };
  },

  async updateSubmissionStatus(id: string, status: ContactSubmission['status']): Promise<void> {
    const current = await this.getSubmissions();
    const updated = current.map(s => s.id === id ? { ...s, status } : s);
    setStorageItem('submissions', updated);

    // Call server endpoint
    try {
      await fetch(`/api/contact/submissions/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
    } catch (err) {
      console.warn('Server status update note:', err);
    }

    try {
      await supabase.from('contact_submissions').update({ status }).eq('id', id);
    } catch (e) {
      console.log('Supabase status update note:', e);
    }
  },

  async deleteSubmission(id: string): Promise<void> {
    const current = await this.getSubmissions();
    const updated = current.filter(s => s.id !== id);
    setStorageItem('submissions', updated);

    try {
      await fetch(`/api/contact/submissions/${id}`, {
        method: 'DELETE'
      });
    } catch (err) {
      console.warn('Server delete note:', err);
    }

    try {
      await supabase.from('contact_submissions').delete().eq('id', id);
    } catch (e) {
      console.log('Supabase delete note:', e);
    }
  },

  // E-commerce Store Methods
  async getProducts(): Promise<StoreProduct[]> {
    const fallback = this.getProductsSync();
    return fastFetch(async () => {
      const { data, error } = await supabase.from('store_products').select('*').order('created_at', { ascending: false });
      if (error || !data || data.length === 0) return fallback;
      return data as StoreProduct[];
    }, fallback);
  },

  async saveProducts(products: StoreProduct[]): Promise<void> {
    setStorageItem('store_products', products);
    try {
      for (const p of products) {
        await supabase.from('store_products').upsert(p);
      }
    } catch (e) {
      console.log('Supabase products sync note:', e);
    }
  },

  async addProduct(productData: Omit<StoreProduct, 'id' | 'created_at'>): Promise<StoreProduct> {
    const newProduct: StoreProduct = {
      ...productData,
      id: `prod-${Date.now()}`,
      created_at: new Date().toISOString()
    };
    const current = await this.getProducts();
    const updated = [newProduct, ...current];
    await this.saveProducts(updated);
    return newProduct;
  },

  async updateProduct(id: string, updates: Partial<StoreProduct>): Promise<StoreProduct> {
    const current = await this.getProducts();
    let updatedProduct: StoreProduct | null = null;
    const updated = current.map(p => {
      if (p.id === id) {
        updatedProduct = { ...p, ...updates };
        return updatedProduct;
      }
      return p;
    });
    await this.saveProducts(updated);
    if (!updatedProduct) throw new Error('Product not found');
    return updatedProduct;
  },

  async deleteProduct(id: string): Promise<void> {
    const current = await this.getProducts();
    const updated = current.filter(p => p.id !== id);
    await this.saveProducts(updated);
  },

  async getOrders(): Promise<StoreOrder[]> {
    try {
      const { data, error } = await supabase.from('store_orders').select('*').order('created_at', { ascending: false });
      if (error || !data || data.length === 0) {
        return getStorageItem<StoreOrder[]>('store_orders', INITIAL_ORDERS);
      }
      return data as StoreOrder[];
    } catch {
      return getStorageItem<StoreOrder[]>('store_orders', INITIAL_ORDERS);
    }
  },

  async saveOrders(orders: StoreOrder[]): Promise<void> {
    setStorageItem('store_orders', orders);
    try {
      for (const o of orders) {
        await supabase.from('store_orders').upsert(o);
      }
    } catch (e) {
      console.log('Supabase orders sync note:', e);
    }
  },

  async createOrder(orderData: Omit<StoreOrder, 'id' | 'order_number' | 'created_at'>): Promise<StoreOrder> {
    const orderNumber = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOrder: StoreOrder = {
      ...orderData,
      id: `ord-${Date.now()}`,
      order_number: orderNumber,
      created_at: new Date().toISOString()
    };
    const current = await this.getOrders();
    const updated = [newOrder, ...current];
    await this.saveOrders(updated);

    // Update stock levels
    const products = await this.getProducts();
    const updatedProducts = products.map(prod => {
      const orderedItem = newOrder.items.find(i => i.product_id === prod.id);
      if (orderedItem) {
        const remainingStock = Math.max(0, prod.stock_quantity - orderedItem.quantity);
        return {
          ...prod,
          stock_quantity: remainingStock,
          in_stock: remainingStock > 0,
          stock_status: remainingStock <= 0 ? 'Out of Stock' : remainingStock < 10 ? 'Low Stock' : 'In Stock'
        };
      }
      return prod;
    });
    await this.saveProducts(updatedProducts as StoreProduct[]);

    return newOrder;
  },

  async updateOrderStatus(orderId: string, status: StoreOrder['status'], trackingNumber?: string, courier?: string): Promise<StoreOrder> {
    const current = await this.getOrders();
    let updatedOrder: StoreOrder | null = null;
    const updated = current.map(o => {
      if (o.id === orderId) {
        updatedOrder = {
          ...o,
          status,
          ...(trackingNumber ? { tracking_number: trackingNumber } : {}),
          ...(courier ? { courier: courier } : {})
        };
        return updatedOrder;
      }
      return o;
    });
    await this.saveOrders(updated);
    if (!updatedOrder) throw new Error('Order not found');
    return updatedOrder;
  },

  async getCoupons(): Promise<StoreCoupon[]> {
    return getStorageItem<StoreCoupon[]>('store_coupons', INITIAL_COUPONS);
  },

  async saveCoupons(coupons: StoreCoupon[]): Promise<void> {
    setStorageItem('store_coupons', coupons);
  },

  async addCoupon(couponData: Omit<StoreCoupon, 'id'>): Promise<StoreCoupon> {
    const newCoupon: StoreCoupon = {
      ...couponData,
      id: `c-${Date.now()}`
    };
    const current = await this.getCoupons();
    const updated = [newCoupon, ...current];
    await this.saveCoupons(updated);
    return newCoupon;
  },

  async deleteCoupon(id: string): Promise<void> {
    const current = await this.getCoupons();
    const updated = current.filter(c => c.id !== id);
    await this.saveCoupons(updated);
  },

  getApplicationsSync(): CareerApplication[] {
    const defaultApps: CareerApplication[] = [
      {
        id: 'app-1',
        reference_id: 'JS-REF-2026-1084',
        full_name: 'Maqbool Hussain',
        email: 'maqbool.hussain@gmail.com',
        phone: '+92 300 1234567',
        location: 'Pakistan',
        position: 'Lead Generation & Client Acquisition Partner',
        experience_level: 'Mid-Level (1-3 yrs)',
        years_experience: 2,
        work_types: ['Remote', 'Project-based'],
        skills: ['Lead Generation', 'Client Outreach', 'Google Maps Research'],
        lead_sources: ['Google Maps', 'Google Search', 'Facebook'],
        custom_skills: 'B2B outreach & client communication',
        portfolio_url: 'https://drive.google.com/file/d/example-cv/view',
        social_url: 'https://instagram.com/maqbool_leads',
        bank_name: 'Meezan Bank',
        earliest_start_date: 'Immediately',
        expected_rate: 'PKR 10,000 / month',
        cover_letter: 'Specialized in researching prospective businesses via Google Maps and initiating professional WhatsApp/social outreach for Janah Studio services.',
        status: 'Reviewing',
        saved_to_google_sheets: false,
        google_sheets_row: 2,
        created_at: new Date(Date.now() - 86400000).toISOString()
      }
    ];
    return getStorageItem<CareerApplication[]>('career_applications_v2', defaultApps);
  },

  async getApplications(): Promise<CareerApplication[]> {
    try {
      const res = await fetch('/api/careers/applications');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.applications)) {
          const normalized: CareerApplication[] = data.applications.map((a: any) => ({
            id: a.id,
            reference_id: a.referenceId || a.reference_id || `JS-REF-2026-${a.id?.slice(-4) || '1000'}`,
            full_name: a.fullName || a.full_name || 'Candidate',
            email: a.email || '',
            phone: a.phone || '',
            location: a.location || '',
            position: a.position || '',
            experience_level: a.experienceLevel || a.experience_level || '',
            years_experience: Number(a.yearsExperience || a.years_experience || 0),
            work_types: Array.isArray(a.workTypes) ? a.workTypes : (Array.isArray(a.work_types) ? a.work_types : []),
            skills: Array.isArray(a.skills) ? a.skills : [],
            lead_sources: Array.isArray(a.leadSources) ? a.leadSources : (Array.isArray(a.lead_sources) ? a.lead_sources : []),
            custom_skills: a.customSkills || a.custom_skills || '',
            portfolio_url: a.portfolioUrl || a.portfolio_url || '',
            social_url: a.socialUrl || a.social_url || '',
            bank_name: a.bankName || a.bank_name || '',
            earliest_start_date: a.earliestStartDate || a.earliest_start_date || '',
            expected_rate: a.expectedRate || a.expected_rate || '',
            cover_letter: a.coverLetter || a.cover_letter || '',
            status: a.status || 'Pending',
            saved_to_google_sheets: Boolean(a.savedToGoogleSheets ?? a.saved_to_google_sheets),
            google_sheets_row: a.googleSheetsRow || a.google_sheets_row,
            created_at: a.createdAt || a.created_at || new Date().toISOString()
          }));
          setStorageItem('career_applications_v2', normalized);
          return normalized;
        }
      }
    } catch (e) {
      console.warn('Could not fetch /api/careers/applications:', e);
    }
    return this.getApplicationsSync();
  },

  async saveApplications(apps: CareerApplication[]): Promise<void> {
    setStorageItem('career_applications_v2', apps);
  },

  async addApplication(appData: Omit<CareerApplication, 'id' | 'reference_id' | 'created_at' | 'status'> & { status?: CareerApplication['status'] }): Promise<CareerApplication> {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const newApp: CareerApplication = {
      ...appData,
      id: `app-${Date.now()}-${randomSuffix}`,
      reference_id: `JS-REF-2026-${randomSuffix}`,
      status: appData.status || 'Pending',
      created_at: new Date().toISOString()
    };
    const current = await this.getApplications();
    const updated = [newApp, ...current];
    await this.saveApplications(updated);
    return newApp;
  },

  async updateApplicationStatus(id: string, status: CareerApplication['status']): Promise<CareerApplication> {
    try {
      await fetch(`/api/careers/applications/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
    } catch (e) {
      console.warn('Could not update application status on server:', e);
    }
    const current = await this.getApplications();
    let updatedApp: CareerApplication | null = null;
    const updated = current.map(a => {
      if (a.id === id) {
        updatedApp = { ...a, status };
        return updatedApp;
      }
      return a;
    });
    await this.saveApplications(updated);
    if (!updatedApp) throw new Error('Application not found');
    return updatedApp;
  },

  async deleteApplication(id: string): Promise<void> {
    try {
      await fetch(`/api/careers/applications/${id}`, {
        method: 'DELETE'
      });
    } catch (e) {
      console.warn('Could not delete application on server:', e);
    }
    const current = await this.getApplications();
    const updated = current.filter(a => a.id !== id);
    await this.saveApplications(updated);
  },

  getGoogleSheetsConfig(): GoogleSheetsConfig {
    const defaultConfig: GoogleSheetsConfig = {
      spreadsheet_id: '',
      sheet_name: 'Applications',
      is_connected: false,
      total_synced_rows: 0
    };
    return getStorageItem<GoogleSheetsConfig>('google_sheets_config', defaultConfig);
  },

  saveGoogleSheetsConfig(config: GoogleSheetsConfig): void {
    setStorageItem('google_sheets_config', config);
  }
};
