import { ServiceItem, PricingPackage, PortfolioProject, FaqItem, TestimonialItem, SiteSettings, StoreProduct, StoreOrder, StoreCoupon } from './types';

export const INITIAL_SERVICES: ServiceItem[] = [
  {
    id: '1',
    title: 'Business Website Development',
    short_description: 'Professional responsive websites for businesses that need a clear and reliable online presence.',
    full_description: 'Professional, responsive websites built around your business, audience, and goals.',
    features: [
      'Responsive design',
      'Business-focused page structure',
      'Clear navigation',
      'Contact forms',
      'WhatsApp communication options',
      'Mobile optimization',
      'Basic SEO foundations',
      'Performance optimization',
      'Social media integration where needed'
    ],
    order_index: 1,
    is_active: true,
    image_url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '2',
    title: 'E-commerce Development',
    short_description: 'Online stores with product management, basic variations, stock tracking, coupons, shipping methods, and essential store functionality.',
    full_description: 'Online stores built around your products, customers, and business requirements.',
    features: [
      'Product listings',
      'Variations',
      'Basic stock tracking',
      'Basic coupons',
      'Shipping methods/charges',
      'Responsive design',
      'Essential store pages',
      'Basic SEO foundations',
      'Mobile optimization'
    ],
    order_index: 2,
    is_active: true,
    image_url: 'https://images.unsplash.com/photo-1556742049-0a67d553c235?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '3',
    title: 'Landing Page Development',
    short_description: 'Focused landing pages designed around a specific service, campaign, offer, or business goal.',
    full_description: 'Focused landing pages built around a specific service, offer, campaign, or business goal.',
    features: [
      'Service/product/offer promotion',
      'Lead generation',
      'Google Ads campaigns',
      'Social campaigns',
      'Events/announcements',
      'Business-specific campaigns',
      'Clear messaging',
      'Focused structure',
      'Strong CTAs',
      'Responsive design',
      'Mobile usability',
      'Conversion-focused layouts'
    ],
    order_index: 3,
    is_active: true,
    image_url: 'https://images.unsplash.com/photo-1533750349077-cdcd106d2052?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '4',
    title: 'Website Redesign',
    short_description: "Improve an existing website's structure, appearance, usability, responsiveness, and overall presentation.",
    full_description: 'A cleaner, more modern website experience for businesses that have outgrown their current website.',
    features: [
      'Modern visual structure',
      'Improved page organization',
      'Better navigation',
      'Mobile optimization',
      'Improved content presentation',
      'Clearer CTAs',
      'Performance improvements where applicable',
      'Search-friendly foundations',
      'Better UX'
    ],
    order_index: 4,
    is_active: true,
    image_url: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '5',
    title: 'Personal Portfolio Website',
    short_description: 'Professional portfolio websites for individuals, professionals, creatives, and service providers who need to present their work and profile online.',
    full_description: 'Professional portfolio websites designed to present your work, skills, experience, and personal brand online.',
    features: [
      'Personal intro',
      'About',
      'Skills/experience',
      'Projects/work showcase',
      'Project details',
      'Services',
      'Testimonials where applicable',
      'Contact',
      'Social links',
      'Responsive/mobile optimization',
      'Structure adapted to your work, audience and goals'
    ],
    order_index: 5,
    is_active: true,
    image_url: 'https://images.unsplash.com/photo-1522542550221-31fd19575a2d?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '6',
    title: 'Website Maintenance & Support',
    short_description: 'Ongoing website maintenance, updates, backups, basic security checks, bug fixes, and technical support.',
    full_description: 'Ongoing website updates, maintenance, technical support, and care after your website launches.',
    features: [
      'Website updates',
      'Backups',
      'Basic security checks',
      'Bug fixes',
      'Normal technical support',
      'Performance monitoring',
      'Basic technical SEO checks',
      'E-commerce maintenance where applicable',
      'Small content/design changes',
      'Priority technical support'
    ],
    order_index: 6,
    is_active: true,
    image_url: 'https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?auto=format&fit=crop&w=800&q=80'
  }
];

export const INITIAL_PRICING: PricingPackage[] = [
  {
    id: 'p1',
    package_name: 'Basic Website',
    starting_price: 'PKR 25,000',
    description: 'Up to 5 pages, responsive design, and essential business foundations.',
    features: [
      'Up to 5 pages',
      'Responsive design',
      'Business-focused layout',
      'Contact form',
      'WhatsApp contact option',
      'Basic SEO foundations',
      'Basic performance optimization',
      'Social links',
      'Basic launch setup'
    ],
    order_index: 1,
    is_active: true,
    category: 'website'
  },
  {
    id: 'p2',
    package_name: 'Standard Website',
    starting_price: 'PKR 45,000',
    description: 'Up to 8 pages with enhanced functionality and performance.',
    features: [
      'Up to 8 pages',
      'Everything in Basic',
      'Additional sections/functionality',
      'Enhanced SEO/performance',
      'Advanced content structure',
      'Additional functionality based on scope'
    ],
    order_index: 2,
    is_active: true,
    category: 'website'
  },
  {
    id: 'p3',
    package_name: 'Premium Website',
    starting_price: 'PKR 75,000',
    description: 'Up to 10 pages with customized design and advanced features.',
    features: [
      'Up to 10 pages',
      'Everything in Standard',
      'More customized design/functionality',
      'Advanced content structure',
      'Enhanced optimization',
      'Additional features based on scope'
    ],
    order_index: 3,
    is_active: true,
    category: 'website'
  },
  {
    id: 'p4',
    package_name: 'Basic Maintenance',
    starting_price: 'PKR 1,999 / month',
    billing_type: 'monthly',
    description: 'Essential updates, backups, and security checks.',
    features: [
      'Up to 2 small content changes/month',
      'Technical maintenance',
      'Backups',
      'Basic security checks',
      'Basic bug fixes',
      'Normal support'
    ],
    order_index: 4,
    is_active: true,
    category: 'maintenance'
  },
  {
    id: 'p5',
    package_name: 'Standard Maintenance',
    starting_price: 'PKR 5,999 / month',
    billing_type: 'monthly',
    description: 'Enhanced maintenance with performance monitoring and SEO checks.',
    features: [
      'Up to 5 small content changes/month',
      'Maintenance',
      'Backups',
      'Basic security checks',
      'Bug fixes',
      'Performance monitoring',
      'Basic technical SEO checks',
      'Priority support'
    ],
    order_index: 5,
    is_active: true,
    category: 'maintenance'
  },
  {
    id: 'p6',
    package_name: 'Premium Maintenance',
    starting_price: 'PKR 9,999 / month',
    billing_type: 'monthly',
    description: 'Comprehensive support with e-commerce maintenance and priority care.',
    features: [
      'Up to 10 small content changes/month',
      'Advanced monitoring',
      'Security maintenance',
      'E-commerce maintenance where applicable',
      'Priority technical support',
      'Other included tasks defined by package scope'
    ],
    order_index: 6,
    is_active: true,
    category: 'maintenance'
  }
];

export const INITIAL_PORTFOLIO: PortfolioProject[] = [
  {
    id: 'port1',
    project_name: 'First Star Shop',
    category: 'E-commerce',
    short_description: 'Online store with catalog variations, stock tracking, and seamless shopping experience.',
    image_url: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=800&q=80',
    project_type: 'Client Project',
    order_index: 1,
    is_active: true,
    project_url: 'https://firststarshop.netlify.app/'
  },
  {
    id: 'port2',
    project_name: 'Janah Studio Official Demo',
    category: 'Websites',
    short_description: 'Interactive demonstration platform showcasing custom web design and responsive performance.',
    image_url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
    project_type: 'Demo',
    order_index: 2,
    is_active: true,
    project_url: 'https://janah-studio-official.ai.studio/'
  },
  {
    id: 'port3',
    project_name: 'Lahore Bistro & Cafe',
    category: 'Websites',
    short_description: 'Responsive restaurant website featuring menu display, reservations, and location map.',
    image_url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80',
    project_type: 'Client Project',
    order_index: 3,
    is_active: true,
    project_url: '#'
  },
  {
    id: 'port4',
    project_name: 'Digital Growth Landing Page',
    category: 'Landing Pages',
    short_description: 'High-conversion landing page optimized for Google Ads lead generation campaigns.',
    image_url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
    project_type: 'Demo',
    order_index: 4,
    is_active: true,
    project_url: '#'
  },
  {
    id: 'port5',
    project_name: 'Dr. Ayesha Cardiology Clinic',
    category: 'Redesigns',
    short_description: 'Modernized medical practice website with appointment booking and patient resources.',
    image_url: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=800&q=80',
    project_type: 'Client Project',
    order_index: 5,
    is_active: true,
    project_url: '#'
  },
  {
    id: 'port6',
    project_name: 'Zainab Khan Portfolio',
    category: 'Personal Portfolios',
    short_description: 'Creative portfolio showcasing graphic design work, client testimonials, and project gallery.',
    image_url: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=800&q=80',
    project_type: 'Demo',
    order_index: 6,
    is_active: true,
    project_url: '#'
  }
];

export const INITIAL_FAQS: FaqItem[] = [
  // General Questions
  {
    id: 'faq-1',
    question: 'What is Janah Studio?',
    answer: 'Janah Studio is a web development studio that helps small businesses build professional websites and online stores.',
    category: 'General Questions',
    order_index: 1,
    is_active: true
  },
  {
    id: 'faq-2',
    question: 'Who does Janah Studio work with?',
    answer: 'We work with small businesses, professionals, startups, and growing online businesses.',
    category: 'General Questions',
    order_index: 2,
    is_active: true
  },
  {
    id: 'faq-3',
    question: 'What services does Janah Studio offer?',
    answer: 'We offer business websites, e-commerce development, landing pages, website redesigns, portfolio websites, maintenance, and other website-related services.',
    category: 'General Questions',
    order_index: 3,
    is_active: true
  },
  {
    id: 'faq-4',
    question: 'How can I contact Janah Studio?',
    answer: "You can contact us through our website's Contact page or WhatsApp.",
    category: 'General Questions',
    order_index: 4,
    is_active: true
  },
  {
    id: 'faq-5',
    question: 'Can I discuss my project before placing an order?',
    answer: 'Yes. You can discuss your requirements, budget, and project details with us before making a decision.',
    category: 'General Questions',
    order_index: 5,
    is_active: true
  },

  // Services
  {
    id: 'faq-6',
    question: 'What types of websites can Janah Studio build?',
    answer: 'We build business websites, online stores, landing pages, portfolio websites, and other websites based on your needs.',
    category: 'Services',
    order_index: 6,
    is_active: true
  },
  {
    id: 'faq-7',
    question: 'Can you build a website for my specific business?',
    answer: 'Yes. We can tailor the website structure and features to your business requirements.',
    category: 'Services',
    order_index: 7,
    is_active: true
  },
  {
    id: 'faq-8',
    question: 'Do you offer custom website solutions?',
    answer: 'Yes. We can discuss your specific requirements and suggest a suitable solution.',
    category: 'Services',
    order_index: 8,
    is_active: true
  },
  {
    id: 'faq-9',
    question: 'Can I request multiple services for one project?',
    answer: "Yes. You can combine suitable services based on your project's needs.",
    category: 'Services',
    order_index: 9,
    is_active: true
  },
  {
    id: 'faq-10',
    question: 'How do I choose the right service for my business?',
    answer: 'Explore our Services and Pricing pages, or contact us to discuss your requirements.',
    category: 'Services',
    order_index: 10,
    is_active: true
  },

  // Pricing & Payments
  {
    id: 'faq-11',
    question: 'How much does a website cost?',
    answer: 'Website prices vary depending on the service, features, scope, and selected package. You can explore our Pricing page for details.',
    category: 'Pricing & Payments',
    order_index: 11,
    is_active: true
  },
  {
    id: 'faq-12',
    question: 'What is included in your website packages?',
    answer: 'Each package includes specific features and services listed on the Pricing page.',
    category: 'Pricing & Payments',
    order_index: 12,
    is_active: true
  },
  {
    id: 'faq-13',
    question: 'Do you offer custom pricing for unique projects?',
    answer: 'Yes. If your requirements do not fit an existing package, contact us for a tailored quotation.',
    category: 'Pricing & Payments',
    order_index: 13,
    is_active: true
  },
  {
    id: 'faq-14',
    question: 'What payment methods do you accept?',
    answer: 'Available payment methods can be confirmed with our team before your project begins.',
    category: 'Pricing & Payments',
    order_index: 14,
    is_active: true
  },
  {
    id: 'faq-15',
    question: 'Do I need to pay a deposit before development begins?',
    answer: 'Yes. A 50% deposit is required to begin the project, with the remaining 50% payable after completion and review, before launch.',
    category: 'Pricing & Payments',
    order_index: 15,
    is_active: true
  },

  // Business Website
  {
    id: 'faq-16',
    question: 'What is included in a business website?',
    answer: 'A business website can include essential pages, responsive design, contact forms, WhatsApp integration, and basic SEO foundations according to your selected package.',
    category: 'Business Website',
    order_index: 16,
    is_active: true
  },
  {
    id: 'faq-17',
    question: 'Can you add extra pages to my business website?',
    answer: 'Yes. Additional pages can be included according to your package or quoted separately if they exceed its scope.',
    category: 'Business Website',
    order_index: 17,
    is_active: true
  },
  {
    id: 'faq-18',
    question: 'Can I request changes to my website after reviewing it?',
    answer: 'Yes. Your package includes the specified revision rounds. Additional work outside the agreed scope may cost extra.',
    category: 'Business Website',
    order_index: 18,
    is_active: true
  },

  // Portfolio Website
  {
    id: 'faq-19',
    question: 'Can you build a personal portfolio website?',
    answer: 'Yes. We create portfolio websites for professionals, freelancers, students, and individuals who want to showcase their work.',
    category: 'Portfolio Website',
    order_index: 19,
    is_active: true
  },
  {
    id: 'faq-20',
    question: 'What can I include in my portfolio website?',
    answer: 'You can showcase your introduction, skills, projects, experience, services, and contact information, depending on your requirements.',
    category: 'Portfolio Website',
    order_index: 20,
    is_active: true
  },
  {
    id: 'faq-21',
    question: 'Can I update my portfolio website in the future?',
    answer: 'Yes. Future updates can be arranged according to your website setup and support requirements.',
    category: 'Portfolio Website',
    order_index: 21,
    is_active: true
  },

  // E-commerce
  {
    id: 'faq-22',
    question: 'Can you build an online store for my business?',
    answer: 'Yes. We build online stores that help businesses present products and sell online.',
    category: 'E-commerce',
    order_index: 22,
    is_active: true
  },
  {
    id: 'faq-23',
    question: 'Can I add and manage my own products?',
    answer: 'Product management options depend on the store setup and functionality included in your project.',
    category: 'E-commerce',
    order_index: 23,
    is_active: true
  },
  {
    id: 'faq-24',
    question: 'Can you add product categories and variations?',
    answer: "Yes. Product categories and variations can be included according to your store's requirements.",
    category: 'E-commerce',
    order_index: 24,
    is_active: true
  },
  {
    id: 'faq-25',
    question: 'Can you set up shopping cart and checkout functionality?',
    answer: 'Yes. Shopping cart and checkout functionality can be included in your e-commerce project.',
    category: 'E-commerce',
    order_index: 25,
    is_active: true
  },
  {
    id: 'faq-26',
    question: 'Can you integrate online payment methods?',
    answer: 'Payment integration depends on the payment provider, platform compatibility, and your business requirements.',
    category: 'E-commerce',
    order_index: 26,
    is_active: true
  },
  {
    id: 'faq-27',
    question: 'Can you configure shipping options and charges?',
    answer: "Yes. Shipping options and charges can be configured according to your store's requirements and available integrations.",
    category: 'E-commerce',
    order_index: 27,
    is_active: true
  },
  {
    id: 'faq-28',
    question: 'Can you add discount codes to my online store?',
    answer: 'Yes. Discount codes can be added if supported by your store platform and selected functionality.',
    category: 'E-commerce',
    order_index: 28,
    is_active: true
  },

  // Landing Pages
  {
    id: 'faq-29',
    question: 'What is a landing page, and when do I need one?',
    answer: 'A landing page focuses on one specific goal, such as promoting a service, collecting enquiries, or generating leads.',
    category: 'Landing Pages',
    order_index: 29,
    is_active: true
  },
  {
    id: 'faq-30',
    question: 'Can you build a landing page for Google Ads campaigns?',
    answer: 'Yes. We can create focused landing pages designed around your advertising campaign and target audience.',
    category: 'Landing Pages',
    order_index: 30,
    is_active: true
  },
  {
    id: 'faq-31',
    question: 'Can a landing page be designed around a specific offer or service?',
    answer: 'Yes. We can structure the page around your offer, key benefits, and desired visitor action.',
    category: 'Landing Pages',
    order_index: 31,
    is_active: true
  },

  // Website Redesign
  {
    id: 'faq-32',
    question: 'Can you redesign my existing website?',
    answer: "Yes. We can improve your existing website's design, structure, usability, and overall presentation.",
    category: 'Website Redesign',
    order_index: 32,
    is_active: true
  },
  {
    id: 'faq-33',
    question: 'Can you improve my website\'s mobile experience and performance?',
    answer: "Yes. We can review mobile usability and performance and make improvements according to the project's scope.",
    category: 'Website Redesign',
    order_index: 33,
    is_active: true
  },
  {
    id: 'faq-34',
    question: 'Will my existing website content be preserved during a redesign?',
    answer: 'Relevant existing content can be preserved or reorganized according to your requirements and the agreed scope.',
    category: 'Website Redesign',
    order_index: 34,
    is_active: true
  },

  // Hosting & Domain
  {
    id: 'faq-35',
    question: 'Do you provide hosting with your website packages?',
    answer: 'Hosting depends on the selected package. Please check the Pricing page for the applicable details.',
    category: 'Hosting & Domain',
    order_index: 35,
    is_active: true
  },
  {
    id: 'faq-36',
    question: 'Do I need to purchase my own domain name?',
    answer: 'This depends on your package. Some packages include a subdomain, while others include a custom domain for the specified period.',
    category: 'Hosting & Domain',
    order_index: 36,
    is_active: true
  },
  {
    id: 'faq-37',
    question: 'Can you help me set up my domain and hosting?',
    answer: 'Yes. We can assist with domain, hosting, and related configuration according to your package.',
    category: 'Hosting & Domain',
    order_index: 37,
    is_active: true
  },
  {
    id: 'faq-38',
    question: 'Can I move my website to another hosting provider later?',
    answer: 'Yes. Migration options depend on your website setup, hosting provider, and package terms.',
    category: 'Hosting & Domain',
    order_index: 38,
    is_active: true
  },
  {
    id: 'faq-39',
    question: 'Who owns the domain and hosting accounts?',
    answer: "Ownership and account arrangements will be clarified before setup. Paid third-party services should be registered with the appropriate account holder's details.",
    category: 'Hosting & Domain',
    order_index: 39,
    is_active: true
  },

  // Website Features & Functionality
  {
    id: 'faq-40',
    question: 'Can you add contact forms and WhatsApp buttons to my website?',
    answer: "Yes. Contact forms and WhatsApp buttons can be included according to your website's requirements.",
    category: 'Website Features & Functionality',
    order_index: 40,
    is_active: true
  },
  {
    id: 'faq-41',
    question: 'Can you integrate social media links into my website?',
    answer: 'Yes. We can add links to your relevant social media profiles.',
    category: 'Website Features & Functionality',
    order_index: 41,
    is_active: true
  },
  {
    id: 'faq-42',
    question: 'Will my website work on mobile phones, tablets, and desktops?',
    answer: 'Yes. Websites are designed to adapt to mobile phones, tablets, and desktop screens.',
    category: 'Website Features & Functionality',
    order_index: 42,
    is_active: true
  },
  {
    id: 'faq-43',
    question: 'Can you add new features to my website later?',
    answer: 'Yes. Additional features can be discussed and quoted separately according to the work required.',
    category: 'Website Features & Functionality',
    order_index: 43,
    is_active: true
  },

  // SEO & Performance
  {
    id: 'faq-44',
    question: 'Will my website include basic SEO setup?',
    answer: 'Basic SEO foundations can include page titles, meta descriptions, heading structure, and other relevant on-page elements according to your package.',
    category: 'SEO & Performance',
    order_index: 44,
    is_active: true
  },
  {
    id: 'faq-45',
    question: 'Can you help my website load faster?',
    answer: 'Yes. We can review website performance and apply suitable improvements within the agreed scope.',
    category: 'SEO & Performance',
    order_index: 45,
    is_active: true
  },
  {
    id: 'faq-46',
    question: 'Will my website be optimized for mobile devices?',
    answer: 'Yes. Responsive design and mobile usability are considered during website development.',
    category: 'SEO & Performance',
    order_index: 46,
    is_active: true
  },
  {
    id: 'faq-47',
    question: 'Can you set up Google Analytics and website tracking?',
    answer: 'Yes. Analytics and tracking setup can be provided as a service according to your requirements and the necessary account access.',
    category: 'SEO & Performance',
    order_index: 47,
    is_active: true
  },

  // Process & Delivery
  {
    id: 'faq-48',
    question: 'How does the website development process work?',
    answer: 'We discuss your requirements, confirm the scope and price, begin development after the initial payment, review the website with you, complete the agreed revisions, and prepare it for launch.',
    category: 'Process & Delivery',
    order_index: 48,
    is_active: true
  },
  {
    id: 'faq-49',
    question: 'How long does it take to complete a website?',
    answer: 'Delivery time depends on the service and selected package. Estimated timelines are provided on the Pricing page.',
    category: 'Process & Delivery',
    order_index: 49,
    is_active: true
  },
  {
    id: 'faq-50',
    question: 'What information and content do I need to provide?',
    answer: 'You may need to provide your business details, text, logo, images, contact information, and any specific requirements relevant to your project.',
    category: 'Process & Delivery',
    order_index: 50,
    is_active: true
  },
  {
    id: 'faq-51',
    question: 'When will my website be launched?',
    answer: 'Your website is prepared for launch after development, review, completion of agreed changes, and your approval, subject to the agreed payment terms.',
    category: 'Process & Delivery',
    order_index: 51,
    is_active: true
  },

  // Revisions & Support
  {
    id: 'faq-52',
    question: 'How many revision rounds are included in my project?',
    answer: 'Two revision rounds are included. Each round should contain one consolidated list of requested changes.',
    category: 'Revisions & Support',
    order_index: 52,
    is_active: true
  },
  {
    id: 'faq-53',
    question: 'Can I request additional changes beyond the included revisions?',
    answer: 'Yes. Additional changes can be discussed and may be charged separately.',
    category: 'Revisions & Support',
    order_index: 53,
    is_active: true
  },
  {
    id: 'faq-54',
    question: 'What if I need a feature that is not included in my package?',
    answer: 'Contact us to discuss your requirements. We can assess the feature and provide a separate quotation if needed.',
    category: 'Revisions & Support',
    order_index: 54,
    is_active: true
  },

  // Affiliate Program
  {
    id: 'faq-55',
    question: 'How does the Janah Studio Affiliate Program work?',
    answer: 'Join our affiliate program and earn rewards by referring clients to Janah Studio. You’ll earn a referral reward when someone you refer purchases our services, and your referred client will also receive a discount when using your unique affiliate code at checkout.',
    category: 'Affiliate Program',
    order_index: 55,
    is_active: true
  }
];

export const INITIAL_TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't1',
    quote: 'I had a great experience with Janah Studio. The team was professional, easy to communicate with, and attentive to my requirements. I really appreciated their approach and the way they handled the work.',
    client_name: 'Dr. Mujtahid',
    role: 'Medical Professional & Client',
    is_active: true
  },
  {
    id: 't2',
    quote: 'Janah Studio built our website efficiently with great attention to detail. The communication was smooth and the final result exceeded our expectations.',
    client_name: 'Wasif Khan Jamali',
    role: 'Business Owner',
    is_active: true
  },
  {
    id: 't3',
    quote: 'Professional, prompt, and reliable web development services. Our online presence has improved noticeably since launching with Janah Studio.',
    client_name: 'Sarah Ahmed',
    role: 'Founder, Creative Hub',
    is_active: true
  }
];

export const INITIAL_SETTINGS: SiteSettings = {
  business_name: 'Janah Studio',
  contact_email: 'janahstudio.official@gmail.com',
  whatsapp_number: '+92 329 543 0114',
  social_youtube: 'https://youtube.com',
  social_facebook: 'https://facebook.com',
  social_instagram: 'https://instagram.com',
  social_tiktok: 'https://tiktok.com',
  global_cta_text: "Let's Build",
  secondary_cta_text: 'Chat Us'
};

export const INITIAL_PRODUCTS: StoreProduct[] = [
  {
    id: 'prod-1',
    name: 'Wireless Noise-Cancelling Headphones',
    price: 8499,
    original_price: 11999,
    description: 'High-fidelity audio with active noise cancellation, 30-hour battery life, and comfortable memory foam earcups.',
    category: 'Electronics',
    image_url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
    stock_quantity: 45,
    in_stock: true,
    stock_status: 'In Stock',
    sku: 'EL-HP-001',
    is_active: true,
    created_at: '2026-03-01T10:00:00Z'
  },
  {
    id: 'prod-2',
    name: 'Classic Minimalist Leather Watch',
    price: 4999,
    original_price: 6499,
    description: 'Timeless quartz timepiece with genuine Italian leather strap, water-resistant casing, and sapphire glass.',
    category: 'Accessories',
    image_url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
    stock_quantity: 28,
    in_stock: true,
    stock_status: 'In Stock',
    sku: 'AC-WT-002',
    is_active: true,
    created_at: '2026-03-02T10:00:00Z'
  },
  {
    id: 'prod-3',
    name: 'Organic Cotton Oxford Shirt',
    price: 3299,
    original_price: 4299,
    description: 'Tailored fit button-down shirt crafted from 100% breathable organic cotton. Suitable for both formal and casual wear.',
    category: 'Fashion',
    image_url: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80',
    stock_quantity: 60,
    in_stock: true,
    stock_status: 'In Stock',
    sku: 'FA-SH-003',
    is_active: true,
    created_at: '2026-03-03T10:00:00Z'
  },
  {
    id: 'prod-4',
    name: 'Smart Fitness Tracker Band',
    price: 3999,
    original_price: 5499,
    description: 'Real-time heart rate monitor, sleep tracking, 50m water resistance, and AMOLED color touch display with 14-day battery.',
    category: 'Electronics',
    image_url: 'https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?auto=format&fit=crop&w=800&q=80',
    stock_quantity: 12,
    in_stock: true,
    stock_status: 'Low Stock',
    sku: 'EL-FT-004',
    is_active: true,
    created_at: '2026-03-04T10:00:00Z'
  },
  {
    id: 'prod-5',
    name: 'Handcrafted Ceramic Coffee Mug Set',
    price: 2499,
    original_price: 3199,
    description: 'Set of 4 artisan ceramic mugs with speckled matte glaze. Microwave and dishwasher safe, crafted for everyday coffee moments.',
    category: 'Home & Living',
    image_url: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80',
    stock_quantity: 35,
    in_stock: true,
    stock_status: 'In Stock',
    sku: 'HL-MG-005',
    is_active: true,
    created_at: '2026-03-05T10:00:00Z'
  },
  {
    id: 'prod-6',
    name: 'Ergonomic Memory Foam Laptop Backpack',
    price: 4499,
    original_price: 5999,
    description: 'Water-resistant travel backpack with dedicated padded sleeve for up to 16-inch laptops, hidden anti-theft pockets, and USB port.',
    category: 'Accessories',
    image_url: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80',
    stock_quantity: 18,
    in_stock: true,
    stock_status: 'In Stock',
    sku: 'AC-BP-006',
    is_active: true,
    created_at: '2026-03-06T10:00:00Z'
  },
  {
    id: 'prod-7',
    name: 'Natural Botanical Face Serum',
    price: 2199,
    original_price: 2899,
    description: 'Hydrating vitamin C and hyaluronic acid facial serum. Non-greasy, cruelty-free, and suitable for all skin types.',
    category: 'Health & Beauty',
    image_url: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80',
    stock_quantity: 40,
    in_stock: true,
    stock_status: 'In Stock',
    sku: 'HB-SR-007',
    is_active: true,
    created_at: '2026-03-07T10:00:00Z'
  },
  {
    id: 'prod-8',
    name: 'Stainless Steel Insulated Water Bottle',
    price: 1899,
    original_price: 2499,
    description: 'Double-walled vacuum insulated flask keeping drinks cold for 24 hours or hot for 12 hours. 750ml capacity.',
    category: 'Home & Living',
    image_url: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=800&q=80',
    stock_quantity: 50,
    in_stock: true,
    stock_status: 'In Stock',
    sku: 'HL-WB-008',
    is_active: true,
    created_at: '2026-03-08T10:00:00Z'
  }
];

export const INITIAL_ORDERS: StoreOrder[] = [
  {
    id: 'ord-101',
    order_number: 'ORD-8821',
    customer_name: 'Hamza Tariq',
    customer_email: 'hamza.tariq@gmail.com',
    customer_phone: '0300-1234567',
    shipping_address: 'House 45, Street 12, F-8/2',
    city: 'Islamabad',
    items: [
      {
        product_id: 'prod-1',
        product_name: 'Wireless Noise-Cancelling Headphones',
        price: 8499,
        quantity: 1,
        image_url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80'
      }
    ],
    total_amount: 8499,
    payment_method: 'Cash on Delivery (COD)',
    status: 'Processing',
    tracking_number: 'TCS-9912048',
    courier: 'TCS Express',
    notes: 'Please call before delivery',
    created_at: '2026-03-15T14:30:00Z'
  },
  {
    id: 'ord-102',
    order_number: 'ORD-8822',
    customer_name: 'Ayesha Siddiqui',
    customer_email: 'ayesha.s@yahoo.com',
    customer_phone: '0321-9876543',
    shipping_address: 'Apartment 4B, Clifton Block 5',
    city: 'Karachi',
    items: [
      {
        product_id: 'prod-2',
        product_name: 'Classic Minimalist Leather Watch',
        price: 4999,
        quantity: 1,
        image_url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80'
      },
      {
        product_id: 'prod-7',
        product_name: 'Natural Botanical Face Serum',
        price: 2199,
        quantity: 1,
        image_url: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80'
      }
    ],
    total_amount: 7198,
    payment_method: 'Bank Transfer',
    status: 'Shipped',
    tracking_number: 'LEO-4410982',
    courier: 'Leopards Courier',
    notes: 'Bank slip verified',
    created_at: '2026-03-16T11:15:00Z'
  },
  {
    id: 'ord-103',
    order_number: 'ORD-8823',
    customer_name: 'Bilal Farooq',
    customer_email: 'bilal.f@outlook.com',
    customer_phone: '0333-5551234',
    shipping_address: 'Plaza 18, Commercial Area, DHA Phase 5',
    city: 'Lahore',
    items: [
      {
        product_id: 'prod-6',
        product_name: 'Ergonomic Memory Foam Laptop Backpack',
        price: 4499,
        quantity: 1,
        image_url: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80'
      }
    ],
    total_amount: 4499,
    payment_method: 'Cash on Delivery (COD)',
    status: 'Delivered',
    tracking_number: 'TCS-9912089',
    courier: 'TCS Express',
    created_at: '2026-03-12T09:40:00Z'
  }
];

export const INITIAL_COUPONS: StoreCoupon[] = [
  {
    id: 'c-1',
    code: 'WELCOME10',
    discount_percentage: 10,
    is_active: true,
    min_order_amount: 2000,
    expiry_date: '2026-12-31'
  },
  {
    id: 'c-2',
    code: 'JANAH20',
    discount_percentage: 20,
    is_active: true,
    min_order_amount: 5000,
    expiry_date: '2026-12-31'
  }
];

