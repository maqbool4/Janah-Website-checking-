import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { FloatingChat } from './components/FloatingChat';

import Home from './pages/Home';
import Services from './pages/Services';
import Pricing from './pages/Pricing';
import Portfolio from './pages/Portfolio';
import About from './pages/About';
import Maintenance from './pages/Maintenance';
import FAQ from './pages/FAQ';
import Contact from './pages/Contact';
import Legal from './pages/Legal';
import NotFound from './pages/NotFound';
import Dashboard from './pages/Dashboard';
import Shop from './pages/Shop';
import Careers from './pages/Careers';

import heroImage from './assets/images/hero_image.png';
import featuredProject from './assets/images/featured_project.png';
import ecommerceProject from './assets/images/ecommerce_project.png';
import portfolioProject from './assets/images/portfolio_project.png';
import redesignProject from './assets/images/redesign_service.png';
import logoImage from './assets/images/logo.png';
import { TopLoadingBar } from './components/TopLoadingBar';

function AppLayout() {
  const location = useLocation();
  const isDashboard = location.pathname.startsWith('/dashboard');

  useEffect(() => {
    const imagesToPreload = [
      heroImage,
      featuredProject,
      ecommerceProject,
      portfolioProject,
      redesignProject,
      logoImage
    ];
    imagesToPreload.forEach((src) => {
      const img = new Image();
      img.src = src;
      if (img.decode) {
        img.decode().catch(() => {});
      }
    });
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex flex-col bg-white text-[#17202A] font-sans selection:bg-[#30E1CE]/30 selection:text-[#17202A]">
      <TopLoadingBar />
      {!isDashboard && <Header />}
      
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/about" element={<About />} />
          <Route path="/maintenance-support" element={<Maintenance />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/careers" element={<Careers />} />
          <Route path="/privacy-policy" element={<Legal />} />
          <Route path="/terms" element={<Legal />} />
          <Route path="/cookie-policy" element={<Legal />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      {!isDashboard && <Footer />}
      {!isDashboard && <FloatingChat />}
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppLayout />
    </BrowserRouter>
  );
}
