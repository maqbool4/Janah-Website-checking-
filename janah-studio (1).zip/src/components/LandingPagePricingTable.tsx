import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Minus, ArrowRight, Layout, Info } from 'lucide-react';
import { Button } from './ui/Button';
import { AnimatedHeading } from './ui/AnimatedHeading';
import { AnimatedDescription } from './ui/AnimatedDescription';

interface LandingPagePricingTableProps {
  className?: string;
  showHeader?: boolean;
}

export const LandingPagePricingTable: React.FC<LandingPagePricingTableProps> = ({ 
  className = '',
  showHeader = true
}) => {
  const navigate = useNavigate();
  const whatsappBaseUrl = "https://wa.me/923295430114";

  const handleOrder = (planName: string, price: string) => {
    const message = encodeURIComponent(`Hi Janah Studio, I am interested in the ${planName} Landing Page Development Package (${price}). Let's discuss!`);
    window.open(`${whatsappBaseUrl}?text=${message}`, '_blank');
  };

  const landingFeatures = [
    {
      feature: 'Price',
      standard: 'PKR 3,999',
      premium: 'PKR 7,999',
      isHighlight: true,
    },
    {
      feature: 'Landing Page',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Professional Design',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Mobile, Tablet & Desktop Responsive',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Hero Section with Call-to-Action',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Product or Service Details',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Benefits Section',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Images & Visual Content',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Contact Form',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'WhatsApp Integration',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Basic SEO Setup',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Free Hosting',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Free Subdomain',
      standard: true,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Customer Reviews Section',
      standard: false,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'FAQ Section',
      standard: false,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Enhanced Design & Section Styling',
      standard: false,
      premium: true,
      isHighlight: false,
    },
    {
      feature: 'Delivery Time',
      standard: '3–5 Days',
      premium: '5–7 Days',
      isHighlight: false,
    },
    {
      feature: 'Support Period',
      standard: '1 Month',
      premium: '2 Months',
      isHighlight: false,
    },
  ];

  return (
    <div className={`space-y-8 ${className}`}>
      {showHeader && (
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-[#30E1CE]/15 via-[#1876C7]/15 to-[#EC4899]/15 border border-[#1876C7]/20 text-[11px] font-bold text-[#1876C7] uppercase tracking-wider">
            <Layout className="w-3.5 h-3.5 text-[#1876C7]" />
            <span>High-Converting • Transparent Pricing</span>
          </div>
          <AnimatedHeading
            text="Landing Page Development"
            as="h2"
            className="text-3xl sm:text-4xl font-extrabold text-[#17202A] tracking-tight"
          />
          <AnimatedDescription
            text="High-impact single-page websites tailored to convert visitors, showcase your offers, and generate qualified leads."
            className="text-sm sm:text-base text-[#66727D] max-w-2xl mx-auto leading-relaxed"
            delay={0.15}
          />
        </div>
      )}

      {/* Comparison Card with 1px space with the card border */}
      <div className="max-w-4xl mx-auto bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 backdrop-blur-md rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none border border-[#30E1CE]/30 shadow-xl overflow-hidden p-[1px]">
        {/* Top Highlight Banner */}
        <div className="bg-gradient-to-r from-[#30E1CE]/30 via-[#1876C7]/20 to-purple-100 px-6 py-4 text-[#17202A] flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left border-b border-[#30E1CE]/30">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#30E1CE] animate-pulse"></span>
            <span className="text-xs sm:text-sm font-semibold tracking-wide text-[#17202A]">
              Launch Your Dedicated Landing Page Fast & Effectively
            </span>
          </div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#17202A] bg-[#30E1CE]/20 px-2.5 py-1 rounded-full border border-[#30E1CE]/40">
            Fast Turnaround
          </span>
        </div>

        {/* Comparison Table */}
        <div className="overflow-x-auto -mx-2 sm:mx-0">
          <table className="w-full text-left border-collapse min-w-[360px] sm:min-w-[480px]">
            {/* Header Row */}
            <thead>
              <tr className="border-b border-[#30E1CE]/30">
                <th className="py-3 px-3 sm:px-6 text-xs sm:text-sm font-bold text-[#17202A] w-[40%] sm:w-[44%] uppercase tracking-wider bg-[#30E1CE]/20">
                  Features
                </th>
                <th className="py-3 px-2 sm:px-5 text-center text-xs sm:text-sm font-extrabold text-[#17202A] w-[30%] sm:w-[28%] bg-gradient-to-r from-[#30E1CE]/30 to-[#1876C7]/20 border-x border-[#30E1CE]/30">
                  <span className="text-sm sm:text-base text-[#17202A] font-extrabold block">Standard</span>
                </th>
                <th className="py-3 px-2 sm:px-5 text-center text-xs sm:text-sm font-extrabold text-[#17202A] w-[30%] sm:w-[28%] bg-gradient-to-r from-[#1876C7]/20 via-[#30E1CE]/30 to-purple-100 relative shadow-inner">
                  <span className="text-sm sm:text-base text-[#17202A] font-extrabold block">Premium</span>
                </th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-[#30E1CE]/20">
              {landingFeatures.map((row, idx) => (
                <tr 
                  key={idx}
                  className={`transition-colors hover:bg-sky-50/40 ${row.isHighlight ? 'bg-[#30E1CE]/10 font-semibold' : idx % 2 === 0 ? 'bg-white/40' : 'bg-transparent'}`}
                >
                  {/* Feature Title */}
                  <td className="py-3 px-3 sm:px-6 text-xs sm:text-sm text-[#17202A] font-medium">
                    {row.feature}
                  </td>

                  {/* Standard Column */}
                  <td className="py-3 px-2 sm:px-5 text-center text-xs sm:text-sm text-[#17202A] border-x border-[#30E1CE]/20 bg-white/30">
                    {typeof row.standard === 'boolean' ? (
                      row.standard ? (
                        <div className="flex justify-center">
                          <span className="inline-flex items-center justify-center w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-emerald-50 text-emerald-600">
                            <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[2.5]" />
                          </span>
                        </div>
                      ) : (
                        <div className="flex justify-center text-gray-400">
                          <Minus className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[2]" />
                        </div>
                      )
                    ) : (
                      <span className={row.isHighlight ? 'text-base sm:text-xl font-extrabold text-[#1876C7]' : 'text-xs sm:text-sm font-semibold'}>
                        {row.standard}
                      </span>
                    )}
                  </td>

                  {/* Premium Column */}
                  <td className="py-3 px-2 sm:px-5 text-center text-xs sm:text-sm text-[#17202A] bg-sky-50/20">
                    {typeof row.premium === 'boolean' ? (
                      row.premium ? (
                        <div className="flex justify-center">
                          <span className="inline-flex items-center justify-center w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-emerald-50 text-emerald-600">
                            <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[2.5]" />
                          </span>
                        </div>
                      ) : (
                        <div className="flex justify-center text-gray-400">
                          <Minus className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[2]" />
                        </div>
                      )
                    ) : (
                      <span className={row.isHighlight ? 'text-base sm:text-xl font-extrabold text-[#1876C7]' : 'text-xs sm:text-sm font-semibold'}>
                        {row.premium}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>

            {/* Actions / CTA Row */}
            <tfoot>
              <tr className="border-t-2 border-[#30E1CE]/30 bg-white/40">
                <td className="py-4 px-3 sm:px-6 text-[11px] sm:text-sm text-[#66727D]">
                  <div className="space-y-0.5">
                    <p className="font-bold text-[#17202A] text-xs sm:text-sm">Need a dedicated page?</p>
                    <p className="text-[10px] sm:text-[11px] text-[#66727D] hidden sm:block">Fast turnaround with 1 year free hosting included.</p>
                  </div>
                </td>
                
                {/* Standard CTA */}
                <td className="py-4 px-2 sm:px-4 text-center border-x border-[#30E1CE]/20 bg-white/50">
                  <div className="flex justify-center">
                    <Button
                      variant="primary"
                      onClick={() => handleOrder('Landing Page Standard', 'PKR 3,999')}
                      className="w-full max-w-[140px] sm:max-w-[160px]"
                    >
                      <span>Choose Plan</span>
                      <ArrowRight className="w-3.5 h-3.5 ml-1 inline text-white" />
                    </Button>
                  </div>
                  <span className="text-[9px] sm:text-[10px] text-[#66727D] block mt-1 font-semibold">PKR 3,999</span>
                </td>

                {/* Premium CTA */}
                <td className="py-4 px-2 sm:px-4 text-center bg-sky-50/30">
                  <div className="flex justify-center">
                    <Button
                      variant="primary"
                      onClick={() => handleOrder('Landing Page Premium', 'PKR 7,999')}
                      className="w-full max-w-[140px] sm:max-w-[160px]"
                    >
                      <span>Choose Plan</span>
                      <ArrowRight className="w-3.5 h-3.5 ml-1 inline text-white" />
                    </Button>
                  </div>
                  <span className="text-[9px] sm:text-[10px] text-[#1876C7] font-semibold block mt-1">PKR 7,999</span>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Bottom Guarantee Banner */}
        <div className="bg-[#F8FAFA] p-4 sm:p-5 border-t border-[#E2E8EA] text-center flex flex-wrap items-center justify-center gap-4 text-xs text-[#66727D]">
          <span className="inline-flex items-center gap-1.5 font-medium text-[#17202A]">
            <Check className="w-3.5 h-3.5 text-emerald-600" /> Free 1st Year Hosting & Subdomain
          </span>
          <span className="hidden sm:inline text-gray-300">•</span>
          <span className="inline-flex items-center gap-1.5 font-medium text-[#17202A]">
            <Check className="w-3.5 h-3.5 text-emerald-600" /> Responsive Mobile & Speed Optimized
          </span>
          <span className="hidden sm:inline text-gray-300">•</span>
          <button 
            onClick={() => navigate('/contact')} 
            className="text-[#1876C7] font-bold hover:underline inline-flex items-center gap-1 cursor-pointer"
          >
            <span>Have Questions? Contact Us</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Hosting Terms Notice */}
      <div className="max-w-4xl mx-auto bg-white/80 backdrop-blur-sm rounded-2xl p-5 border border-[#30E1CE]/30 shadow-sm space-y-2 text-xs text-[#66727D] text-left">
        <div className="flex items-center gap-1.5 font-bold text-[#17202A]">
          <Info className="w-4 h-4 text-[#1876C7]" />
          <span>Hosting & Renewal Terms:</span>
        </div>
        <ul className="space-y-1 pl-5 list-disc text-[11px] sm:text-xs leading-relaxed">
          <li>Free hosting and a subdomain are included for the first (1st) year in both Standard and Premium plans.</li>
          <li>After the first year, standard renewal charges apply for hosting and subdomain continuation, or you may transfer your landing page to any independent hosting provider with zero lock-in.</li>
          <li>Renewal terms, pricing, and server requirements are clearly communicated and confirmed before your order is finalized.</li>
        </ul>
      </div>
    </div>
  );
};
