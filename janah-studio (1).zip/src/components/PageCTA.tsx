import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, MessageCircle } from 'lucide-react';
import { Button } from './ui/Button';
import { AnimatedSection } from './ui/AnimatedSection';
import { AnimatedHeading } from './ui/AnimatedHeading';
import { AnimatedDescription } from './ui/AnimatedDescription';

interface PageCTAProps {
  title?: string;
  description?: string;
  primaryBtnText?: string;
  primaryBtnLink?: string;
  whatsappMessage?: string;
  className?: string;
}

export const PageCTA: React.FC<PageCTAProps> = ({
  title = 'Ready to Build Your Website?',
  description = 'Let’s discuss your business, goals, and project needs. Get started with Janah Studio today.',
  primaryBtnText = 'Let’s Build',
  primaryBtnLink = '/contact',
  whatsappMessage = "Hi Janah Studio, I'd like to discuss a website project.",
  className = '',
}) => {
  const navigate = useNavigate();
  const whatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent(whatsappMessage)}`;

  return (
    <AnimatedSection className={className}>
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none pt-6 pb-10 sm:pb-14 px-6 sm:px-16 text-center space-y-3 shadow-2xl relative overflow-hidden border border-[#30E1CE]/30">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#30E1CE]/10 rounded-full blur-3xl pointer-events-none" />
          
          <AnimatedHeading
            text={title}
            as="h2"
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#17202A]"
          />
          <AnimatedDescription
            text={description}
            className="text-sm sm:text-base text-[#66727D] max-w-xl mx-auto leading-relaxed"
            delay={0.15}
          />

          <div className="flex flex-row flex-nowrap items-center justify-center gap-2 sm:gap-4 pt-4 overflow-x-auto pb-1">
            <Button
              variant="primary"
              onClick={() => navigate(primaryBtnLink)}
              className="px-6 sm:px-8 shrink-0 flex items-center gap-2"
            >
              <span>{primaryBtnText}</span>
              <ArrowRight className="w-4 h-4" />
            </Button>

            <Button
              variant="chat"
              onClick={() => window.open(whatsappUrl, '_blank')}
              className="px-6 sm:px-8 shrink-0 flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>
          </div>
        </div>
      </section>
    </AnimatedSection>
  );
};
