import React from 'react';
import { motion, useReducedMotion, Variants } from 'framer-motion';

interface AnimatedHeadingProps {
  text: string;
  className?: string;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'span';
  delay?: number;
  light?: boolean;
}

const EASING = [0.16, 1, 0.3, 1] as const;

export const AnimatedHeading: React.FC<AnimatedHeadingProps> = ({
  text,
  className = '',
  as = 'h2',
  delay = 0,
}) => {
  const shouldReduceMotion = useReducedMotion();
  const Tag = (motion as any)[as] || motion.h2;

  if (shouldReduceMotion) {
    const PlainTag = as;
    return <PlainTag className={className}>{text}</PlainTag>;
  }

  // Split into words, then words into characters to ensure browser word-wrapping is 100% preserved
  const words = text.split(' ');

  const containerVariants: Variants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.016, // Fast, natural character-by-character cascade
        delayChildren: delay,
      },
    },
  };

  const charVariants: Variants = {
    hidden: {
      opacity: 0,
      y: 12,
      rotateX: 40, // Elegant 3D rotational roll into position
      scale: 0.95,
    },
    visible: {
      opacity: 1,
      y: 0,
      rotateX: 0,
      scale: 1,
      transition: {
        duration: 0.42,
        ease: EASING, // Continuous, uninterrupted motion
      },
    },
  };

  return (
    <Tag
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: '0px 0px -30px 0px', amount: 0.15 }}
      className={className}
      aria-label={text}
      style={{ perspective: 1000 }}
    >
      {words.map((word, wordIdx) => (
        <span key={wordIdx} className="inline-block whitespace-nowrap">
          {word.split('').map((char, charIdx) => (
            <motion.span
              key={charIdx}
              variants={charVariants}
              className="inline-block will-change-transform"
              style={{ display: 'inline-block', transformOrigin: '50% 100%' }}
              aria-hidden="true"
            >
              {char}
            </motion.span>
          ))}
          {wordIdx < words.length - 1 && (
            <span className="inline-block">&nbsp;</span>
          )}
        </span>
      ))}
    </Tag>
  );
};
