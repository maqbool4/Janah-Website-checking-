import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';

interface AnimatedSectionProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  direction?: 'up' | 'down' | 'left' | 'right' | 'none';
}

const EASING = [0.16, 1, 0.3, 1] as const;

export const AnimatedSection: React.FC<AnimatedSectionProps> = ({
  children,
  className = '',
  delay = 0,
  direction = 'up',
}) => {
  const shouldReduceMotion = useReducedMotion();

  const getInitial = () => {
    if (shouldReduceMotion) {
      return { opacity: 0 };
    }
    switch (direction) {
      case 'left':
        return { opacity: 0, x: 36, y: 0 };
      case 'right':
        return { opacity: 0, x: -36, y: 0 };
      case 'down':
        return { opacity: 0, y: -24, x: 0 };
      case 'up':
        return { opacity: 0, y: 24, x: 0 };
      case 'none':
      default:
        return { opacity: 0, y: 0, x: 0 };
    }
  };

  return (
    <motion.div
      initial={getInitial()}
      whileInView={shouldReduceMotion ? { opacity: 1 } : { opacity: 1, y: 0, x: 0 }}
      viewport={{ once: true, margin: '0px 0px -30px 0px', amount: 0.08 }}
      transition={{
        duration: 0.65,
        delay,
        ease: EASING, // Ultra-smooth continuous ease, zero stuttering or hitching
      }}
      className={className}
      style={{ willChange: 'transform, opacity' }}
    >
      {children}
    </motion.div>
  );
};
