import React from 'react';
import { motion, useReducedMotion, Variants } from 'framer-motion';

interface AnimatedDescriptionProps {
  text: string;
  className?: string;
  delay?: number;
  as?: 'p' | 'div' | 'span';
}

const EASING = [0.16, 1, 0.3, 1] as const;

export const AnimatedDescription: React.FC<AnimatedDescriptionProps> = ({
  text,
  className = '',
  delay = 0,
  as = 'p',
}) => {
  const shouldReduceMotion = useReducedMotion();
  const Tag = (motion as any)[as] || motion.p;

  if (shouldReduceMotion) {
    const PlainTag = as;
    return <PlainTag className={className}>{text}</PlainTag>;
  }

  // Split description into individual words for fluid, fast word-by-word reveal
  const words = text.trim().split(/\s+/);

  const containerVariants: Variants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.028, // Fast, natural word-by-word cascade
        delayChildren: delay,
      },
    },
  };

  const wordVariants: Variants = {
    hidden: {
      opacity: 0,
      y: 8,
      filter: 'blur(1.5px)',
    },
    visible: {
      opacity: 1,
      y: 0,
      filter: 'blur(0px)',
      transition: {
        duration: 0.32,
        ease: EASING,
      },
    },
  };

  return (
    <Tag
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: '0px 0px -30px 0px', amount: 0.15 }}
      className={className}
      aria-label={text}
    >
      {words.map((word, idx) => (
        <motion.span
          key={idx}
          variants={wordVariants}
          className="inline-block mr-[0.28em] will-change-transform"
          aria-hidden="true"
        >
          {word}
        </motion.span>
      ))}
    </Tag>
  );
};
