import React from 'react';
import { motion } from 'motion/react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'chat' | 'navy-blue' | 'whatsapp' | 'email';
}

export const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', className, ...props }) => {
  // Uniform height 40px, font 14px, weight 700, px-4 horizontal padding, whitespace-nowrap, center alignment, 3D shadow
  const baseClasses = "relative h-[40px] px-4 py-0 font-bold text-[14px] whitespace-nowrap w-fit transition-all duration-150 inline-flex items-center justify-center text-center tracking-wide cursor-pointer";
  
  // Custom rounded shape: Top-left and bottom-right rounded, others sharp
  const shapeClasses = "rounded-tl-[12px] rounded-br-[12px] rounded-tr-none rounded-bl-none";

  const variants = {
    primary: "bg-gradient-to-r from-[#1C2533] to-[#247BC1] text-white shadow-[0_4px_0_#000000] hover:brightness-105 active:!bg-[#BA00FF] active:shadow-none active:translate-y-1",
    secondary: "bg-gradient-to-r from-[#17202A] via-[#2D3748] to-[#1876C7] text-white shadow-[0_4px_0_#0a0f14] hover:brightness-105 active:!bg-[#BA00FF] active:shadow-none active:translate-y-1",
    outline: "bg-white border-2 border-[#1876C7] text-[#1876C7] shadow-[0_4px_0_#155a95] hover:bg-[#30E1CE]/10 active:!bg-[#BA00FF] active:!text-white active:shadow-none active:translate-y-1",
    chat: "bg-gradient-to-r from-[#30E1CE] via-[#14B8A6] to-[#10B981] text-white shadow-[0_4px_0_#0d9488] hover:brightness-105 active:shadow-none active:translate-y-1",
    "navy-blue": "bg-gradient-to-r from-[#1C2533] to-[#247BC1] text-white shadow-[0_4px_0_#000000] hover:brightness-105 active:!bg-[#BA00FF] active:shadow-none active:translate-y-1 tracking-[2px]",
    whatsapp: "bg-gradient-to-r from-[#25D366] to-[#128C7E] text-white shadow-[0_4px_0_#075E54] hover:brightness-105 active:!bg-[#BA00FF] active:shadow-none active:translate-y-1",
    email: "bg-gradient-to-r from-[#0078D4] to-[#005A9E] text-white shadow-[0_4px_0_#004578] hover:brightness-105 active:!bg-[#BA00FF] active:shadow-none active:translate-y-1"
  };

  return (
    <motion.button
      whileTap={variant !== 'chat' ? { scale: 0.98, backgroundColor: '#BA00FF' } : { scale: 0.98 }}
      className={`${baseClasses} ${shapeClasses} ${variants[variant]} ${className}`}
      {...(props as any)}
    >
      {children}
    </motion.button>
  );
};
