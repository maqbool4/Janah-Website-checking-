import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Search, 
  Menu, 
  X, 
  MessageCircle, 
  Mail,
  Briefcase
} from 'lucide-react';
import logo from '../assets/images/logo.png';
import { Button } from './ui/Button';
import { InlineSearch } from './InlineSearch';

export const Header: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    setMobileMenuOpen(false);
    setSearchOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    let hideTimer: NodeJS.Timeout;
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      if (currentScrollY <= 20) {
        setIsVisible(true);
      } else if (currentScrollY > lastScrollY && currentScrollY > 60) {
        // Scrolling down
        setIsVisible(false);
      } else if (currentScrollY < lastScrollY) {
        // Scrolling up
        setIsVisible(true);
      }
      setLastScrollY(currentScrollY);
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (e.clientY < 60) {
        setIsVisible(true);
      }
    };

    if (window.scrollY > 60) {
      hideTimer = setTimeout(() => {
        setIsVisible(false);
      }, 2000);
    }

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
      if (hideTimer) clearTimeout(hideTimer);
    };
  }, [lastScrollY]);

  const whatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent("Hi Janah Studio, I'd like to discuss a website project.")}`;

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Services', path: '/services' },
    { label: 'Pricing', path: '/pricing' },
    { label: 'Portfolio', path: '/portfolio' },
    { label: 'About', path: '/about' },
    { label: 'Maintenance', path: '/maintenance-support' },
    { label: 'Careers', path: '/careers' },
    { label: 'FAQ', path: '/faq' },
    { label: 'Contact', path: '/contact' }
  ];

  return (
    <>
      {/* Full-screen Overlay Search Modal */}
      <InlineSearch isOpen={searchOpen} onClose={() => setSearchOpen(false)} />

      <header className={`relative sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-[#E2E8EA] transition-all duration-300 transform ${isVisible ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0 pointer-events-none'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Brand Logo */}
          <Link to="/" className="flex items-center gap-1.5 group shrink-0">
            <img src={logo} alt="Janah Studio Logo" className="w-7 h-7 rounded-lg shadow-sm group-hover:scale-105 transition-transform" />
            <div>
              <span className="text-base font-bold tracking-tight text-[#17202A] block leading-none">
                Janah Studio
              </span>
              <span className="text-[10px] text-[#66727D] font-medium block mt-0.5">
                Website Designer
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-5 xl:gap-7">
            {navLinks.map((link) => {
              const isActive = location.pathname === link.path;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`text-sm transition-colors hover:text-[#1876C7] ${
                    isActive ? 'text-[#1876C7] font-semibold' : 'text-[#66727D] font-medium'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          {/* Right Actions */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Search Button */}
            <button 
              onClick={() => setSearchOpen(true)}
              aria-label="Search Janah Studio"
              className="p-2.5 rounded-xl border border-[#E2E8EA] text-[#66727D] hover:text-[#1876C7] hover:border-[#1876C7]/50 transition-all bg-[#F8FAFA]"
              title="Search website"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Secondary CTA: Chat Us */}
            <Button
              variant="chat"
              onClick={() => window.open(whatsappUrl, '_blank')}
              className="flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>

            {/* Primary CTA: Let's Build */}
            <Button
              variant="primary"
              onClick={() => navigate('/contact')}
            >
              <span>Let’s Build</span>
            </Button>
          </div>

          {/* Mobile Menu Button & Search */}
          <div className="flex items-center gap-2 lg:hidden">
            <button 
              onClick={() => setSearchOpen(true)}
              aria-label="Search"
              className="p-2 rounded-xl border border-[#E2E8EA] text-[#66727D] hover:text-[#1876C7] bg-[#F8FAFA]"
            >
              <Search className="w-4 h-4" />
            </button>
            
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle Menu"
              className="p-2 rounded-xl border border-[#E2E8EA] text-[#17202A] bg-[#F8FAFA] hover:bg-gray-100 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-5 h-5 text-gray-700" /> : <Menu className="w-5 h-5 text-gray-700" />}
            </button>
          </div>
        </div>

        {/* Backdrop overlay to close menu on outside tap */}
        {mobileMenuOpen && (
          <div 
            className="lg:hidden fixed inset-0 z-40 bg-black/10 backdrop-blur-[0.5px]"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
        )}

        {/* Compact Content-Width Dropdown Menu with Janah Studio Card & Button Styling */}
        {mobileMenuOpen && (
          <div 
            className="lg:hidden absolute top-[calc(100%+8px)] right-3 sm:right-6 z-50 w-max min-w-[205px] max-w-[260px] bg-white/98 backdrop-blur-xl rounded-tl-2xl rounded-br-2xl rounded-tr-md rounded-bl-md shadow-[0_12px_36px_rgba(24,118,199,0.14)] border border-[#30E1CE]/35 p-3.5 animate-in fade-in zoom-in-95 duration-150"
            style={{ width: 'max-content' }}
          >
            {/* Nav Links with Comfortable Spacing */}
            <nav className="flex flex-col space-y-1">
              {navLinks.map((link) => {
                const isActive = location.pathname === link.path;
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`text-[13.5px] py-2 px-3.5 rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none transition-all flex items-center justify-between whitespace-nowrap font-medium ${
                      isActive 
                        ? 'text-[#1876C7] font-bold bg-[#1876C7]/10 border-l-2 border-[#1876C7]' 
                        : 'text-[#17202A] hover:bg-[#F8FAFA] hover:text-[#1876C7]'
                    }`}
                  >
                    <span>{link.label}</span>
                    {link.path === '/careers' && (
                      <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded ml-2">
                        Hiring
                      </span>
                    )}
                  </Link>
                );
              })}
            </nav>

            {/* Icons-Only Single Row Buttons matching Janah Studio Button Design & Slim Row Height */}
            <div className="pt-2.5 mt-2 border-t border-[#E2E8EA] grid grid-cols-2 gap-2">
              {/* WhatsApp Icon Button */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="h-9 flex items-center justify-center rounded-tl-[10px] rounded-br-[10px] rounded-tr-none rounded-bl-none bg-gradient-to-r from-[#25D366] to-[#128C7E] text-white shadow-[0_2px_0_#075E54] hover:brightness-105 active:translate-y-0.5 active:shadow-none transition-all cursor-pointer"
                title="WhatsApp"
                aria-label="WhatsApp"
              >
                <svg className="w-4.5 h-4.5 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/>
                </svg>
              </a>

              {/* Email Icon Button */}
              <a
                href="mailto:janahstudio.official@gmail.com"
                onClick={() => setMobileMenuOpen(false)}
                className="h-9 flex items-center justify-center rounded-tl-[10px] rounded-br-[10px] rounded-tr-none rounded-bl-none bg-gradient-to-r from-[#1C2533] to-[#247BC1] text-white shadow-[0_2px_0_#000000] hover:brightness-105 active:translate-y-0.5 active:shadow-none transition-all cursor-pointer"
                title="Email"
                aria-label="Email"
              >
                <Mail className="w-4.5 h-4.5 text-white" />
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
