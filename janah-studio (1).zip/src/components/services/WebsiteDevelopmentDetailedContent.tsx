import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Button } from '../ui/Button';

export const WebsiteDevelopmentDetailedContent = () => {
  return (
    <div className="space-y-8 text-left">
      <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#30E1CE]/30 shadow-xl space-y-6">
        <h3 className="text-2xl font-bold text-[#17202A]">Business Websites</h3>
        <p className="text-sm text-[#66727D] leading-relaxed">
          Janah Studio builds professional, customized websites to help small businesses establish a credible online presence, showcase services, and attract customers. Each website is tailored to your unique industry goals, audience, and budget.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Target Industries</h4>
          <p className="text-xs text-[#66727D] leading-relaxed">
            Restaurants and cafés, real estate, beauty and fashion, travel and tourism, consultants and professionals, repair and construction, startups, and other small businesses.
          </p>
        </div>
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Key Features</h4>
          <p className="text-xs text-[#66727D] leading-relaxed">
            Home, About, Services, and Contact pages, business information, service descriptions, image galleries, contact forms, WhatsApp/social links, responsive navigation, and professional branding.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#E2E8EA] shadow-sm space-y-4">
        <h4 className="text-lg font-bold text-[#17202A]">SEO, Performance & Customization</h4>
        <p className="text-sm text-[#66727D] leading-relaxed">
          We ensure your site includes basic SEO foundations, mobile optimization, performance improvements, and necessary analytics integrations. Final pages, features, and content depend on your specific business requirements and the agreed project scope.
        </p>
      </div>
      

      <div className="pt-4">
        <Link
          to="/contact"
          className="inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-gradient-to-r from-[#30E1CE] to-[#1876C7] text-white font-bold text-sm shadow-md w-full"
        >
          <span>Start Your Website Project</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};
