import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';

export const MaintenanceSupportContent = () => {
  return (
    <div className="space-y-8 text-left">
      <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#30E1CE]/30 shadow-xl space-y-6">
        <h3 className="text-2xl font-bold text-[#17202A]">Website Maintenance & Support</h3>
        <p className="text-sm text-[#66727D] leading-relaxed">
          Janah Studio provides ongoing website maintenance and technical support to help businesses keep their websites updated, functional, and reliable. Our service can include routine updates, minor content changes, troubleshooting, basic security checks, and technical assistance based on the selected maintenance package. We help businesses address common website issues and maintain a professional online presence without having to manage every technical task themselves. Available support and monthly task limits depend on the selected package and agreed scope.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Target Businesses</h4>
          <ul className="space-y-1.5">
            {[
              'Small businesses with existing websites',
              'Businesses that need regular website updates',
              'E-commerce businesses requiring ongoing website care',
              'Businesses that need minor content or image changes',
              'Business owners who lack in-house technical support',
              'Businesses needing help with website errors or technical issues',
              'Professionals and service providers maintaining their online presence',
              'Businesses seeking ongoing website maintenance after launch'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Key Features</h4>
          <ul className="space-y-1.5">
            {[
              'Routine Website Maintenance',
              'Supported Software and Plugin Updates',
              'Minor Text, Image, and Content Changes',
              'Basic Website Functionality Checks',
              'Troubleshooting of Covered Website Issues',
              'Basic Security and Website Health Checks',
              'Technical Assistance Within the Selected Package',
              'Website Content and Link Checks',
              'Performance-Related Checks',
              'Monthly Task Limits Based on Selected Package',
              'Support According to Agreed Service Scope'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="pt-2 flex flex-row gap-3">
        <Link to="/contact" className="flex-1">
          <Button variant="navy-blue" className="w-full h-[40px] text-[14px]">
            <span>Start Project</span>
          </Button>
        </Link>
        <Link to="/maintenance-support" className="flex-1">
          <Button variant="chat" className="w-full h-[40px] text-[14px]">
            <span>View Pricing</span>
          </Button>
        </Link>
      </div>
    </div>
  );
};
