import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';

export const BusinessWebsiteContent = () => {
  return (
    <div className="space-y-8 text-left">
      <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#30E1CE]/30 shadow-xl space-y-6">
        <h3 className="text-2xl font-bold text-[#17202A]">Business Website</h3>
        <p className="text-sm text-[#66727D] leading-relaxed">
          Janah Studio builds professional, customized websites tailored to each business's goals, services, target audience, and brand. A professional website helps your business establish a credible online presence, present its services clearly, build customer trust, reach potential customers, and support long-term business growth. Our service includes responsive design, essential business pages, contact functionality, basic SEO foundations, and performance-conscious development.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Target Businesses</h4>
          <ul className="space-y-1.5">
            {[
              'Restaurants and cafés',
              'Fashion brands and clothing businesses',
              'Real estate agencies and property businesses',
              'Beauty salons and beauty service providers',
              'Professional service providers and consultants',
              'Travel and tourism businesses',
              'Small local businesses',
              'Other service-based businesses'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Key Features</h4>
          <ul className="space-y-1.5">
            {[
              'Custom website structure based on business needs',
              'Responsive design for mobile, tablet, and desktop',
              'Essential business pages and service sections',
              'Clear business information and service presentation',
              'Contact forms and WhatsApp integration',
              'Professional branding and consistent visual design',
              'Basic on-page SEO foundations',
              'Performance-conscious development',
              'Cross-device testing',
              'Revisions and launch support within the agreed scope'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="pt-2 flex flex-row gap-3">
        <Link to="/contact" className="flex-1">
          <Button variant="navy-blue" className="w-full h-[40px] text-[14px]">
            <span>Start Project</span>
          </Button>
        </Link>
        <Link to="/pricing" className="flex-1">
          <Button variant="chat" className="w-full h-[40px] text-[14px]">
            <span>View Pricing</span>
          </Button>
        </Link>
      </div>
    </div>
  );
};
