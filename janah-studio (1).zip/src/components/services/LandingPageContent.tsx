import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';

export const LandingPageContent = () => {
  return (
    <div className="space-y-8 text-left">
      <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#30E1CE]/30 shadow-xl space-y-6">
        <h3 className="text-2xl font-bold text-[#17202A]">Landing Page</h3>
        <p className="text-sm text-[#66727D] leading-relaxed">
          Janah Studio creates professional, conversion-focused landing pages designed to promote specific products, services, campaigns, and special offers. Each landing page presents a clear message, highlights key benefits, and guides visitors toward a specific action, such as submitting an enquiry, contacting your business, requesting a quote, or making a purchase. Our service includes responsive design, clear calls to action, persuasive content structure, basic SEO foundations, and performance-conscious development tailored to your campaign goals.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Target Businesses</h4>
          <ul className="space-y-1.5">
            {[
              'Businesses running Google Ads or other online advertising campaigns',
              'Small businesses promoting specific services',
              'E-commerce businesses promoting products or special offers',
              'Startups launching new products or services',
              'Real estate businesses promoting properties',
              'Coaches, consultants, and professional service providers',
              'Event organizers promoting events or registrations',
              'Businesses running lead-generation campaigns'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Key Features</h4>
          <ul className="space-y-1.5">
            {[
              'Custom Landing Page Design Based on Campaign Goals',
              'Responsive Design for Mobile, Tablet, and Desktop',
              'Clear Headline and Value Proposition',
              'Structured Content Highlighting Key Benefits',
              'Prominent Call-to-Action Buttons',
              'Contact Forms and Enquiry Functionality',
              'WhatsApp Contact Integration',
              'Product, Service, or Offer Presentation',
              'Basic On-Page SEO Foundations',
              'Performance-Conscious Development',
              'Cross-Device Testing',
              'Revisions and Launch Support'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="pt-2 flex flex-row gap-3">
        <Link to="/contact" className="flex-1">
          <Button variant="navy-blue" className="w-full h-[40px] text-[14px]">
            <span>Start Project</span>
          </Button>
        </Link>
        <Link to="/pricing" className="flex-1">
          <Button variant="chat" className="w-full h-[40px] text-[14px]">
            <span>View Pricing</span>
          </Button>
        </Link>
      </div>
    </div>
  );
};
