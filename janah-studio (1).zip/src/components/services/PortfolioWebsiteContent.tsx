import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';

export const PortfolioWebsiteContent = () => {
  return (
    <div className="space-y-8 text-left">
      <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#30E1CE]/30 shadow-xl space-y-6">
        <h3 className="text-2xl font-bold text-[#17202A]">Portfolio Website</h3>
        <p className="text-sm text-[#66727D] leading-relaxed">
          Janah Studio builds professional, personalized portfolio websites that help individuals showcase their skills, projects, experience, achievements, and services online. Whether you are a student, freelancer, job seeker, creative professional, or experienced specialist, a portfolio website helps you present your work professionally, build credibility, and make it easier for potential clients, employers, and collaborators to discover you. Our service includes responsive design, organized portfolio sections, professional presentation, contact options, basic SEO foundations, and performance-conscious development.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Target Businesses & Individuals</h4>
          <ul className="space-y-1.5">
            {[
              'Freelancers and independent professionals',
              'Students and recent graduates',
              'Job seekers and career professionals',
              'Web developers and software developers',
              'Graphic designers and UI/UX designers',
              'Photographers and videographers',
              'Writers, content creators, and digital marketers',
              'Consultants and other skilled professionals'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Key Features</h4>
          <ul className="space-y-1.5">
            {[
              'Personalized Portfolio Website Design',
              'Responsive Design for Mobile, Tablet, and Desktop',
              'Professional Introduction and About Section',
              'Skills, Services, and Experience Presentation',
              'Projects and Work Showcase',
              'Education, Certifications, and Achievements',
              'Contact Form and Social Media Links',
              'WhatsApp Contact Button',
              'Downloadable CV or Resume Options',
              'Basic On-Page SEO Foundations',
              'Performance-Conscious Development',
              'Cross-Device Testing',
              'Revisions and Launch Support'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="pt-2 flex flex-row gap-3">
        <Link to="/contact" className="flex-1">
          <Button variant="navy-blue" className="w-full h-[40px] text-[14px]">
            <span>Start Project</span>
          </Button>
        </Link>
        <Link to="/pricing" className="flex-1">
          <Button variant="chat" className="w-full h-[40px] text-[14px]">
            <span>View Pricing</span>
          </Button>
        </Link>
      </div>
    </div>
  );
};
