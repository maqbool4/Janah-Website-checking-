import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';

export const EcommerceWebsiteContent = () => {
  return (
    <div className="space-y-8 text-left">
      <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#30E1CE]/30 shadow-xl space-y-6">
        <h3 className="text-2xl font-bold text-[#17202A]">E-commerce Website</h3>
        <p className="text-sm text-[#66727D] leading-relaxed">
          Janah Studio builds professional, customized e-commerce websites that help businesses showcase products, manage online shopping, and reach customers digitally. Our service focuses on creating a smooth shopping experience with responsive design, organized product pages, shopping cart functionality, checkout options, and performance-conscious development. Each store is tailored to the business's products, requirements, and brand.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Target Businesses</h4>
          <ul className="space-y-1.5">
            {[
              'Restaurants and cafés',
              'Fashion brands and clothing businesses',
              'Electronics and accessories stores',
              'Home décor and furniture businesses',
              'Jewelry and gift shops',
              'Grocery and specialty food businesses',
              'Small businesses selling products online',
              'Other retail and product-based businesses'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Key Features</h4>
          <ul className="space-y-1.5">
            {[
              'Customized E-commerce Website Structure',
              'Responsive Design for Mobile, Tablet, and Desktop',
              'Organized Product Categories and Product Pages',
              'Shopping Cart Functionality',
              'Checkout and Order Submission Options',
              'Payment Gateway Integration',
              'WhatsApp and Customer Contact Integration',
              'Professional Branding and Product Presentation',
              'Basic On-Page SEO Foundations',
              'Performance-Conscious Development',
              'Cross-Device Testing',
              'Revisions and Launch Support'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="pt-2 flex flex-row gap-3">
        <Link to="/contact" className="flex-1">
          <Button variant="navy-blue" className="w-full h-[40px] text-[14px]">
            <span>Start Project</span>
          </Button>
        </Link>
        <Link to="/pricing" className="flex-1">
          <Button variant="chat" className="w-full h-[40px] text-[14px]">
            <span>View Pricing</span>
          </Button>
        </Link>
      </div>
    </div>
  );
};
