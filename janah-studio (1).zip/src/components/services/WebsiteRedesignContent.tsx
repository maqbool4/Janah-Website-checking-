import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';

export const WebsiteRedesignContent = () => {
  return (
    <div className="space-y-8 text-left">
      <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-8 border border-[#30E1CE]/30 shadow-xl space-y-6">
        <h3 className="text-2xl font-bold text-[#17202A]">Website Redesign</h3>
        <p className="text-sm text-[#66727D] leading-relaxed">
          Janah Studio helps businesses improve outdated, poorly structured, or underperforming websites through professional website redesign and rebuilding services. We improve website appearance, layout, navigation, mobile usability, and content presentation to create a more modern and user-friendly experience. Depending on your website's condition and requirements, we can refine the existing website or rebuild it when necessary. Our approach focuses on responsive design, improved usability, basic SEO considerations, and performance-conscious development while preserving important existing content and functionality wherever possible.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Target Businesses</h4>
          <ul className="space-y-1.5">
            {[
              'Businesses with outdated website designs',
              'Small businesses seeking a more professional online presence',
              'Businesses with poorly structured or difficult-to-navigate websites',
              'Businesses with websites that do not work well on mobile devices',
              'E-commerce businesses needing an improved shopping experience',
              'Businesses experiencing website usability or performance issues',
              'Businesses rebranding or updating their visual identity',
              'Businesses needing website improvements as their services grow'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-white rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none p-5 border border-[#E2E8EA] shadow-sm">
          <h4 className="text-sm font-bold text-[#17202A] mb-2">Key Features</h4>
          <ul className="space-y-1.5">
            {[
              'Modern Website Design and Layout Improvements',
              'Website Rebuilding When Required',
              'Responsive Design for Mobile, Tablet, and Desktop',
              'Improved Navigation and Content Structure',
              'Better Presentation of Business Information and Services',
              'User Experience and Usability Improvements',
              'Basic On-Page SEO Considerations',
              'Performance-Conscious Development',
              'Preservation of Important Existing Content/Functionality',
              'Cross-Device Testing',
              'Revisions and Launch Support'
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs text-[#66727D]">
                <CheckCircle2 className="w-3 h-3 text-[#1876C7]" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="pt-2 flex flex-row gap-3">
        <Link to="/contact" className="flex-1">
          <Button variant="navy-blue" className="w-full h-[40px] text-[14px]">
            <span>Start Project</span>
          </Button>
        </Link>
        <Link to="/pricing" className="flex-1">
          <Button variant="chat" className="w-full h-[40px] text-[14px]">
            <span>View Pricing</span>
          </Button>
        </Link>
      </div>
    </div>
  );
};
