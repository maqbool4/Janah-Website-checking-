import React, { useEffect, useRef } from 'react';

export const FloatingChat: React.FC = () => {
  const floatRef = useRef<HTMLAnchorElement>(null);
  const whatsappUrl = "https://wa.me/923295430114?text=Hi%20Janah%20Studio%2C%20I%27d%20like%20to%20discuss%20a%20website%20project.";

  useEffect(() => {
    const b = floatRef.current;
    if (!b || b.dataset.ready) return;
    b.dataset.ready = '1';

    let startX: number | undefined, startY: number | undefined, dx = 0, dy = 0;
    let dragging = false, moved = false, timer: any;
    let blockClick = false;

    const onPointerDown = (e: PointerEvent) => {
      if (e.button !== 0 && e.pointerType === 'mouse') return;
      startX = e.clientX - dx;
      startY = e.clientY - dy;
      moved = false;
      dragging = false;
      blockClick = false;

      timer = setTimeout(() => {
        dragging = true;
        b.classList.add('pressed');
        b.setPointerCapture?.(e.pointerId);
      }, 350);
    };

    const onPointerMove = (e: PointerEvent) => {
      if (startX == null || startY == null) return;
      if (!dragging &&
          Math.hypot(e.clientX - (startX + dx),
                     e.clientY - (startY + dy)) > 8) {
        clearTimeout(timer);
        return;
      }
      if (!dragging) return;

      moved = true;
      blockClick = true;
      dx = e.clientX - startX;
      dy = e.clientY - startY;

      const r = b.getBoundingClientRect();
      dx = Math.max(dx, -r.left + 8);
      dx = Math.min(dx, window.innerWidth - r.right - 8);
      dy = Math.max(dy, -r.top + 8);
      dy = Math.min(dy, window.innerHeight - r.bottom - 8);

      b.style.transform = `translate(${dx}px,${dy}px)`;
    };

    const finish = () => {
      clearTimeout(timer);
      b.classList.remove('pressed');
      startX = startY = undefined;
      dragging = false;
      setTimeout(() => { blockClick = false; }, 100);
    };

    const onClick = (e: MouseEvent) => {
      if (blockClick || moved) {
        e.preventDefault();
        moved = false;
      }
    };

    b.addEventListener('pointerdown', onPointerDown);
    b.addEventListener('pointermove', onPointerMove);
    b.addEventListener('pointerup', finish);
    b.addEventListener('pointercancel', finish);
    b.addEventListener('click', onClick);

    return () => {
      b.removeEventListener('pointerdown', onPointerDown);
      b.removeEventListener('pointermove', onPointerMove);
      b.removeEventListener('pointerup', finish);
      b.removeEventListener('pointercancel', finish);
      b.removeEventListener('click', onClick);
    };
  }, []);

  return (
    <>
      <style>{`
        .wa-float {
          position: fixed;
          right: 20px;
          bottom: 22px;
          z-index: 99999;
          width: 45px;
          height: 45px;
          cursor: grab;
          touch-action: none;
          user-select: none;
          -webkit-user-select: none;
          filter:
            drop-shadow(0 3px 0 #0D9488)
            drop-shadow(0 0 6px rgba(48,225,206,.8));
        }

        .wa-float:active { cursor: grabbing; }

        .wa-back {
          position: absolute;
          inset: 4px -3px -3px 4px;
          background: linear-gradient(
            145deg,
            #E8FFFC 0%,
            #30E1CE 25%,
            #14B8A6 65%,
            #087F73 100%
          ) !important;
          border: 1px solid #BFFFF6 !important;
          border-radius: 15px 15px 3px 15px;
          transform: rotate(5deg);
          box-shadow: 0 0 12px rgba(48,225,206,.65);
        }

        .wa-front {
          position: absolute;
          inset: 0;
          display: grid;
          place-items: center;
          background: linear-gradient(
            135deg,
            #30E1CE 0%,
            #14B8A6 32%,
            #10B981 62%,
            #30E1CE 100%
          ) !important;
          border: 1.5px solid #E8FFFC !important;
          border-radius: 15px 15px 3px 15px;
          clip-path: polygon(0 0,100% 0,100% 82%,78% 100%,0 100%);
          box-shadow:
            inset 2px 2px 5px rgba(255,255,255,.65),
            inset -3px -3px 8px rgba(0,80,75,.25),
            0 0 8px #30E1CE !important;
        }

        .wa-logo {
          width: 28px;
          height: 28px;
          color: #FFFFFF;
          filter: drop-shadow(0 1px 1px #087c73);
        }

        .wa-person {
          position: absolute;
          width: 21px;
          height: 21px;
          right: -5px;
          top: -9px;
          background: linear-gradient(
            135deg,
            #30E1CE,
            #10B981
          ) !important;
          border: 2px solid #FFFFFF !important;
          border-radius: 50%;
          display: grid;
          place-items: center;
          box-shadow:
            0 0 8px #30E1CE,
            inset 0 0 5px rgba(255,255,255,.5);
        }

        .wa-person svg { width: 14px; height: 14px; }

        .wa-signal {
          position: absolute;
          top: -8px;
          right: -10px;
          width: 13px;
          height: 18px;
          border-right: 2px solid #30E1CE;
          border-right-color: #30E1CE !important;
          border-radius: 50%;
          pointer-events: none;
          filter: drop-shadow(0 0 3px #30E1CE);
        }

        .wa-signal.two {
          right: -14px;
          top: -11px;
          width: 18px;
          height: 24px;
          opacity: .8;
        }

        .wa-float.pressed .wa-front {
          filter: brightness(.88);
        }
      `}</style>

      <a
        ref={floatRef}
        className="wa-float"
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with Janah Studio on WhatsApp"
      >
        <span className="wa-back"></span>
        <span className="wa-front">
          <svg className="wa-logo" viewBox="0 0 48 48" fill="none">
            <path d="M24 4.5a19 19 0 0 0-16.4 28.6L5 43l10.3-2.7A19 19 0 1 0 24 4.5Z"
              stroke="white" strokeWidth="3.5"
              strokeLinejoin="round"/>
            <path d="M17 14c-1 0-2 1-2.5 2.5-.6 1.5.1 4 2.1 6.7 2.5 3.5 5.3 5.7 8.5 7 2.5 1.1 4 .8 5.3-.3l2-2.4-5-2.5-2.4 2.2c-2.4-1-4.7-3.2-5.6-5.2l1.7-2.1-2.2-5.1Z"
              fill="white"/>
          </svg>
        </span>

        <span className="wa-person">
          <svg viewBox="0 0 24 24" fill="white">
            <circle cx="12" cy="7" r="4"/>
            <path d="M4 21v-3a8 8 0 0 1 16 0v3Z"/>
          </svg>
        </span>
        <span className="wa-signal"></span>
        <span className="wa-signal two"></span>
      </a>
    </>
  );
};
