import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  X, 
  ArrowRight, 
  Sparkles, 
  Briefcase, 
  Layers, 
  DollarSign, 
  HelpCircle, 
  FileText, 
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { dataStore } from '../lib/dataStore';
import { ServiceItem, PricingPackage, PortfolioProject, FaqItem } from '../lib/types';

interface InlineSearchProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SearchItem {
  id: string;
  title: string;
  type: 'Service' | 'Pricing' | 'Portfolio' | 'Career' | 'FAQ' | 'Page';
  path: string;
  desc: string;
  badgeColor: string;
}

const STATIC_CAREER_ROLES: SearchItem[] = [
  {
    id: 'career-lead-gen',
    title: 'Lead Generation & Client Acquisition Partner',
    type: 'Career',
    path: '/careers',
    desc: 'Find potential businesses that need websites or online stores, contact prospective clients, explain Janah Studio services, and generate genuine project enquiries.',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200'
  },
  {
    id: 'career-lead-research',
    title: 'Lead Research Partner',
    type: 'Career',
    path: '/careers',
    desc: 'Research suitable businesses, collect publicly available business information, identify businesses with potential website needs, and submit organized lead lists.',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200'
  },
  {
    id: 'career-web-dev',
    title: 'Web Development Partner',
    type: 'Career',
    path: '/careers',
    desc: 'Build modern responsive websites and interactive web applications using React, Next.js, and modern frontend tools.',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200'
  },
  {
    id: 'career-wordpress',
    title: 'WordPress Development Partner',
    type: 'Career',
    path: '/careers',
    desc: 'Custom WordPress theme development, WooCommerce configurations, Elementor builds, speed optimization, and secure site setups.',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200'
  },
  {
    id: 'career-ecommerce',
    title: 'E-commerce Development Partner',
    type: 'Career',
    path: '/careers',
    desc: 'Design and build high-converting Shopify, WooCommerce, and custom online storefronts with seamless checkouts.',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200'
  },
  {
    id: 'career-ui-ux',
    title: 'UI/UX Design Partner',
    type: 'Career',
    path: '/careers',
    desc: 'Design sleek modern web and mobile application prototypes, wireframes, component design systems, and Figma designs.',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200'
  },
  {
    id: 'career-video',
    title: 'Video Editing & Motion Graphics Partner',
    type: 'Career',
    path: '/careers',
    desc: 'Edit promo videos, reels, client walkthroughs, kinetic typography, and motion animations for brand presentations.',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200'
  },
  {
    id: 'career-seo-content',
    title: 'SEO, Content & Digital Marketing Partner',
    type: 'Career',
    path: '/careers',
    desc: 'SEO copywriting, conversion copywriting, on-page optimization, keyword strategy, and social media management.',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200'
  }
];

const STATIC_PAGES: SearchItem[] = [
  {
    id: 'page-home',
    title: 'Home - Janah Studio',
    type: 'Page',
    path: '/',
    desc: 'Modern website design, development, and conversion-focused digital experiences for growing businesses.',
    badgeColor: 'bg-slate-100 text-slate-700 border-slate-200'
  },
  {
    id: 'page-services',
    title: 'Services & Website Solutions',
    type: 'Page',
    path: '/services',
    desc: 'Explore custom web design, business sites, e-commerce stores, landing pages, and redesigns.',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200'
  },
  {
    id: 'page-pricing',
    title: 'Pricing & Packages',
    type: 'Page',
    path: '/pricing',
    desc: 'Transparent pricing packages for landing pages, multi-page business websites, and online stores.',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200'
  },
  {
    id: 'page-portfolio',
    title: 'Portfolio & Client Projects',
    type: 'Page',
    path: '/portfolio',
    desc: 'Browse recent client websites, e-commerce stores, UI/UX case studies, and live digital projects.',
    badgeColor: 'bg-purple-100 text-purple-800 border-purple-200'
  },
  {
    id: 'page-careers',
    title: 'Work With Janah Studio (Careers & Partners)',
    type: 'Career',
    path: '/careers',
    desc: 'Join our network of freelancers and service partners across lead generation, web development, design, and digital support.',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200'
  },
  {
    id: 'page-maintenance',
    title: 'Maintenance & Support Services',
    type: 'Page',
    path: '/maintenance-support',
    desc: 'Website security, daily backups, speed optimization, technical support, and monthly updates.',
    badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-200'
  },
  {
    id: 'page-faq',
    title: 'Frequently Asked Questions (FAQ)',
    type: 'FAQ',
    path: '/faq',
    desc: 'Answers to common questions about timelines, pricing, revisions, technologies, and project process.',
    badgeColor: 'bg-teal-100 text-teal-800 border-teal-200'
  },
  {
    id: 'page-contact',
    title: 'Contact Janah Studio',
    type: 'Page',
    path: '/contact',
    desc: 'Start your website project today. Reach out via contact form or direct WhatsApp message.',
    badgeColor: 'bg-sky-100 text-sky-800 border-sky-200'
  }
];

export const InlineSearch: React.FC<InlineSearchProps> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'Service' | 'Pricing' | 'Portfolio' | 'Career' | 'FAQ'>('ALL');
  const [results, setResults] = useState<SearchItem[]>([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      document.body.style.overflow = '';
      setQuery('');
      setResults([]);
      setActiveFilter('ALL');
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  useEffect(() => {
    let isCancelled = false;
    const fetchResults = async () => {
      const q = query.trim().toLowerCase();
      if (!q) {
        setResults([]);
        setLoading(false);
        return;
      }

      setLoading(true);
      try {
        const [services, pricing, portfolio, faqs] = await Promise.all([
          dataStore.getServices().catch(() => []),
          dataStore.getPricing().catch(() => []),
          dataStore.getPortfolio().catch(() => []),
          dataStore.getFaqs().catch(() => [])
        ]);

        if (isCancelled) return;

        const serviceItems: SearchItem[] = services
          .filter(s => s.title.toLowerCase().includes(q) || (s.short_description && s.short_description.toLowerCase().includes(q)))
          .map((s: ServiceItem) => ({
            id: `service-${s.id}`,
            title: s.title,
            type: 'Service',
            path: '/services',
            desc: s.short_description || 'Professional website development service by Janah Studio.',
            badgeColor: 'bg-blue-100 text-blue-800 border-blue-200'
          }));

        const pricingItems: SearchItem[] = pricing
          .filter(p => p.package_name.toLowerCase().includes(q) || (p.description && p.description.toLowerCase().includes(q)))
          .map((p: PricingPackage) => ({
            id: `pricing-${p.id}`,
            title: p.package_name,
            type: 'Pricing',
            path: '/pricing',
            desc: `${p.starting_price} — ${p.description || 'Complete website design and launch package.'}`,
            badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200'
          }));

        const portfolioItems: SearchItem[] = portfolio
          .filter((proj: PortfolioProject) => proj.project_name.toLowerCase().includes(q) || (proj.short_description && proj.short_description.toLowerCase().includes(q)))
          .map((proj: PortfolioProject) => ({
            id: `portfolio-${proj.id}`,
            title: proj.project_name,
            type: 'Portfolio',
            path: '/portfolio',
            desc: proj.short_description || 'Live website design project created by Janah Studio.',
            badgeColor: 'bg-purple-100 text-purple-800 border-purple-200'
          }));

        const faqItems: SearchItem[] = faqs
          .filter(f => f.question.toLowerCase().includes(q) || (f.answer && f.answer.toLowerCase().includes(q)))
          .map((f: FaqItem) => ({
            id: `faq-${f.id}`,
            title: f.question,
            type: 'FAQ',
            path: '/faq',
            desc: f.answer,
            badgeColor: 'bg-teal-100 text-teal-800 border-teal-200'
          }));

        const careerMatches: SearchItem[] = STATIC_CAREER_ROLES.filter(c =>
          c.title.toLowerCase().includes(q) || c.desc.toLowerCase().includes(q)
        );

        const pageMatches: SearchItem[] = STATIC_PAGES.filter(p =>
          p.title.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q)
        );

        const combined = [
          ...pageMatches,
          ...careerMatches,
          ...serviceItems,
          ...pricingItems,
          ...portfolioItems,
          ...faqItems
        ];

        // Deduplicate by id
        const unique = Array.from(new Map(combined.map(item => [item.id, item])).values());
        setResults(unique);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        if (!isCancelled) setLoading(false);
      }
    };

    const timer = setTimeout(fetchResults, 150);
    return () => {
      isCancelled = true;
      clearTimeout(timer);
    };
  }, [query]);

  if (!isOpen) return null;

  const filteredResults = activeFilter === 'ALL'
    ? results
    : results.filter(r => r.type === activeFilter);

  const handleSelect = (path: string) => {
    navigate(path);
    onClose();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const popularSearches = [
    { label: 'Work With Us (Careers)', query: 'career' },
    { label: 'Web Development', query: 'web development' },
    { label: 'E-commerce Store', query: 'e-commerce' },
    { label: 'Pricing Plans', query: 'pricing' },
    { label: 'Portfolio Projects', query: 'portfolio' },
    { label: 'Lead Research', query: 'lead research' },
    { label: 'Contact WhatsApp', query: 'contact' }
  ];

  return (
    <div 
      className="fixed inset-0 z-[100] flex flex-col items-center justify-start pt-8 sm:pt-20 px-3 sm:px-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-2xl bg-white rounded-2xl sm:rounded-3xl shadow-2xl border border-[#E2E8EA] overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Search Input Bar */}
        <div className="flex items-center gap-3 px-4 sm:px-6 h-16 sm:h-20 border-b border-[#E2E8EA] bg-[#F8FAFA]">
          <div className="w-10 h-10 rounded-xl bg-[#1876C7]/10 text-[#1876C7] flex items-center justify-center shrink-0">
            <Search className="w-5 h-5" />
          </div>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search services, pricing, careers, portfolio, FAQ..."
            className="flex-grow h-full text-base sm:text-lg text-[#17202A] placeholder-[#66727D] focus:outline-none bg-transparent font-medium"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="p-1.5 text-xs text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Clear
            </button>
          )}
          <div className="hidden sm:flex items-center text-[10px] font-semibold text-gray-400 px-2 py-1 rounded bg-gray-100 border border-gray-200">
            ESC
          </div>
          <button 
            type="button"
            onClick={onClose} 
            aria-label="Close search"
            className="p-2 rounded-xl hover:bg-rose-50 text-gray-500 hover:text-rose-600 transition-colors shrink-0"
            title="Close Search"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Badges Bar */}
        {results.length > 0 && (
          <div className="flex items-center gap-1.5 px-4 sm:px-6 py-2.5 bg-white border-b border-gray-100 overflow-x-auto text-xs">
            <button
              onClick={() => setActiveFilter('ALL')}
              className={`px-3 py-1 rounded-full font-semibold transition-all shrink-0 ${
                activeFilter === 'ALL'
                  ? 'bg-[#1876C7] text-white shadow-xs'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              All ({results.length})
            </button>
            {(['Service', 'Pricing', 'Portfolio', 'Career', 'FAQ'] as const).map(cat => {
              const count = results.filter(r => r.type === cat).length;
              if (count === 0) return null;
              return (
                <button
                  key={cat}
                  onClick={() => setActiveFilter(cat)}
                  className={`px-3 py-1 rounded-full font-semibold transition-all shrink-0 ${
                    activeFilter === cat
                      ? 'bg-[#1876C7] text-white shadow-xs'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {cat === 'Career' ? 'Careers & Roles' : cat} ({count})
                </button>
              );
            })}
          </div>
        )}

        {/* Content Body */}
        <div className="flex-grow overflow-y-auto p-4 sm:p-6 divide-y divide-gray-100">
          {/* Default State: Popular Suggestions */}
          {!query.trim() && (
            <div className="space-y-6 py-2">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#66727D] block mb-3">
                  Popular Searches
                </span>
                <div className="flex flex-wrap gap-2">
                  {popularSearches.map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => setQuery(item.query)}
                      className="px-3 py-1.5 rounded-xl bg-[#F8FAFA] hover:bg-[#1876C7]/10 text-[#17202A] hover:text-[#1876C7] text-xs font-medium border border-[#E2E8EA] hover:border-[#1876C7]/30 transition-all flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#30E1CE]" />
                      <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#66727D] block mb-3">
                  Quick Navigation
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {STATIC_PAGES.slice(0, 6).map((page) => (
                    <button
                      key={page.id}
                      onClick={() => handleSelect(page.path)}
                      className="p-3 text-left rounded-xl hover:bg-[#F8FAFA] border border-transparent hover:border-[#E2E8EA] transition-all flex items-center justify-between group"
                    >
                      <div className="min-w-0 pr-2">
                        <span className="text-xs font-bold text-[#17202A] group-hover:text-[#1876C7] block truncate">
                          {page.title}
                        </span>
                        <span className="text-[11px] text-[#66727D] block truncate">
                          {page.desc}
                        </span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-[#1876C7] shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Loading State */}
          {query.trim() && loading && (
            <div className="py-12 text-center text-sm text-[#66727D]">
              Searching Janah Studio...
            </div>
          )}

          {/* No Results State */}
          {query.trim() && !loading && filteredResults.length === 0 && (
            <div className="py-12 text-center">
              <div className="w-12 h-12 rounded-2xl bg-gray-100 text-gray-400 flex items-center justify-center mx-auto mb-3">
                <Search className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-[#17202A]">No matches found for "{query}"</h4>
              <p className="text-xs text-[#66727D] max-w-sm mx-auto mt-1">
                Try searching for keywords like "web development", "pricing", "lead generation", or "contact".
              </p>
            </div>
          )}

          {/* Results List */}
          {query.trim() && !loading && filteredResults.length > 0 && (
            <div className="space-y-2 pt-1">
              {filteredResults.map((res) => (
                <button
                  key={res.id}
                  onClick={() => handleSelect(res.path)}
                  className="w-full text-left p-3.5 sm:p-4 rounded-xl hover:bg-[#F8FAFA] border border-transparent hover:border-[#E2E8EA] transition-all group flex items-start justify-between gap-3"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border uppercase ${res.badgeColor}`}>
                        {res.type === 'Career' ? 'Career Role' : res.type}
                      </span>
                      <h4 className="text-sm font-bold text-[#17202A] group-hover:text-[#1876C7] transition-colors truncate">
                        {res.title}
                      </h4>
                    </div>
                    <p className="text-xs text-[#66727D] line-clamp-2 leading-relaxed">
                      {res.desc}
                    </p>
                  </div>
                  <div className="shrink-0 pt-1 text-gray-300 group-hover:text-[#1876C7] transition-colors">
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-4 sm:px-6 py-3 bg-[#F8FAFA] border-t border-[#E2E8EA] flex items-center justify-between text-xs text-[#66727D]">
          <span>Janah Studio Search</span>
          <button
            onClick={onClose}
            className="text-xs font-semibold text-[#1876C7] hover:underline"
          >
            Close Search
          </button>
        </div>
      </div>
    </div>
  );
};
