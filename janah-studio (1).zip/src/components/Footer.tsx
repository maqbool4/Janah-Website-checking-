import React from 'react';
import { Link } from 'react-router-dom';
import { Code, MessageCircle, Mail, ShieldAlert } from 'lucide-react';
import { Button } from './ui/Button';

export const Footer: React.FC = () => {
  const whatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent("Hi Janah Studio, I'd like to discuss a website project.")}`;

  const socialLinks = [
    {
      name: 'Facebook',
      url: 'https://facebook.com',
      bgClass: 'bg-[#1877F2] shadow-[0_2.5px_0_#0d56b3]',
      icon: (
        <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      )
    },
    {
      name: 'Instagram',
      url: 'https://instagram.com',
      bgClass: 'bg-gradient-to-tr from-[#f09433] via-[#dc2743] to-[#bc1888] shadow-[0_2.5px_0_#83105d]',
      icon: (
        <svg className="w-3.5 h-3.5 fill-none stroke-current" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24">
          <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
          <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
          <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
        </svg>
      )
    },
    {
      name: 'YouTube',
      url: 'https://youtube.com',
      bgClass: 'bg-[#FF0000] shadow-[0_2.5px_0_#b30000]',
      icon: (
        <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
          <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
        </svg>
      )
    },
    {
      name: 'TikTok',
      url: 'https://tiktok.com',
      bgClass: 'bg-[#010101] shadow-[0_2.5px_0_#000000]',
      icon: (
        <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
          <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
        </svg>
      )
    },
    {
      name: 'Pinterest',
      url: 'https://pinterest.com',
      bgClass: 'bg-[#E60023] shadow-[0_2.5px_0_#990017]',
      icon: (
        <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
          <path d="M12 0a12 12 0 0 0-4.37 23.17c-.07-.63-.13-1.6.03-2.29.14-.62.93-3.95.93-3.95s-.24-.48-.24-1.18c0-1.11.64-1.94 1.44-1.94.68 0 1 .51 1 1.12 0 .68-.43 1.7-.66 2.64-.19.79.4 1.44 1.18 1.44 1.41 0 2.5-1.49 2.5-3.64 0-1.9-1.37-3.23-3.32-3.23-2.26 0-3.59 1.7-3.59 3.45 0 .68.26 1.42.59 1.82.06.08.07.15.05.23-.07.28-.22.89-.25 1.01-.04.16-.13.2-.3.12-1.13-.53-1.84-2.18-1.84-3.51 0-2.86 2.08-5.49 6-5.49 3.15 0 5.6 2.25 5.6 5.25 0 3.13-1.97 5.65-4.71 5.65-.92 0-1.79-.48-2.08-1.05l-.57 2.16c-.2.79-.76 1.78-1.13 2.38A12 12 0 1 0 12 0z"/>
        </svg>
      )
    },
    {
      name: 'Google Maps',
      url: 'https://maps.google.com',
      bgClass: 'bg-[#34A853] shadow-[0_2.5px_0_#1e6e34]',
      icon: (
        <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
          <path d="M12 0C7.58 0 4 3.58 4 8c0 5.25 7.13 15.3 7.43 15.72a.75.75 0 0 0 1.14 0C12.87 23.3 20 13.25 20 8c0-4.42-3.58-8-8-8zm0 11.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z"/>
        </svg>
      )
    }
  ];

  return (
    <footer className="bg-[#241F1C] text-white pt-12 pb-8 border-t border-[#E2E8EA]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-8 border-b border-white/10">
          
          {/* Brand Info (Left Col) */}
          <div className="lg:col-span-5 space-y-3 text-left">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-[#30E1CE] to-[#1876C7] flex items-center justify-center text-white font-bold shadow-md">
                <Code className="w-4 h-4" />
              </div>
              <span className="text-lg font-bold tracking-tight text-white">
                Janah Studio
              </span>
            </Link>
            <p className="text-xs text-gray-300 max-w-sm leading-relaxed">
              Janah Studio is a web development studio helping small businesses build professional websites and online stores that help them get discovered and grow online.
            </p>
            <div className="flex items-center gap-2.5 pt-1">
              <Button
                variant="whatsapp"
                onClick={() => window.open(whatsappUrl, '_blank')}
                className="text-xs"
              >
                <MessageCircle className="w-3.5 h-3.5 text-white" />
                <span>WhatsApp</span>
              </Button>
              <Button
                variant="email"
                onClick={() => window.location.href = 'mailto:janahstudio.official@gmail.com'}
                className="text-xs"
              >
                <Mail className="w-3.5 h-3.5 text-white" />
                <span>Email Us</span>
              </Button>
            </div>
          </div>

          {/* Unified Pages List (Right Col in a 4-Column Grid) */}
          <div className="lg:col-span-7 space-y-3 text-left">
            <h3 className="text-xs font-semibold tracking-wider text-[#30E1CE] uppercase">Pages</h3>
            <div className="grid grid-cols-4 gap-y-3 gap-x-4 text-xs text-gray-300">
              <Link to="/" className="hover:text-white transition-colors">Home</Link>
              <Link to="/services" className="hover:text-white transition-colors">Services</Link>
              <Link to="/pricing" className="hover:text-white transition-colors">Pricing</Link>
              <Link to="/portfolio" className="hover:text-white transition-colors">Portfolio</Link>
              <Link to="/about" className="hover:text-white transition-colors">About</Link>
              <Link to="/faq" className="hover:text-white transition-colors">FAQ</Link>
              <Link to="/contact" className="hover:text-white transition-colors">Contact</Link>
              <Link to="/careers" className="text-[#30E1CE] hover:text-white transition-colors font-semibold">Careers</Link>
              <Link to="/privacy-policy" className="hover:text-white transition-colors">Privacy</Link>
              <Link to="/terms" className="hover:text-white transition-colors">Terms</Link>
              <Link to="/cookie-policy" className="hover:text-white transition-colors">Cookies</Link>
              <Link to="/dashboard" className="text-[#30E1CE] hover:text-white transition-colors font-semibold">
                Admin
              </Link>
            </div>
          </div>

        </div>

        {/* Centralized Branded Social Media Icons (Smaller, compact 28x28px square buttons) */}
        <div className="pt-6 pb-2 flex flex-col items-center justify-center gap-2">
          <div className="flex flex-wrap items-center justify-center gap-6">
            {socialLinks.map((social) => (
              <a
                key={social.name}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`Follow Janah Studio on ${social.name}`}
                title={social.name}
                className={`w-[28px] h-[28px] rounded-tl-[8px] rounded-br-[8px] rounded-tr-none rounded-bl-none ${social.bgClass} text-white hover:brightness-110 hover:scale-105 active:shadow-none active:translate-y-[2px] transition-all flex items-center justify-center cursor-pointer shrink-0`}
              >
                {social.icon}
              </a>
            ))}
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-400 gap-2">
          <p>© 2026 Janah Studio. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};
