import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const CONFIG_FILE = path.join(__dirname, '.aistudio', 'google-sheets-config.json');
const APPLICATIONS_FILE = path.join(__dirname, '.aistudio', 'career-applications.json');

// Ensure directory exists
try {
  const dir = path.dirname(CONFIG_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
} catch (e) {
  console.warn('Could not ensure .aistudio dir:', e);
}

export interface ServerSheetsConfig {
  accessToken: string;
  spreadsheetId: string;
  spreadsheetUrl: string;
  spreadsheetTitle?: string;
  userEmail?: string;
  connectedAt?: string;
  totalSynced: number;
}

export interface CandidateSubmission {
  id: string;
  referenceId: string;
  fullName: string;
  email: string;
  phone: string;
  location: string;
  position: string;
  experienceLevel: string;
  yearsExperience: number | string;
  workTypes: string[];
  skills: string[];
  leadSources?: string[];
  customSkills?: string;
  portfolioUrl?: string;
  socialUrl?: string;
  previousExperience?: string;
  coverLetter?: string;
  additionalMessage?: string;
  expectedRate?: string;
  bankName?: string;
  createdAt: string;
  savedToGoogleSheets: boolean;
  googleSheetsRow?: number;
}

export const getSheetsConfig = (): ServerSheetsConfig | null => {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = fs.readFileSync(CONFIG_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading sheets config:', err);
  }
  return null;
};

export const saveSheetsConfig = (config: ServerSheetsConfig | null) => {
  try {
    if (!config) {
      if (fs.existsSync(CONFIG_FILE)) {
        fs.unlinkSync(CONFIG_FILE);
      }
      return;
    }
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving sheets config:', err);
  }
};

export const getLocalApplications = (): CandidateSubmission[] => {
  try {
    if (fs.existsSync(APPLICATIONS_FILE)) {
      const data = fs.readFileSync(APPLICATIONS_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading local applications:', err);
  }
  return [];
};

export const saveLocalApplication = (application: CandidateSubmission) => {
  try {
    const list = getLocalApplications();
    const updated = [application, ...list.filter(a => a.id !== application.id)];
    fs.writeFileSync(APPLICATIONS_FILE, JSON.stringify(updated, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving local application:', err);
  }
};

export const updateLocalApplicationStatus = (id: string, status: string): boolean => {
  try {
    const list = getLocalApplications();
    const item = list.find((a: any) => a.id === id);
    if (item) {
      (item as any).status = status;
      fs.writeFileSync(APPLICATIONS_FILE, JSON.stringify(list, null, 2), 'utf-8');
      return true;
    }
  } catch (err) {
    console.error('Error updating application status:', err);
  }
  return false;
};

export const deleteLocalApplication = (id: string): boolean => {
  try {
    const list = getLocalApplications();
    const updated = list.filter((a: any) => a.id !== id);
    fs.writeFileSync(APPLICATIONS_FILE, JSON.stringify(updated, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error deleting application:', err);
  }
  return false;
};

export const DEFAULT_HEADERS = [
  'Timestamp',
  'Reference ID',
  'Full Name',
  'Email',
  'WhatsApp / Phone',
  'Country / Location',
  'Position / Service Category',
  'Experience Level',
  'Years of Experience',
  'Work Availability',
  'Relevant Skills',
  'Preferred Lead Sources',
  'Additional Skills / Expertise',
  'Portfolio or CV Link',
  'Social Profile (Instagram / Facebook / LinkedIn)',
  'Previous Experience',
  'Motivation (Why Janah Studio)',
  'Additional Message',
  'Expected Compensation / Rate',
  'Preferred Payment Method (Bank/Binance/JazzCash)',
  'Application Status'
];

const getLastColumnLetter = (count: number): string => {
  let result = '';
  let n = count;
  while (n > 0) {
    const rem = (n - 1) % 26;
    result = String.fromCharCode(65 + rem) + result;
    n = Math.floor((n - 1) / 26);
  }
  return result || 'U';
};

/**
 * Creates a new spreadsheet named "Janah Studio - Careers Applications" using the access token
 */
export const createSpreadsheetWithHeaders = async (accessToken: string): Promise<{ id: string; url: string; title: string }> => {
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        title: 'Janah Studio - Careers Applications'
      },
      sheets: [
        {
          properties: {
            title: 'Applications',
            gridProperties: {
              frozenRowCount: 1
            }
          }
        }
      ]
    })
  });

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(`Google Sheets API Error (${createRes.status}): ${errText}`);
  }

  const sheetData = await createRes.json();
  const spreadsheetId = sheetData.spreadsheetId;
  const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  const lastCol = getLastColumnLetter(DEFAULT_HEADERS.length);

  // Write headers
  await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Applications!A1:${lastCol}1?valueInputOption=USER_ENTERED`, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      range: `Applications!A1:${lastCol}1`,
      majorDimension: 'ROWS',
      values: [DEFAULT_HEADERS]
    })
  });

  return { id: spreadsheetId, url: spreadsheetUrl, title: sheetData.properties?.title || 'Janah Studio - Careers Applications' };
};

/**
 * Ensures header row exists on an existing spreadsheet
 */
export const ensureHeadersExist = async (spreadsheetId: string, accessToken: string): Promise<string> => {
  // First fetch sheets metadata
  const metaRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!metaRes.ok) {
    const err = await metaRes.text();
    throw new Error(`Cannot access spreadsheet: ${err}`);
  }

  const meta = await metaRes.json();
  const sheets = meta.sheets || [];
  const targetSheet = sheets.find((s: any) => s.properties?.title?.toLowerCase() === 'applications') || sheets[0];
  const sheetTitle = targetSheet?.properties?.title || 'Sheet1';
  const lastCol = getLastColumnLetter(DEFAULT_HEADERS.length);

  // Check if A1 has header
  const valRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetTitle)}!A1:${lastCol}1`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (valRes.ok) {
    const valData = await valRes.json();
    if (!valData.values || valData.values.length === 0) {
      // Append headers
      await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetTitle)}!A1:${lastCol}1?valueInputOption=USER_ENTERED`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          range: `${sheetTitle}!A1:${lastCol}1`,
          majorDimension: 'ROWS',
          values: [DEFAULT_HEADERS]
        })
      });
    }
  }

  return sheetTitle;
};

/**
 * Appends a candidate submission as a new row to Google Sheets
 */
export const appendApplicationToSheet = async (
  spreadsheetId: string,
  accessToken: string,
  app: CandidateSubmission
): Promise<{ updatedRange: string; updatedRows: number }> => {
  const sheetTitle = await ensureHeadersExist(spreadsheetId, accessToken);
  const lastCol = getLastColumnLetter(DEFAULT_HEADERS.length);

  const rowValues = [
    app.createdAt || new Date().toISOString(),
    app.referenceId || '',
    app.fullName || '',
    app.email || '',
    app.phone || '',
    app.location || '',
    app.position || '',
    app.experienceLevel || '',
    String(app.yearsExperience || '0'),
    Array.isArray(app.workTypes) ? app.workTypes.join(', ') : '',
    Array.isArray(app.skills) ? app.skills.join(', ') : '',
    Array.isArray(app.leadSources) ? app.leadSources.join(', ') : '',
    app.customSkills || '',
    app.portfolioUrl || '',
    app.socialUrl || '',
    app.previousExperience || '',
    app.coverLetter || '',
    app.additionalMessage || '',
    app.expectedRate || 'Negotiable',
    app.bankName || 'Not specified',
    'New Application'
  ];

  const appendRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetTitle)}!A:${lastCol}:append?valueInputOption=USER_ENTERED`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        range: `${sheetTitle}!A:${lastCol}`,
        majorDimension: 'ROWS',
        values: [rowValues]
      })
    }
  );

  if (!appendRes.ok) {
    const errText = await appendRes.text();
    throw new Error(`Google Sheets append failed (${appendRes.status}): ${errText}`);
  }

  const result = await appendRes.json();
  return {
    updatedRange: result.updates?.updatedRange || '',
    updatedRows: result.updates?.updatedRows || 1
  };
};
