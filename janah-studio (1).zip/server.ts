import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import {
  getSheetsConfig,
  saveSheetsConfig,
  createSpreadsheetWithHeaders,
  ensureHeadersExist,
  appendApplicationToSheet,
  getLocalApplications,
  saveLocalApplication,
  updateLocalApplicationStatus,
  deleteLocalApplication,
  type ServerSheetsConfig,
  type CandidateSubmission
} from './serverSheets';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

const apiKey = process.env.GEMINI_API_KEY;

// Initialize the GoogleGenAI client with Recommended settings
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// AI Reply Draft Generator API Route
app.post('/api/generate-reply', async (req, res) => {
  const { name, business_name, service, project_description, budget, type } = req.body;
  if (!name || !service || !project_description) {
    return res.status(400).json({ error: 'Missing required lead details' });
  }

  try {
    const prompt = `You are the lead consultant and developer at "Janah Studio" (a professional web development studio specializing in custom, high-converting websites, e-commerce stores, and online presence for small businesses).
    
Generate a professional, warm, and highly converting reply draft for a new project inquiry.

Lead Details:
- Client Name: ${name}
- Business Name: ${business_name || 'Not provided'}
- Requested Service: ${service}
- Project Description: ${project_description}
- Client Budget: ${budget || 'Not specified'}
- Reply Channel: ${type || 'email'}

Guidelines:
- If reply channel is 'email', generate a professional subject line and a beautifully formatted email body. Use a warm, consultative, and structured tone. Do not use generic placeholders like [Your Name]; sign off as "The Janah Studio Team".
- If reply channel is 'whatsapp', generate a concise, friendly message with clear spacing, helpful emojis, and a clear call to action to continue the discussion on WhatsApp.
- Emphasize how Janah Studio is the perfect fit to build a modern, responsive, and performance-optimized website that drives real results for their business.
- Provide a brief 2-sentence recommendation of what the best technical approach or solution could look like based on their description.
- Keep the tone professional, reassuring, and enthusiastic. Ensure there are no generic bracketed placeholders in the final response.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });

    const draft = response.text || '';
    res.json({ draft });
  } catch (error: any) {
    console.error('Error in /api/generate-reply:', error);
    res.status(500).json({ error: error.message || 'Failed to generate reply draft' });
  }
});

// Contact Submissions Storage & API
const CONTACT_SUBMISSIONS_FILE = path.join(__dirname, '.aistudio', 'contact-submissions.json');

const getLocalContactSubmissions = (): any[] => {
  try {
    if (fs.existsSync(CONTACT_SUBMISSIONS_FILE)) {
      const raw = fs.readFileSync(CONTACT_SUBMISSIONS_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      // Filter out any old legacy test entries
      return Array.isArray(parsed) ? parsed.filter(s => s && s.name !== 'Ahmad Khan' && s.id !== 'sub-1') : [];
    }
  } catch (e) {
    console.error('Error reading contact submissions file:', e);
  }
  return [];
};

const saveLocalContactSubmission = (submission: any): void => {
  try {
    const list = getLocalContactSubmissions();
    const existingIndex = list.findIndex((s: any) => s.id === submission.id);
    if (existingIndex >= 0) {
      list[existingIndex] = submission;
    } else {
      list.unshift(submission);
    }
    const dir = path.dirname(CONTACT_SUBMISSIONS_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(CONTACT_SUBMISSIONS_FILE, JSON.stringify(list, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error saving contact submission:', e);
  }
};

// Rate limiter / duplicate prevention map
const contactRateLimits = new Map<string, number>();

app.post('/api/contact/submit', (req, res) => {
  try {
    const body = req.body;
    const { name, email, enquiry_type, project_description, service } = body;

    // Validation
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ error: 'Full Name is required.' });
    }
    if (!email || typeof email !== 'string' || !email.includes('@')) {
      return res.status(400).json({ error: 'A valid Email Address is required.' });
    }
    if (!enquiry_type || typeof enquiry_type !== 'string' || !enquiry_type.trim()) {
      return res.status(400).json({ error: 'Enquiry Type is required.' });
    }

    // Check rate limit (prevent spam / duplicate double-clicks)
    const clientKey = `${req.ip || 'ip'}_${email.trim().toLowerCase()}`;
    const lastSubTime = contactRateLimits.get(clientKey);
    const now = Date.now();
    if (lastSubTime && now - lastSubTime < 3000) {
      return res.status(429).json({ error: 'Please wait a moment before submitting again.' });
    }
    contactRateLimits.set(clientKey, now);

    const submissionRecord = {
      ...body,
      id: body.id || `enq-${now}-${Math.floor(100 + Math.random() * 900)}`,
      name: name.trim(),
      email: email.trim(),
      enquiry_type: enquiry_type.trim(),
      service: service || '',
      project_description: (project_description || '').trim(),
      status: body.status || 'New',
      created_at: body.created_at || new Date().toISOString()
    };

    saveLocalContactSubmission(submissionRecord);

    return res.json({
      success: true,
      id: submissionRecord.id,
      message: 'Enquiry received successfully.'
    });
  } catch (err: any) {
    console.error('Contact submission error:', err);
    return res.status(500).json({ error: err.message || 'Server error saving enquiry.' });
  }
});

app.get('/api/contact/submissions', (req, res) => {
  const subs = getLocalContactSubmissions();
  res.json({ submissions: subs });
});

app.patch('/api/contact/submissions/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const list = getLocalContactSubmissions();
  const item = list.find((s: any) => s.id === id);
  if (item) {
    item.status = status;
    saveLocalContactSubmission(item);
    return res.json({ success: true });
  }
  res.status(404).json({ error: 'Submission not found' });
});

app.delete('/api/contact/submissions/:id', (req, res) => {
  const { id } = req.params;
  const list = getLocalContactSubmissions().filter((s: any) => s.id !== id);
  try {
    fs.writeFileSync(CONTACT_SUBMISSIONS_FILE, JSON.stringify(list, null, 2), 'utf-8');
    return res.json({ success: true });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
});

// Google Sheets Configuration Status (Never exposes sensitive tokens)
app.get('/api/google-sheets/config', (req, res) => {
  const config = getSheetsConfig();
  if (!config || !config.spreadsheetId) {
    return res.json({
      isConnected: false,
      spreadsheetId: '',
      spreadsheetUrl: '',
      userEmail: '',
      totalSynced: 0
    });
  }

  res.json({
    isConnected: true,
    spreadsheetId: config.spreadsheetId,
    spreadsheetUrl: config.spreadsheetUrl,
    spreadsheetTitle: config.spreadsheetTitle || 'Janah Studio - Careers Applications',
    userEmail: config.userEmail || '',
    connectedAt: config.connectedAt || '',
    totalSynced: config.totalSynced || 0
  });
});

// Admin Connect Google Sheets
app.post('/api/admin/google-sheets/connect', async (req, res) => {
  const { accessToken, spreadsheetId, userEmail, createNew } = req.body;
  if (!accessToken) {
    return res.status(400).json({ error: 'OAuth Access Token is required to connect Google Sheets.' });
  }

  try {
    let sheetId = spreadsheetId ? spreadsheetId.trim() : '';
    let sheetUrl = '';
    let sheetTitle = 'Janah Studio - Careers Applications';

    // Parse spreadsheet ID from URL if full URL provided
    if (sheetId.includes('/spreadsheets/d/')) {
      const match = sheetId.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
      if (match && match[1]) {
        sheetId = match[1];
      }
    }

    if (createNew || !sheetId) {
      // Create a brand new dedicated spreadsheet in the owner's Google account
      const created = await createSpreadsheetWithHeaders(accessToken);
      sheetId = created.id;
      sheetUrl = created.url;
      sheetTitle = created.title;
    } else {
      // Verify access and ensure header row
      sheetTitle = await ensureHeadersExist(sheetId, accessToken);
      sheetUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/edit`;
    }

    const currentConfig = getSheetsConfig();
    const newConfig: ServerSheetsConfig = {
      accessToken,
      spreadsheetId: sheetId,
      spreadsheetUrl: sheetUrl,
      spreadsheetTitle: sheetTitle,
      userEmail: userEmail || 'Connected Google Account',
      connectedAt: new Date().toISOString(),
      totalSynced: currentConfig?.totalSynced || 0
    };

    saveSheetsConfig(newConfig);

    res.json({
      success: true,
      message: 'Google Sheets connected successfully!',
      spreadsheetId: sheetId,
      spreadsheetUrl: sheetUrl,
      spreadsheetTitle: sheetTitle
    });
  } catch (error: any) {
    console.error('Failed to connect Google Sheets:', error);
    res.status(500).json({ error: error.message || 'Failed to connect Google Sheets.' });
  }
});

// Admin Disconnect Google Sheets
app.post('/api/admin/google-sheets/disconnect', (req, res) => {
  saveSheetsConfig(null);
  res.json({ success: true, message: 'Google Sheets disconnected.' });
});

// Admin Sync Pending Applications
app.post('/api/admin/google-sheets/sync-all', async (req, res) => {
  const config = getSheetsConfig();
  if (!config || !config.accessToken || !config.spreadsheetId) {
    return res.status(400).json({ error: 'Google Sheets is not connected yet.' });
  }

  const applications = getLocalApplications();
  const unsynced = applications.filter(a => !a.savedToGoogleSheets);
  let syncedCount = 0;
  const errors: string[] = [];

  for (const app of unsynced) {
    try {
      await appendApplicationToSheet(config.spreadsheetId, config.accessToken, app);
      app.savedToGoogleSheets = true;
      saveLocalApplication(app);
      syncedCount++;
    } catch (err: any) {
      errors.push(`${app.referenceId}: ${err.message}`);
    }
  }

  config.totalSynced = (config.totalSynced || 0) + syncedCount;
  saveSheetsConfig(config);

  res.json({
    success: true,
    syncedCount,
    remainingUnsynced: unsynced.length - syncedCount,
    errors: errors.length > 0 ? errors : undefined
  });
});

// Careers Public Application Submission Endpoint
app.post('/api/careers/apply', async (req, res) => {
  try {
    const body = req.body || {};
    const fullName = typeof body.fullName === 'string' ? body.fullName.trim() : '';
    const email = typeof body.email === 'string' ? body.email.trim() : '';
    const phone = typeof body.phone === 'string' ? body.phone.trim() : '';
    const location = typeof body.location === 'string' ? body.location.trim() : '';
    const position = typeof body.position === 'string' ? body.position.trim() : '';
    const experienceLevel = typeof body.experienceLevel === 'string' ? body.experienceLevel.trim() : '';
    const yearsExperience = body.yearsExperience !== undefined ? String(body.yearsExperience).trim() : '0';
    const workTypes = Array.isArray(body.workTypes) ? body.workTypes : [];
    const skills = Array.isArray(body.skills) ? body.skills : [];
    const leadSources = Array.isArray(body.leadSources) ? body.leadSources : [];
    const customSkills = typeof body.customSkills === 'string' ? body.customSkills.trim() : '';
    const portfolioUrl = typeof body.portfolioUrl === 'string' ? body.portfolioUrl.trim() : '';
    const socialUrl = typeof body.socialUrl === 'string' ? body.socialUrl.trim() : '';
    const previousExperience = typeof body.previousExperience === 'string' ? body.previousExperience.trim() : '';
    const coverLetter = typeof body.coverLetter === 'string' ? body.coverLetter.trim() : '';
    const additionalMessage = typeof body.additionalMessage === 'string' ? body.additionalMessage.trim() : '';
    const expectedRate = typeof body.expectedRate === 'string' ? body.expectedRate.trim() : '';
    const bankName = typeof body.bankName === 'string' ? body.bankName.trim() : '';

    // Validation for required fields
    if (!fullName || fullName.length < 2) {
      return res.status(400).json({ error: 'Full name is required (minimum 2 characters).' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      return res.status(400).json({ error: 'A valid email address is required.' });
    }

    if (!phone || phone.length < 7) {
      return res.status(400).json({ error: 'A valid phone or WhatsApp number is required (min 7 digits).' });
    }

    if (!location || location.length < 2) {
      return res.status(400).json({ error: 'Country / Location is required.' });
    }

    if (!position) {
      return res.status(400).json({ error: 'Please choose an opportunity or service category.' });
    }

    if (!experienceLevel) {
      return res.status(400).json({ error: 'Please select your experience level.' });
    }

    if (!Array.isArray(workTypes) || workTypes.length === 0) {
      return res.status(400).json({ error: 'Please select at least one work availability type.' });
    }

    if (!Array.isArray(skills) || skills.length === 0) {
      return res.status(400).json({ error: 'Please select at least one relevant skill.' });
    }

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const referenceId = `JS-REF-2026-${randomSuffix}`;
    const applicationId = `cand-${Date.now()}-${randomSuffix}`;
    const now = new Date().toISOString();

    const application: CandidateSubmission = {
      id: applicationId,
      referenceId,
      fullName,
      email: email.toLowerCase(),
      phone,
      location,
      position,
      experienceLevel,
      yearsExperience: yearsExperience || '0',
      workTypes,
      skills,
      leadSources,
      customSkills,
      portfolioUrl,
      socialUrl,
      previousExperience,
      coverLetter,
      additionalMessage,
      expectedRate: expectedRate || 'Negotiable',
      bankName: bankName || 'Not specified',
      createdAt: now,
      savedToGoogleSheets: false
    };

    const sheetsConfig = getSheetsConfig();
    if (sheetsConfig && sheetsConfig.accessToken && sheetsConfig.spreadsheetId) {
      try {
        const appendResult = await appendApplicationToSheet(
          sheetsConfig.spreadsheetId,
          sheetsConfig.accessToken,
          application
        );
        application.savedToGoogleSheets = true;
        saveLocalApplication(application);

        sheetsConfig.totalSynced = (sheetsConfig.totalSynced || 0) + 1;
        saveSheetsConfig(sheetsConfig);

        return res.json({
          success: true,
          referenceId,
          applicationId,
          savedToGoogleSheets: true,
          spreadsheetId: sheetsConfig.spreadsheetId,
          updatedRange: appendResult.updatedRange,
          message: 'Application submitted successfully and saved directly into Google Sheets!'
        });
      } catch (sheetError: any) {
        console.warn('Google Sheets append failed, saving locally and returning queued status:', sheetError.message);
        // Save locally so applicant is never lost
        saveLocalApplication(application);
        return res.json({
          success: true,
          referenceId,
          applicationId,
          savedToGoogleSheets: false,
          requiresSetup: true,
          sheetError: sheetError.message,
          message: 'Application received and safely recorded! Google Sheets sync is pending administrative review.'
        });
      }
    } else {
      // Save locally
      saveLocalApplication(application);
      return res.json({
        success: true,
        referenceId,
        applicationId,
        savedToGoogleSheets: false,
        requiresSetup: true,
        message: 'Application recorded successfully! (Google Sheets connection pending setup by administrator).'
      });
    }
  } catch (err: any) {
    console.error('Career application submission error:', err);
    return res.status(500).json({
      error: err.message || 'Server error processing application. Please try again.'
    });
  }
});

// View all applications for admin
app.get('/api/careers/applications', (req, res) => {
  const apps = getLocalApplications();
  res.json({ applications: apps });
});

// Update application status
app.patch('/api/careers/applications/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const success = updateLocalApplicationStatus(id, status);
  if (success) {
    return res.json({ success: true, id, status });
  }
  return res.status(404).json({ error: 'Application not found' });
});

// Delete application
app.delete('/api/careers/applications/:id', (req, res) => {
  const { id } = req.params;
  const success = deleteLocalApplication(id);
  if (success) {
    return res.json({ success: true });
  }
  return res.status(404).json({ error: 'Application not found' });
});

// SEO Static Files Handlers
app.get('/robots.txt', (req, res) => {
  const robotsPath = path.resolve(__dirname, 'public', 'robots.txt');
  if (fs.existsSync(robotsPath)) {
    res.type('text/plain').sendFile(robotsPath);
  } else {
    res.type('text/plain').send("User-agent: *\nAllow: /\nDisallow: /dashboard\nDisallow: /api/\n\nSitemap: https://janahstudio.com/sitemap.xml\n");
  }
});

app.get('/sitemap.xml', (req, res) => {
  const sitemapPath = path.resolve(__dirname, 'public', 'sitemap.xml');
  if (fs.existsSync(sitemapPath)) {
    res.type('application/xml').sendFile(sitemapPath);
  } else {
    res.status(404).send('Sitemap not found');
  }
});

// Serve Frontend
const isProd = process.env.NODE_ENV === 'production';
if (!isProd) {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist/index.html'));
  });
}

const port = process.env.PORT || 3000;
app.listen(Number(port), '0.0.0.0', () => {
  console.log(`Server running at http://localhost:${port}`);
});
