import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CheckCircle2, ArrowRight, ShieldCheck, MessageCircle } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { BusinessPricingTable } from '../components/BusinessPricingTable';
import { EcommercePricingTable } from '../components/EcommercePricingTable';
import { PortfolioPricingTable } from '../components/PortfolioPricingTable';
import { RedesignPricingTable } from '../components/RedesignPricingTable';
import { LandingPagePricingTable } from '../components/LandingPagePricingTable';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';

export default function Pricing() {
  const navigate = useNavigate();
  const whatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent("Hi Janah Studio, I'd like to discuss website pricing.")}`;

  return (
    <div className="space-y-20 pb-20">
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] pt-2 pb-10 sm:pb-14 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30">
        <div className="relative z-10 max-w-3xl space-y-2">
          <AnimatedHeading
            text="Our Pricing Packages"
            as="h1"
            className="text-4xl sm:text-5xl font-extrabold text-[#17202A] tracking-tight leading-tight"
          />
          <div className="w-36 h-3 mt-1 mb-2">
            <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
              <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <defs>
                <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#30E1CE" />
                  <stop offset="50%" stopColor="#1876C7" />
                  <stop offset="100%" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <AnimatedDescription
            text="Transparent, fixed pricing packages for custom business websites, full-stack e-commerce stores, creative portfolios, high-converting landing pages, and modern website redesigns — with clear deliverables, zero hidden fees, and dedicated post-launch support."
            className="text-sm sm:text-base text-[#66727D] leading-relaxed"
            delay={0.2}
          />
        </div>
      </section>

      {/* Website Packages */}
      <AnimatedSection direction="left">
        <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <BusinessPricingTable showHeader={true} />
        </section>
      </AnimatedSection>

      {/* E-commerce Packages */}
      <AnimatedSection direction="right">
        <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <EcommercePricingTable showHeader={true} />
        </section>
      </AnimatedSection>

      {/* Portfolio Website Packages */}
      <AnimatedSection direction="left">
        <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <PortfolioPricingTable />
        </section>
      </AnimatedSection>

      {/* Website Redesign / Rebuilding Packages */}
      <AnimatedSection direction="right">
        <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <RedesignPricingTable showHeader={true} />
        </section>
      </AnimatedSection>

      {/* Landing Page Development Packages */}
      <AnimatedSection direction="left">
        <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <LandingPagePricingTable showHeader={true} />
        </section>
      </AnimatedSection>

      {/* Website Maintenance & Support Promotional Card */}
      <AnimatedSection direction="right">
        <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 backdrop-blur-md rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-6 sm:p-8 md:p-10 border border-[#30E1CE]/30 shadow-xl hover:shadow-2xl transition-all duration-300 relative overflow-hidden">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
            <div className="space-y-4 max-w-2xl text-left">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-[#30E1CE]/15 via-[#1876C7]/15 to-[#EC4899]/15 border border-[#1876C7]/20 text-[11px] font-bold text-[#1876C7] uppercase tracking-wider">
                <ShieldCheck className="w-3.5 h-3.5 text-[#1876C7]" />
                <span>Care Plans • Ongoing Support</span>
              </div>

              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#17202A] tracking-tight">
                Website Maintenance & Support
              </h2>

              <p className="text-sm sm:text-base text-[#66727D] leading-relaxed">
                Keep your website secure, updated, and running smoothly with ongoing maintenance and technical support plans tailored to your needs.
              </p>

              <div className="pt-2">
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <li className="flex items-start gap-2.5 text-xs sm:text-sm text-[#17202A] font-medium">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0 mt-0.5" />
                    <span>Regular website updates and maintenance</span>
                  </li>
                  <li className="flex items-start gap-2.5 text-xs sm:text-sm text-[#17202A] font-medium">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0 mt-0.5" />
                    <span>Security checks and technical assistance</span>
                  </li>
                  <li className="flex items-start gap-2.5 text-xs sm:text-sm text-[#17202A] font-medium">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0 mt-0.5" />
                    <span>Monthly content changes based on your selected plan</span>
                  </li>
                  <li className="flex items-start gap-2.5 text-xs sm:text-sm text-[#17202A] font-medium">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0 mt-0.5" />
                    <span>E-commerce maintenance where applicable</span>
                  </li>
                  <li className="flex items-start gap-2.5 text-xs sm:text-sm text-[#17202A] font-medium sm:col-span-2">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0 mt-0.5" />
                    <span>Support options for different business needs</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="shrink-0 flex flex-col items-start lg:items-center justify-center gap-2 pt-2 lg:pt-0">
              <Button
                variant="primary"
                onClick={() => navigate('/maintenance-support')}
                className="flex items-center justify-center gap-2"
              >
                <span>View Maintenance Pricing</span>
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>
      </AnimatedSection>

      {/* Important Project Information */}
      <AnimatedSection>
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-[#E2E8EA] space-y-3">
            <h3 className="text-base font-bold text-[#17202A]">Payment Structure</h3>
            <p className="text-xs text-[#66727D] leading-relaxed">
              50% deposit reserves the project and begins planning/development. The remaining 50% is due after agreed completion/review and before launch.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#E2E8EA] space-y-3">
            <h3 className="text-base font-bold text-[#17202A]">Revisions</h3>
            <p className="text-xs text-[#66727D] leading-relaxed">
              Two revision rounds are included. Each revision round is one consolidated list of normal changes. Extra or new scope is charged separately.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#E2E8EA] space-y-3">
            <h3 className="text-base font-bold text-[#17202A]">Hosting</h3>
            <p className="text-xs text-[#66727D] leading-relaxed">
              Hosting is separate. Client-owned domains, hosting and third-party accounts should be in the client's name/information.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#E2E8EA] space-y-3">
            <h3 className="text-base font-bold text-[#17202A]">Client Approval</h3>
            <p className="text-xs text-[#66727D] leading-relaxed">
              Written client approval is required before launch to ensure all requirements and details are fully verified.
            </p>
          </div>
        </div>
      </section>
      </AnimatedSection>

      {/* Final CTA Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none pt-4 pb-10 sm:pb-14 px-8 sm:px-16 text-center space-y-3 shadow-2xl relative overflow-hidden border border-[#30E1CE]/30">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#30E1CE]/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <AnimatedHeading
            text="Not Sure Which Package Fits Best?"
            as="h2"
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#17202A]"
          />
          <AnimatedDescription
            text="Let us help you choose the right package or discuss a custom quote tailored to your exact scope and budget."
            className="text-sm sm:text-base text-[#66727D] max-w-xl mx-auto leading-relaxed"
            delay={0.15}
          />

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <Button
              variant="chat"
              onClick={() => window.open(whatsappUrl, '_blank')}
              className="px-6 shrink-0"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>

            <Button
              variant="outline"
              onClick={() => navigate('/contact')}
              className="px-6 shrink-0 border-[#1876C7] text-[#1876C7]"
            >
              <span>Get Quote</span>
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </Button>
          </div>
        </div>
      </section>
      </AnimatedSection>

    </div>
  );
}
