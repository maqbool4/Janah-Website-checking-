import React, { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ChevronDown, ChevronUp, MessageCircle, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { BusinessWebsiteContent } from '../components/services/BusinessWebsiteContent';
import { EcommerceWebsiteContent } from '../components/services/EcommerceWebsiteContent';
import { PortfolioWebsiteContent } from '../components/services/PortfolioWebsiteContent';
import { LandingPageContent } from '../components/services/LandingPageContent';
import { WebsiteRedesignContent } from '../components/services/WebsiteRedesignContent';
import { MaintenanceSupportContent } from '../components/services/MaintenanceSupportContent';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';

export default function Services() {
  const navigate = useNavigate();
  const whatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent("Hi Janah Studio, I'd like to discuss website services.")}`;
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const cardRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

  const toggleExpand = (id: string) => {
    const isOpening = expandedId !== id;
    setExpandedId(isOpening ? id : null);

    if (isOpening) {
      setTimeout(() => {
        const el = cardRefs.current[id];
        if (el) {
          const headerOffset = 85; // accounts for sticky navbar + breathing room
          const elementTop = el.getBoundingClientRect().top + window.pageYOffset;
          window.scrollTo({
            top: Math.max(0, elementTop - headerOffset),
            behavior: 'smooth'
          });
        }
      }, 100);
    }
  };

  const services = [
    { 
      id: 'business', 
      title: 'Business Website', 
      desc: 'Professional, customized websites for small businesses to establish credibility and attract customers.', 
      Component: BusinessWebsiteContent 
    },
    { 
      id: 'ecommerce', 
      title: 'E-commerce Website', 
      desc: 'Professional, customized e-commerce websites to showcase products and manage online shopping.', 
      Component: EcommerceWebsiteContent 
    },
    { 
      id: 'portfolio', 
      title: 'Portfolio Website', 
      desc: 'Professional, personalized portfolio websites to showcase skills, projects, and achievements.', 
      Component: PortfolioWebsiteContent 
    },
    { 
      id: 'landing', 
      title: 'Landing Page', 
      desc: 'Professional, conversion-focused landing pages designed to promote specific campaigns and offers.', 
      Component: LandingPageContent 
    },
    { 
      id: 'redesign', 
      title: 'Website Redesign', 
      desc: 'Professional website redesign and rebuilding to modernize appearance, usability, and performance.', 
      Component: WebsiteRedesignContent 
    },
    { 
      id: 'maintenance', 
      title: 'Website Maintenance & Support', 
      desc: 'Ongoing website maintenance and technical support to keep websites updated, functional, and reliable.', 
      Component: MaintenanceSupportContent 
    },
  ];

  return (
    <div className="space-y-16 pb-20 pt-8">
      
      {/* Title Section */}
      <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] pt-2 pb-10 sm:pb-14 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30">
        <div className="relative z-10 max-w-3xl space-y-2">
          <AnimatedHeading
            text="Our Services"
            as="h1"
            className="text-4xl sm:text-5xl font-extrabold text-[#17202A] tracking-tight leading-tight"
          />
          <div className="w-36 h-3 mt-1 mb-2">
            <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
              <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <defs>
                <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#30E1CE" />
                  <stop offset="50%" stopColor="#1876C7" />
                  <stop offset="100%" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <AnimatedDescription
            text="Explore our comprehensive web development services tailored to help your brand grow. From custom business websites and full-featured e-commerce stores to high-converting landing pages, modern redesigns, and dedicated maintenance — every project is engineered with modern responsive design, clean code, and search engine optimization."
            className="text-sm sm:text-base text-[#66727D] leading-relaxed"
            delay={0.2}
          />
        </div>
      </section>

      {/* Services List Section (Original clean design) */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {services.map((service, index) => {
          const isExpanded = expandedId === service.id;
          const numStr = String(index + 1).padStart(2, '0');

          return (
            <AnimatedSection key={service.id} direction={index % 2 === 0 ? "left" : "right"} delay={index * 0.06}>
              <div 
                ref={(el) => { cardRefs.current[service.id] = el; }}
                id={`service-${service.id}`}
                className="bg-white rounded-3xl border border-[#E2E8EA] shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden scroll-mt-24"
              >
                <div className="p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div className="space-y-3 flex-grow text-left">
                    <span className="text-xs font-mono font-bold text-[#1876C7] px-3 py-1 rounded-full bg-[#1876C7]/10 inline-block">
                      {numStr} — SERVICE
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-extrabold text-[#17202A] tracking-tight">
                      {service.title}
                    </h2>
                    <p className="text-sm text-[#66727D] leading-relaxed max-w-2xl">
                      {service.desc}
                    </p>
                  </div>
                  <div className="shrink-0 self-start md:self-center">
                    <Button
                      variant={isExpanded ? 'outline' : 'navy-blue'}
                      onClick={() => toggleExpand(service.id)}
                      className="flex items-center gap-2 h-[40px] text-[14px]"
                    >
                      <span>{isExpanded ? 'Show Less' : 'Learn More'}</span>
                      {isExpanded ? <ChevronUp className="w-4 h-4 ml-1" /> : <ChevronDown className="w-4 h-4 ml-1" />}
                    </Button>
                  </div>
                </div>
                
                {isExpanded && (
                  <div className="px-6 pb-8 sm:px-8 pt-6 border-t border-[#E2E8EA] bg-[#F8FAFA] animate-in fade-in duration-300">
                    <service.Component />
                  </div>
                )}
              </div>
            </AnimatedSection>
          );
        })}
      </section>

      {/* Final CTA Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none pt-4 pb-10 sm:pb-14 px-8 sm:px-16 text-center space-y-3 shadow-2xl relative overflow-hidden border border-[#30E1CE]/30">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#30E1CE]/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <AnimatedHeading
            text="Need a Custom Service or Specific Feature?"
            as="h2"
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#17202A]"
          />
          <AnimatedDescription
            text="Tell us about your unique requirements and project goals. We'll discuss a tailored solution for your business."
            className="text-sm sm:text-base text-[#66727D] max-w-xl mx-auto leading-relaxed"
            delay={0.15}
          />

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <Button
              variant="chat"
              onClick={() => window.open(whatsappUrl, '_blank')}
              className="px-6 shrink-0"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>

            <Button
              variant="outline"
              onClick={() => navigate('/contact')}
              className="px-6 shrink-0 border-[#1876C7] text-[#1876C7]"
            >
              <span>Contact Us</span>
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </Button>
          </div>
        </div>
      </section>
      </AnimatedSection>

    </div>
  );
}
