import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CheckCircle2, ShieldCheck, ArrowRight, MessageCircle, HelpCircle, FileText } from 'lucide-react';
import { dataStore } from '../lib/dataStore';
import { PricingPackage, FaqItem } from '../lib/types';
import { Button } from '../components/ui/Button';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';

export default function Maintenance() {
  const navigate = useNavigate();
  const [pricing, setPricing] = useState<PricingPackage[]>(() => 
    dataStore.getPricingSync().filter(p => p.is_active && p.category === 'maintenance')
  );
  const [faqs, setFaqs] = useState<FaqItem[]>(() => 
    dataStore.getFaqsSync().filter(f => f.is_active && (f.category === 'Revisions & Support' || f.category === 'Maintenance & Support' || f.category === 'Hosting & Domain'))
  );

  useEffect(() => {
    dataStore.getPricing().then(res => setPricing(res.filter(p => p.is_active && p.category === 'maintenance')));
    dataStore.getFaqs().then(res => setFaqs(res.filter(f => f.is_active && (f.category === 'Revisions & Support' || f.category === 'Maintenance & Support' || f.category === 'Hosting & Domain'))));
  }, []);

  const whatsappBaseUrl = "https://wa.me/923295430114";
  const generalWhatsappUrl = `${whatsappBaseUrl}?text=${encodeURIComponent("Hi Janah Studio, I'd like to discuss a website maintenance plan.")}`;

  const handleOrder = (planName: string, price: string) => {
    const message = encodeURIComponent(`Hi Janah Studio, I am interested in the ${planName} Maintenance Plan (${price}). Let's discuss!`);
    window.open(`${whatsappBaseUrl}?text=${message}`, '_blank');
  };

  return (
    <div className="space-y-16 sm:space-y-20 pb-20 pt-8">
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] pt-4 pb-10 sm:pb-14 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30">
        <div className="relative z-10 max-w-3xl space-y-3 text-left">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-[#30E1CE]/15 via-[#1876C7]/15 to-[#EC4899]/15 border border-[#1876C7]/20 text-[11px] font-bold text-[#1876C7] uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5 text-[#1876C7]" />
            <span>Care Plans • Ongoing Website Support</span>
          </div>

          <AnimatedHeading
            text="Keep Your Website Updated, Secure, and Working Properly"
            as="h1"
            className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#17202A] tracking-tight leading-tight"
          />

          <div className="w-36 h-3 mt-1 mb-2">
            <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
              <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
              <defs>
                <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#30E1CE" />
                  <stop offset="50%" stopColor="#1876C7" />
                  <stop offset="100%" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          <AnimatedDescription
            text="Ongoing website maintenance helps keep your website updated, monitored, backed up, and supported after launch so you can focus on growing your business."
            className="text-sm sm:text-base text-[#66727D] leading-relaxed"
            delay={0.2}
          />

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Button
              variant="navy-blue"
              onClick={() => navigate('/contact')}
              className="flex items-center gap-2"
            >
              <span>Let’s Build</span>
              <ArrowRight className="w-4 h-4" />
            </Button>

            <Button
              variant="chat"
              onClick={() => window.open(generalWhatsappUrl, '_blank')}
              className="px-6 flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>
          </div>
        </div>
      </section>

      {/* Pricing Plans Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <span className="text-xs font-mono font-bold text-[#1876C7] px-3 py-1 rounded-full bg-[#1876C7]/10 inline-block">
            MONTHLY PACKAGES
          </span>
          <AnimatedHeading
            text="Choose Your Maintenance Plan"
            as="h2"
            className="text-3xl sm:text-4xl font-extrabold text-[#17202A] tracking-tight"
          />
          <AnimatedDescription
            text="Flexible monthly plans designed for personal websites, growing business sites, and busy online stores."
            className="text-sm sm:text-base text-[#66727D]"
            delay={0.15}
          />
        </div>

        {pricing.length === 0 ? (
          <div className="py-16 flex flex-col items-center justify-center space-y-3">
            <div className="w-8 h-8 rounded-full border-2 border-[#1876C7] border-t-transparent animate-spin" />
            <p className="text-sm text-[#66727D]">Loading maintenance plans...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricing.map((pkg, idx) => {
            const isPopular = idx === 1;
            return (
              <AnimatedSection key={pkg.id} direction={idx === 0 ? "left" : idx === 1 ? "up" : "right"} delay={idx * 0.08}>
                <div 
                  className={`bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 backdrop-blur-md rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-6 sm:p-8 border ${
                    isPopular 
                      ? 'border-[#1876C7] ring-2 ring-[#1876C7]/30 shadow-2xl scale-[1.02]' 
                      : 'border-[#30E1CE]/30 shadow-xl hover:shadow-2xl'
                  } flex flex-col justify-between space-y-6 relative transition-all duration-300 text-left h-full`}
                >
                  {isPopular && (
                    <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-[#30E1CE] to-[#1876C7] text-white text-xs font-bold shadow-md uppercase tracking-wider">
                      Most Popular
                    </span>
                  )}

                  <div className="space-y-5">
                    <div className="space-y-1">
                      <h3 className="text-xl sm:text-2xl font-bold text-[#17202A]">{pkg.package_name}</h3>
                      <p className="text-xs text-[#66727D] leading-relaxed min-h-[32px]">{pkg.description}</p>
                    </div>

                    <div className="pt-2 pb-1">
                      <span className="text-3xl sm:text-4xl font-extrabold text-[#17202A] block tracking-tight">
                        {pkg.starting_price}
                      </span>
                      <span className="text-[11px] text-[#66727D] block font-medium mt-0.5">Billed monthly • Cancel anytime</span>
                    </div>

                    <ul className="space-y-3 pt-4 border-t border-[#30E1CE]/25">
                      {pkg.features.map((feat, i) => (
                        <li key={i} className="flex items-start gap-2.5 text-xs text-[#17202A] font-medium leading-relaxed">
                          <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-4 border-t border-[#30E1CE]/20 space-y-2">
                    <Button
                      variant={isPopular ? 'primary' : 'navy-blue'}
                      onClick={() => handleOrder(pkg.package_name, pkg.starting_price)}
                      className="w-full flex items-center justify-center gap-2"
                    >
                      <span>Choose Plan</span>
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                    <p className="text-[10px] text-center text-[#66727D]">Direct enquiry via WhatsApp</p>
                  </div>
                </div>
              </AnimatedSection>
            );
          })}
        </div>
        )}
      </section>
      </AnimatedSection>

      {/* Terms & Conditions Details */}
      <AnimatedSection>
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center space-y-2 mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1876C7]/10 text-xs font-bold text-[#1876C7] uppercase tracking-wider">
            <FileText className="w-3.5 h-3.5 text-[#1876C7]" />
            <span>Scope & Policies</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#17202A] tracking-tight">
            Maintenance Scope & Guidelines
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="bg-gradient-to-br from-[#30E1CE]/10 via-blue-50/50 to-white backdrop-blur-sm rounded-tl-2xl rounded-br-2xl rounded-tr-none rounded-bl-none p-5 sm:p-6 border border-[#30E1CE]/30 shadow-sm hover:shadow-md transition-all space-y-2 text-left">
            <h3 className="text-sm sm:text-base font-bold text-[#17202A] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#1876C7]"></span>
              Emergency Support
            </h3>
            <p className="text-xs text-[#66727D] leading-relaxed">
              Urgent fixes outside normal hours or critical recovery issues are handled promptly and quoted separately based on urgency and required technical scope.
            </p>
          </div>

          <div className="bg-gradient-to-br from-[#30E1CE]/10 via-blue-50/50 to-white backdrop-blur-sm rounded-tl-2xl rounded-br-2xl rounded-tr-none rounded-bl-none p-5 sm:p-6 border border-[#30E1CE]/30 shadow-sm hover:shadow-md transition-all space-y-2 text-left">
            <h3 className="text-sm sm:text-base font-bold text-[#17202A] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#1876C7]"></span>
              Small Change Definition
            </h3>
            <p className="text-xs text-[#66727D] leading-relaxed">
              Minor content, text, price, image, or design touch-ups. Major rebuilds, new feature developments, or full redesigns are scoped and quoted separately.
            </p>
          </div>

          <div className="bg-gradient-to-br from-[#30E1CE]/10 via-blue-50/50 to-white backdrop-blur-sm rounded-tl-2xl rounded-br-2xl rounded-tr-none rounded-bl-none p-5 sm:p-6 border border-[#30E1CE]/30 shadow-sm hover:shadow-md transition-all space-y-2 text-left">
            <h3 className="text-sm sm:text-base font-bold text-[#17202A] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#1876C7]"></span>
              Hosting Policy
            </h3>
            <p className="text-xs text-[#66727D] leading-relaxed">
              Third-party server and domain hosting fees are billed to the client's own accounts unless specifically included in your written project contract.
            </p>
          </div>

          <div className="bg-gradient-to-br from-[#30E1CE]/10 via-blue-50/50 to-white backdrop-blur-sm rounded-tl-2xl rounded-br-2xl rounded-tr-none rounded-bl-none p-5 sm:p-6 border border-[#30E1CE]/30 shadow-sm hover:shadow-md transition-all space-y-2 text-left">
            <h3 className="text-sm sm:text-base font-bold text-[#17202A] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#1876C7]"></span>
              Terms & Cancellations
            </h3>
            <p className="text-xs text-[#66727D] leading-relaxed">
              Monthly maintenance is billed in advance and is non-refundable once the monthly cycle starts. You can cancel before the next renewal with no lock-in.
            </p>
          </div>
        </div>
      </section>
      </AnimatedSection>

      {/* Maintenance FAQ */}
      {faqs.length > 0 && (
        <AnimatedSection>
          <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-2 mb-8">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1876C7]/10 text-xs font-bold text-[#1876C7] uppercase tracking-wider">
              <HelpCircle className="w-3.5 h-3.5 text-[#1876C7]" />
              <span>Questions & Answers</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#17202A] tracking-tight">
              Maintenance & Support FAQ
            </h2>
          </div>
          <div className="space-y-4 text-left">
            {faqs.map(faq => (
              <div 
                key={faq.id} 
                className="bg-gradient-to-br from-[#30E1CE]/10 via-blue-50/40 to-white backdrop-blur-sm rounded-tl-2xl rounded-br-2xl rounded-tr-none rounded-bl-none p-5 sm:p-6 border border-[#30E1CE]/30 shadow-sm hover:shadow-md transition-all space-y-2"
              >
                <h3 className="text-sm sm:text-base font-bold text-[#17202A] flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#30E1CE]"></span>
                  {faq.question}
                </h3>
                <p className="text-xs sm:text-sm text-[#66727D] leading-relaxed pl-4">{faq.answer}</p>
              </div>
            ))}
          </div>
        </section>
        </AnimatedSection>
      )}

      {/* Final CTA Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none pt-4 pb-10 sm:pb-14 px-8 sm:px-16 text-center space-y-3 shadow-2xl relative overflow-hidden border border-[#30E1CE]/30">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#30E1CE]/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <AnimatedHeading
            text="Need Ongoing Website Support?"
            as="h2"
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#17202A]"
          />
          <AnimatedDescription
            text="Keep your website secure, updated, and running smoothly with monthly maintenance plans tailored to your needs."
            className="text-sm sm:text-base text-[#66727D] max-w-xl mx-auto leading-relaxed"
            delay={0.15}
          />

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <Button
              variant="chat"
              onClick={() => window.open(generalWhatsappUrl, '_blank')}
              className="px-6 shrink-0"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>

            <Button
              variant="outline"
              onClick={() => navigate('/contact')}
              className="px-6 shrink-0 border-[#1876C7] text-[#1876C7]"
            >
              <span>Get Support</span>
              <ArrowRight className="w-4 h-4 ml-1.5" />
            </Button>
          </div>
        </div>
      </section>
      </AnimatedSection>

    </div>
  );
}
