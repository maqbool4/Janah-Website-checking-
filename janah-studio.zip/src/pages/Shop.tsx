import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  ShoppingBag, 
  ShoppingCart, 
  Search, 
  Check, 
  X, 
  ArrowRight, 
  Plus, 
  Minus, 
  ShieldCheck, 
  Tag, 
  Truck, 
  CreditCard,
  Building,
  CheckCircle2,
  ExternalLink,
  Settings
} from 'lucide-react';
import { dataStore } from '../lib/dataStore';
import { StoreProduct, StoreCoupon } from '../lib/types';
import { Button } from '../components/ui/Button';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';

interface CartItem {
  product: StoreProduct;
  quantity: number;
}

export default function Shop() {
  const [products, setProducts] = useState<StoreProduct[]>(() => dataStore.getProductsSync());
  const [coupons, setCoupons] = useState<StoreCoupon[]>(() => dataStore.getCouponsSync());
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('janah_store_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<StoreProduct | null>(null);

  // Checkout State
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [city, setCity] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash on Delivery (COD)' | 'Bank Transfer' | 'Online Payment Gateway'>('Cash on Delivery (COD)');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<StoreCoupon | null>(null);
  const [couponError, setCouponError] = useState('');
  const [orderSuccess, setOrderSuccess] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    loadStoreData();

    const handleUpdate = () => {
      loadStoreData();
    };

    window.addEventListener('janah_store_updated', handleUpdate);
    window.addEventListener('storage', handleUpdate);

    return () => {
      window.removeEventListener('janah_store_updated', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  const loadStoreData = async () => {
    const prods = await dataStore.getProducts();
    const coups = await dataStore.getCoupons();
    setProducts(prods.filter(p => p.is_active));
    setCoupons(coups.filter(c => c.is_active));
  };

  useEffect(() => {
    try {
      localStorage.setItem('janah_store_cart', JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  const categories = ['All', ...Array.from(new Set(products.map(p => p.category)))];

  const filteredProducts = products.filter(product => {
    const matchesCat = selectedCategory === 'All' || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const addToCart = (product: StoreProduct) => {
    if (!product.in_stock || product.stock_quantity <= 0) return;
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock_quantity) return prev;
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const newQty = item.quantity + delta;
          if (newQty <= 0) return null;
          if (newQty > item.product.stock_quantity) return item;
          return { ...item, quantity: newQty };
        }
        return item;
      }).filter(Boolean) as CartItem[];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const discountAmount = appliedCoupon ? Math.round((subtotal * appliedCoupon.discount_percentage) / 100) : 0;
  const finalTotal = Math.max(0, subtotal - discountAmount);

  const applyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    const found = coupons.find(c => c.code.toUpperCase() === couponCode.trim().toUpperCase());
    if (!found) {
      setCouponError('Invalid or expired coupon code.');
      return;
    }
    if (found.min_order_amount && subtotal < found.min_order_amount) {
      setCouponError(`Minimum order amount of PKR ${found.min_order_amount.toLocaleString()} required for this coupon.`);
      return;
    }
    setAppliedCoupon(found);
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    setIsSubmitting(true);

    try {
      const order = await dataStore.createOrder({
        customer_name: customerName,
        customer_email: customerEmail,
        customer_phone: customerPhone,
        shipping_address: shippingAddress,
        city: city || 'Pakistan',
        items: cart.map(item => ({
          product_id: item.product.id,
          product_name: item.product.name,
          price: item.product.price,
          quantity: item.quantity,
          image_url: item.product.image_url
        })),
        total_amount: finalTotal,
        payment_method: paymentMethod,
        status: 'Pending',
        coupon_code: appliedCoupon ? appliedCoupon.code : undefined,
        discount_amount: discountAmount > 0 ? discountAmount : undefined,
        notes: `Placed from Live Store Demo. Payment: ${paymentMethod}`
      });

      setOrderSuccess(order.order_number);
      setCart([]);
      setIsCheckingOut(false);
      // Reload products to refresh stock count
      await loadStoreData();
    } catch (err) {
      console.error(err);
      alert('Failed to place order. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="space-y-12 pb-24 pt-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Hero Banner with Admin Link */}
      <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] p-8 sm:p-12 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none border border-[#30E1CE]/30">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1876C7]/10 border border-[#1876C7]/20 text-[11px] font-bold text-[#1876C7] uppercase tracking-wider">
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Live Store Demonstration • E-commerce Package</span>
            </div>
            <AnimatedHeading
              text="Janah Online Store"
              as="h1"
              className="text-3xl sm:text-5xl font-extrabold text-[#17202A] tracking-tight leading-tight"
            />
            <AnimatedDescription
              text="Experience the full shopping cart, instant stock management, discount coupons, and checkout workflow. All changes made in the Admin Dashboard sync to this live store immediately."
              className="text-sm sm:text-base text-[#66727D] leading-relaxed"
              delay={0.2}
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-3 shrink-0">
            <Link to="/dashboard">
              <Button variant="navy-blue" className="flex items-center gap-2 h-[42px] px-6 text-sm">
                <Settings className="w-4 h-4" />
                <span>Admin Dashboard</span>
              </Button>
            </Link>
            <Link to="/pricing">
              <Button variant="outline" className="flex items-center gap-2 h-[42px] px-6 text-sm bg-white">
                <span>View Packages</span>
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Floating Cart Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setIsCartOpen(true)}
          className="flex items-center gap-2 px-5 py-3.5 rounded-full bg-gradient-to-r from-[#17202A] to-[#1876C7] text-white shadow-2xl hover:scale-105 transition-transform"
        >
          <ShoppingCart className="w-5 h-5 text-[#30E1CE]" />
          <span className="text-xs font-bold uppercase tracking-wider">Cart</span>
          {totalCartCount > 0 && (
            <span className="w-5 h-5 rounded-full bg-[#30E1CE] text-[#17202A] text-xs font-extrabold flex items-center justify-center">
              {totalCartCount}
            </span>
          )}
        </button>
      </div>

      {/* Search and Category Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-[#1876C7] text-white shadow-md'
                  : 'bg-white border border-[#E2E8EA] text-[#66727D] hover:text-[#17202A] hover:bg-gray-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search products..."
            className="w-full pl-10 pr-4 py-2 text-xs rounded-xl border border-[#E2E8EA] bg-white text-[#17202A] focus:outline-none focus:border-[#1876C7]"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Product Grid */}
      {products.length === 0 ? (
        <div className="py-16 flex flex-col items-center justify-center space-y-3 bg-white rounded-3xl border border-[#E2E8EA]">
          <div className="w-8 h-8 rounded-full border-2 border-[#1876C7] border-t-transparent animate-spin" />
          <p className="text-sm text-[#66727D]">Loading products...</p>
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-[#E2E8EA] p-8 space-y-3">
          <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto" />
          <h3 className="text-base font-bold text-[#17202A]">No products found</h3>
          <p className="text-xs text-[#66727D]">Try choosing another category or clearing your search query.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => {
            const isOutOfStock = !product.in_stock || product.stock_quantity <= 0;
            const isLowStock = product.stock_quantity > 0 && product.stock_quantity < 10;

            return (
              <div 
                key={product.id}
                className="bg-white rounded-tl-2xl rounded-br-2xl rounded-tr-none rounded-bl-none border border-[#E2E8EA] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden group"
              >
                <div>
                  {/* Image Container */}
                  <div className="relative aspect-square overflow-hidden bg-gray-50">
                    <img 
                      src={product.image_url} 
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    
                    {/* Stock Status Pill */}
                    <div className="absolute top-2.5 left-2.5">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold shadow-xs ${
                        isOutOfStock 
                          ? 'bg-red-500 text-white' 
                          : isLowStock 
                            ? 'bg-amber-500 text-white' 
                            : 'bg-emerald-600 text-white'
                      }`}>
                        {isOutOfStock ? 'Out of Stock' : isLowStock ? `Only ${product.stock_quantity} Left` : 'In Stock'}
                      </span>
                    </div>

                    <button 
                      onClick={() => setQuickViewProduct(product)}
                      className="absolute bottom-2.5 right-2.5 px-3 py-1 rounded-lg bg-white/90 backdrop-blur-xs text-[#17202A] text-[11px] font-bold opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                    >
                      Quick View
                    </button>
                  </div>

                  {/* Content */}
                  <div className="p-4 space-y-2">
                    <div className="flex items-center justify-between text-[11px] text-[#66727D]">
                      <span>{product.category}</span>
                      {product.sku && <span className="font-mono text-[10px]">SKU: {product.sku}</span>}
                    </div>
                    
                    <h3 className="text-sm font-bold text-[#17202A] line-clamp-1 group-hover:text-[#1876C7] transition-colors">
                      {product.name}
                    </h3>
                    
                    <p className="text-xs text-[#66727D] line-clamp-2 leading-relaxed">
                      {product.description}
                    </p>
                  </div>
                </div>

                {/* Price and Cart Action */}
                <div className="p-4 pt-0 border-t border-gray-100 mt-2 flex items-center justify-between gap-3">
                  <div>
                    <span className="text-base font-extrabold text-[#1876C7] block">
                      PKR {product.price.toLocaleString()}
                    </span>
                    {product.original_price && (
                      <span className="text-[10px] text-gray-400 line-through">
                        PKR {product.original_price.toLocaleString()}
                      </span>
                    )}
                  </div>

                  <Button
                    variant={isOutOfStock ? 'outline' : 'primary'}
                    disabled={isOutOfStock}
                    onClick={() => addToCart(product)}
                    className="h-[36px] text-xs px-3.5"
                  >
                    <span>{isOutOfStock ? 'Sold Out' : 'Add to Cart'}</span>
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Quick View Modal */}
      {quickViewProduct && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 relative shadow-2xl border border-[#E2E8EA] space-y-6">
            <button 
              onClick={() => setQuickViewProduct(null)}
              className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 text-gray-500"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
              <div className="aspect-square rounded-2xl overflow-hidden bg-gray-100 border border-[#E2E8EA]">
                <img 
                  src={quickViewProduct.image_url} 
                  alt={quickViewProduct.name}
                  className="w-full h-full object-cover" 
                />
              </div>

              <div className="space-y-4">
                <div className="space-y-1">
                  <span className="text-xs font-bold text-[#1876C7] uppercase">{quickViewProduct.category}</span>
                  <h2 className="text-xl font-bold text-[#17202A]">{quickViewProduct.name}</h2>
                  <p className="text-2xl font-extrabold text-[#1876C7] pt-1">
                    PKR {quickViewProduct.price.toLocaleString()}
                  </p>
                </div>

                <p className="text-xs text-[#66727D] leading-relaxed">
                  {quickViewProduct.description}
                </p>

                <div className="pt-2 border-t border-gray-100 space-y-2 text-xs text-[#17202A]">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Stock Availability:</span>
                    <span className="font-bold">{quickViewProduct.stock_quantity} units remaining</span>
                  </div>
                  {quickViewProduct.sku && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Item SKU:</span>
                      <span className="font-mono font-bold">{quickViewProduct.sku}</span>
                    </div>
                  )}
                </div>

                <div className="pt-4">
                  <Button
                    variant="primary"
                    disabled={!quickViewProduct.in_stock || quickViewProduct.stock_quantity <= 0}
                    onClick={() => {
                      addToCart(quickViewProduct);
                      setQuickViewProduct(null);
                    }}
                    className="w-full h-[40px] text-xs"
                  >
                    <span>Add to Shopping Cart</span>
                    <ShoppingCart className="w-4 h-4 ml-1.5" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cart Drawer / Modal */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
          <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-300">
            {/* Header */}
            <div className="p-5 border-b border-[#E2E8EA] flex items-center justify-between bg-[#F8FAFA]">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-[#1876C7]" />
                <h3 className="text-base font-bold text-[#17202A]">Your Shopping Cart</h3>
                <span className="px-2 py-0.5 rounded-full bg-[#1876C7]/10 text-[#1876C7] text-xs font-bold">
                  {totalCartCount} items
                </span>
              </div>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="p-1.5 rounded-lg hover:bg-gray-200 text-gray-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Order Success Notice */}
            {orderSuccess ? (
              <div className="p-8 text-center space-y-4 my-auto">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-[#17202A]">Order Placed Successfully!</h3>
                <p className="text-xs text-[#66727D] leading-relaxed">
                  Thank you for testing the Janah Studio live e-commerce flow. Your order number is:
                </p>
                <span className="text-lg font-mono font-bold text-[#1876C7] block bg-sky-50 py-2 rounded-xl border border-sky-100">
                  {orderSuccess}
                </span>
                <p className="text-[11px] text-[#66727D]">
                  This order has been sent to the <strong>Admin Dashboard</strong> where it can be reviewed and processed.
                </p>
                <div className="pt-4 flex flex-col gap-2">
                  <Link to="/dashboard" onClick={() => setIsCartOpen(false)}>
                    <Button variant="navy-blue" className="w-full text-xs h-[40px]">
                      <span>Open Admin Dashboard to View Order</span>
                    </Button>
                  </Link>
                  <Button variant="outline" onClick={() => setOrderSuccess(null)} className="w-full text-xs h-[40px]">
                    <span>Continue Shopping</span>
                  </Button>
                </div>
              </div>
            ) : isCheckingOut ? (
              /* Checkout Form */
              <div className="flex-grow p-5 overflow-y-auto space-y-4">
                <button 
                  onClick={() => setIsCheckingOut(false)}
                  className="text-xs font-bold text-[#1876C7] flex items-center gap-1 hover:underline"
                >
                  ← Back to Cart
                </button>
                <h4 className="text-sm font-bold text-[#17202A]">Shipping & Customer Details</h4>
                
                <form id="checkout-form" onSubmit={handlePlaceOrder} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-[#17202A]">Full Name</label>
                    <input 
                      type="text" 
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Tariq Mehmood"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-[#17202A]">Email Address</label>
                      <input 
                        type="email" 
                        required
                        value={customerEmail}
                        onChange={(e) => setCustomerEmail(e.target.value)}
                        placeholder="tariq@gmail.com"
                        className="w-full px-3 py-2 text-xs rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-[#17202A]">WhatsApp / Phone</label>
                      <input 
                        type="tel" 
                        required
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="0300-1234567"
                        className="w-full px-3 py-2 text-xs rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-[#17202A]">Shipping Address</label>
                    <textarea 
                      required
                      rows={2}
                      value={shippingAddress}
                      onChange={(e) => setShippingAddress(e.target.value)}
                      placeholder="House/Street, Area, Landmark"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-[#17202A]">City</label>
                    <input 
                      type="text" 
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="e.g. Lahore, Karachi, Islamabad"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                    />
                  </div>

                  <div className="space-y-1.5 pt-2">
                    <label className="text-[11px] font-bold text-[#17202A]">Payment Method</label>
                    <div className="space-y-1.5 text-xs">
                      {[
                        { id: 'Cash on Delivery (COD)', desc: 'Pay with cash upon package receipt' },
                        { id: 'Bank Transfer', desc: 'Transfer to Janah Studio account (Meezan/HBL)' },
                        { id: 'Online Payment Gateway', desc: 'Instant JazzCash/Easypaisa/Card (Premium)' }
                      ].map((m) => (
                        <label 
                          key={m.id}
                          className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition-colors ${
                            paymentMethod === m.id ? 'border-[#1876C7] bg-[#1876C7]/5' : 'border-[#E2E8EA]'
                          }`}
                        >
                          <input 
                            type="radio" 
                            name="payment"
                            checked={paymentMethod === m.id}
                            onChange={() => setPaymentMethod(m.id as any)}
                            className="mt-0.5 text-[#1876C7]"
                          />
                          <div>
                            <span className="font-bold text-[#17202A] block">{m.id}</span>
                            <span className="text-[10px] text-[#66727D]">{m.desc}</span>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                </form>
              </div>
            ) : (
              /* Cart Items List */
              <div className="flex-grow p-5 overflow-y-auto space-y-4">
                {cart.length === 0 ? (
                  <div className="text-center py-16 space-y-3">
                    <ShoppingBag className="w-12 h-12 text-gray-300 mx-auto" />
                    <p className="text-xs text-[#66727D]">Your shopping cart is empty.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {cart.map((item) => (
                      <div key={item.product.id} className="flex gap-3 p-3 rounded-2xl border border-[#E2E8EA] bg-white">
                        <img 
                          src={item.product.image_url} 
                          alt={item.product.name}
                          className="w-16 h-16 rounded-xl object-cover bg-gray-50 border border-gray-100 shrink-0" 
                        />
                        <div className="flex-grow space-y-1">
                          <h4 className="text-xs font-bold text-[#17202A] line-clamp-1">{item.product.name}</h4>
                          <span className="text-xs font-extrabold text-[#1876C7] block">
                            PKR {(item.product.price * item.quantity).toLocaleString()}
                          </span>
                          <div className="flex items-center gap-2 pt-1">
                            <div className="flex items-center border border-[#E2E8EA] rounded-lg bg-gray-50">
                              <button 
                                onClick={() => updateQuantity(item.product.id, -1)}
                                className="p-1 text-gray-500 hover:text-[#17202A]"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="px-2 text-xs font-bold text-[#17202A]">{item.quantity}</span>
                              <button 
                                onClick={() => updateQuantity(item.product.id, 1)}
                                className="p-1 text-gray-500 hover:text-[#17202A]"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                            <button 
                              onClick={() => removeFromCart(item.product.id)}
                              className="text-[10px] text-red-600 hover:underline ml-auto"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}

                    {/* Discount Coupon Form */}
                    <div className="p-3 bg-[#F8FAFA] rounded-2xl border border-[#E2E8EA] space-y-2">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-[#17202A]">
                        <Tag className="w-3.5 h-3.5 text-[#1876C7]" />
                        <span>Discount Coupon</span>
                      </div>
                      {appliedCoupon ? (
                        <div className="flex items-center justify-between text-xs bg-emerald-50 text-emerald-800 p-2 rounded-xl border border-emerald-200">
                          <span>Applied: <strong>{appliedCoupon.code}</strong> ({appliedCoupon.discount_percentage}% OFF)</span>
                          <button onClick={() => setAppliedCoupon(null)} className="text-red-600 text-[10px] font-bold">Remove</button>
                        </div>
                      ) : (
                        <form onSubmit={applyCoupon} className="flex gap-2">
                          <input 
                            type="text" 
                            value={couponCode}
                            onChange={(e) => setCouponCode(e.target.value)}
                            placeholder="e.g. WELCOME10"
                            className="flex-grow px-3 py-1.5 text-xs rounded-xl border border-[#E2E8EA] uppercase focus:outline-none focus:border-[#1876C7]"
                          />
                          <button 
                            type="submit"
                            className="px-3 py-1.5 rounded-xl bg-[#17202A] text-white text-xs font-bold hover:bg-[#1876C7] transition-colors"
                          >
                            Apply
                          </button>
                        </form>
                      )}
                      {couponError && <p className="text-[10px] text-red-600">{couponError}</p>}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Footer with Summary and Checkout Button */}
            {!orderSuccess && cart.length > 0 && (
              <div className="p-5 border-t border-[#E2E8EA] bg-[#F8FAFA] space-y-3">
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-[#66727D]">
                    <span>Subtotal:</span>
                    <span>PKR {subtotal.toLocaleString()}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-bold">
                      <span>Discount ({appliedCoupon?.discount_percentage}%):</span>
                      <span>- PKR {discountAmount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-[#66727D]">
                    <span>Delivery Charges:</span>
                    <span className="text-emerald-600 font-bold">FREE</span>
                  </div>
                  <div className="flex justify-between text-base font-extrabold text-[#17202A] pt-2 border-t border-gray-200">
                    <span>Total Amount:</span>
                    <span className="text-[#1876C7]">PKR {finalTotal.toLocaleString()}</span>
                  </div>
                </div>

                {isCheckingOut ? (
                  <Button
                    variant="primary"
                    disabled={isSubmitting}
                    onClick={() => {
                      const form = document.getElementById('checkout-form') as HTMLFormElement;
                      if (form) form.requestSubmit();
                    }}
                    className="w-full h-[42px] text-xs font-bold"
                  >
                    <span>{isSubmitting ? 'Processing Order...' : 'Confirm & Place Order'}</span>
                  </Button>
                ) : (
                  <Button
                    variant="primary"
                    onClick={() => setIsCheckingOut(true)}
                    className="w-full h-[42px] text-xs font-bold"
                  >
                    <span>Proceed to Checkout</span>
                    <ArrowRight className="w-4 h-4 ml-1.5" />
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
