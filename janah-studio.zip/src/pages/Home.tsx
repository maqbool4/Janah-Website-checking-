import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  ArrowRight, 
  CheckCircle2, 
  Code, 
  ShoppingBag, 
  Layout, 
  RefreshCw, 
  Smartphone, 
  ShieldCheck, 
  Zap, 
  HelpCircle,
  MessageCircle,
  ExternalLink,
  User,
  ChevronLeft,
  ChevronRight,
  Plus,
  Minus,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { dataStore } from '../lib/dataStore';
import { ServiceItem, PortfolioProject, PricingPackage, FaqItem, TestimonialItem } from '../lib/types';
import { Button } from '../components/ui/Button';
import { PortfolioPricingTable } from '../components/PortfolioPricingTable';
import { AnimatedSection } from '../components/ui/AnimatedSection';
import { AnimatedHeading } from '../components/ui/AnimatedHeading';
import { AnimatedDescription } from '../components/ui/AnimatedDescription';
import featuredProject from '../assets/images/featured_project.png';
import ecommerceProject from '../assets/images/ecommerce_project.png';
import portfolioProject from '../assets/images/portfolio_project.png';
import redesignProject from '../assets/images/redesign_service.png';
import heroImage from '../assets/images/hero_image.png';

const slides = [
  {
    id: 'web-dev',
    title: 'Website Development',
    tagline: 'Build a Professional Online Presence',
    description: 'We develop professional websites tailored to your business, audience, and goals. A well-planned website helps you present services clearly and build customer trust.',
    image: heroImage,
    link: '/services',
  },
  {
    id: 'ecommerce',
    title: 'E-commerce Development',
    tagline: 'Bring Your Products Online',
    description: 'We build online stores that help you showcase products, organize information, and give customers a smooth browsing and ordering experience.',
    image: ecommerceProject,
    link: '/services',
  },
  {
    id: 'landing-pages',
    title: 'Landing Page Development',
    tagline: 'Turn Visitor Attention into Action',
    description: 'We create focused landing pages for specific services, products, and campaigns with clear messaging and focused calls to action.',
    image: featuredProject,
    link: '/services',
  },
  {
    id: 'redesign',
    title: 'Website Redesign',
    tagline: 'Give Your Existing Website a Fresh Start',
    description: 'We improve existing websites with modern presentation, clearer content structure, improved usability, and responsive layouts.',
    image: redesignProject,
    link: '/services',
  },
  {
    id: 'portfolio',
    title: 'Portfolio Website',
    tagline: 'Showcase Your Work, Skills, and Experience',
    description: 'We create professional portfolio websites for freelancers, creatives, and professionals to establish a credible online presence and share work easily.',
    image: portfolioProject,
    link: '/portfolio',
  },
  {
    id: 'maintenance',
    title: 'Website Maintenance & Support',
    tagline: 'Keep Your Website Updated and Working Smoothly',
    description: 'We provide ongoing website updates, content changes, technical fixes, and maintenance support to keep your site reliable and functional.',
    image: heroImage,
    link: '/maintenance-support',
  },
];

const howItWorksSteps = [
  { num: '01', title: 'Initial Discussion', desc: 'Tell us about your website needs and goals.' },
  { num: '02', title: 'Plan & Pricing', desc: 'We finalize the requirements, project scope, and price.' },
  { num: '03', title: 'Project Confirmation', desc: 'Approve the quote and complete the initial payment.' },
  { num: '04', title: 'Design & Development', desc: 'We build your website and make the included revisions.' },
  { num: '05', title: 'Approval & Launch', desc: 'Approve the final website, complete payment, and go live.' },
];

const SectionHeading: React.FC<{ title: string; subtitle?: string; light?: boolean }> = ({ title, subtitle, light = false }) => (
  <div className="text-left space-y-2 mb-8">
    <AnimatedHeading
      text={title}
      as="h2"
      className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${light ? 'text-white' : 'text-[#17202A]'}`}
    />
    <div className="w-36 h-3 mt-2">
      <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
        <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
        <defs>
          <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#30E1CE" />
            <stop offset="50%" stopColor="#1876C7" />
            <stop offset="100%" stopColor="#A855F7" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  </div>
);

export default function Home() {
  const navigate = useNavigate();
  const [services, setServices] = useState<ServiceItem[]>(() => dataStore.getServicesSync().filter(s => s.is_active));
  const [portfolio, setPortfolio] = useState<PortfolioProject[]>(() => dataStore.getPortfolioSync().filter(p => p.is_active));
  const [pricing, setPricing] = useState<PricingPackage[]>(() => dataStore.getPricingSync().filter(p => p.is_active && p.category === 'website'));
  const [faqs, setFaqs] = useState<FaqItem[]>(() => {
    const all = dataStore.getFaqsSync().filter(f => f.is_active);
    const featuredIds = ['faq-1', 'faq-3', 'faq-11', 'faq-48', 'faq-49'];
    const featured = all.filter(f => featuredIds.includes(f.id));
    return featured.length === 5 ? featured : all.slice(0, 5);
  });
  const [testimonials, setTestimonials] = useState<TestimonialItem[]>(() => dataStore.getTestimonialsSync().filter(t => t.is_active));
  const [currentSlide, setCurrentSlide] = useState(0);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  // Testimonials slider state
  const [currentTestimonialIndex, setCurrentTestimonialIndex] = useState(0);
  const [isTestimonialPaused, setIsTestimonialPaused] = useState(false);
  const [testimonialTouchStart, setTestimonialTouchStart] = useState<number | null>(null);
  const [testimonialTouchEnd, setTestimonialTouchEnd] = useState<number | null>(null);
  const [openFaqId, setOpenFaqId] = useState<string | null>(null);

  const minSwipeDistance = 50;

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;
    if (isLeftSwipe) {
      setCurrentStepIndex((prev) => (prev + 1) % howItWorksSteps.length);
    } else if (isRightSwipe) {
      setCurrentStepIndex((prev) => (prev - 1 + howItWorksSteps.length) % howItWorksSteps.length);
    }
  };

  const onTestimonialTouchStart = (e: React.TouchEvent) => {
    setTestimonialTouchEnd(null);
    setTestimonialTouchStart(e.targetTouches[0].clientX);
  };

  const onTestimonialTouchMove = (e: React.TouchEvent) => {
    setTestimonialTouchEnd(e.targetTouches[0].clientX);
  };

  const onTestimonialTouchEnd = () => {
    if (!testimonialTouchStart || !testimonialTouchEnd || testimonials.length === 0) return;
    const distance = testimonialTouchStart - testimonialTouchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;
    if (isLeftSwipe) {
      setCurrentTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    } else if (isRightSwipe) {
      setCurrentTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrentStepIndex((prev) => (prev + 1) % howItWorksSteps.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [isPaused]);

  useEffect(() => {
    if (isTestimonialPaused || testimonials.length === 0) return;
    const timer = setInterval(() => {
      setCurrentTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [isTestimonialPaused, testimonials.length]);

  useEffect(() => {
    dataStore.getServices().then(res => setServices(res.filter(s => s.is_active)));
    dataStore.getPortfolio().then(res => setPortfolio(res.filter(p => p.is_active)));
    dataStore.getPricing().then(res => setPricing(res.filter(p => p.is_active && p.category === 'website')));
    dataStore.getFaqs().then(res => {
      const all = res.filter(f => f.is_active);
      const featuredIds = ['faq-1', 'faq-3', 'faq-11', 'faq-48', 'faq-49'];
      const featured = all.filter(f => featuredIds.includes(f.id));
      setFaqs(featured.length === 5 ? featured : all.slice(0, 5));
    });
    dataStore.getTestimonials().then(res => setTestimonials(res.filter(t => t.is_active)));
  }, []);

  const whatsappUrl = `https://wa.me/923295430114?text=${encodeURIComponent("Hi Janah Studio, I'd like to discuss a website project.")}`;

  return (
    <div className="space-y-16 sm:space-y-24 pb-20">
      
      {/* Hero Heading Section */}
      <section className="relative text-[#17202A] pt-6 sm:pt-10 pb-8 sm:pb-12 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30 bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70">
        {/* Ambient decorative lighting with present color accents */}
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#30E1CE]/60 to-transparent"></div>
        <div className="absolute -top-16 -right-16 w-80 h-80 bg-[#30E1CE]/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-16 right-10 w-96 h-96 bg-[#1876C7]/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-1/3 -left-16 w-72 h-72 bg-purple-200/25 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-3 text-left">
            <AnimatedHeading
              text="Professional Websites That Help Your Business Get Found and Grow"
              as="h1"
              className="text-2xl sm:text-4xl lg:text-5xl font-extrabold text-[#17202A] tracking-tight leading-[1.15]"
            />

            <div className="w-36 h-3 mt-1 mb-2">
              <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
                <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient-hero)" strokeWidth="2.5" strokeLinecap="round" />
                <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient-hero)" strokeWidth="2.5" strokeLinecap="round" />
                <defs>
                  <linearGradient id="wave-gradient-hero" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#30E1CE" />
                    <stop offset="50%" stopColor="#1876C7" />
                    <stop offset="100%" stopColor="#A855F7" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
            
            <AnimatedDescription
              text="We build professional websites, portfolio websites, and online stores for small businesses that want to look credible, reach more customers, and grow online."
              className="text-xs sm:text-base text-[#66727D] leading-relaxed font-medium"
              delay={0.2}
            />

            <div className="flex flex-wrap items-center gap-2 pt-2">
              <Button
                variant="navy-blue"
                onClick={() => navigate('/contact')}
                className="flex items-center gap-2"
              >
                <span>Let’s Build</span>
                <ArrowRight className="w-4 h-4" />
              </Button>

              <Button
                variant="chat"
                onClick={() => window.open(whatsappUrl, '_blank')}
                className="px-6 py-3 flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-white" />
                <span>Chat Us</span>
              </Button>
            </div>

            <div className="pt-4 sm:pt-6 grid grid-cols-3 gap-2 sm:gap-4 border-t border-[#17202A]/10">
              <div>
                <p className="text-lg sm:text-xl font-bold text-[#17202A]">100%</p>
                <p className="text-[11px] sm:text-xs text-[#66727D] font-medium">Responsive Design</p>
              </div>
              <div>
                <p className="text-lg sm:text-xl font-bold text-[#17202A]">Fast</p>
                <p className="text-[11px] sm:text-xs text-[#66727D] font-medium">Performance Optimized</p>
              </div>
              <div>
                <p className="text-lg sm:text-xl font-bold text-[#17202A]">Reliable</p>
                <p className="text-[11px] sm:text-xs text-[#66727D] font-medium">Support & Maintenance</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Showcase Section */}
      <AnimatedSection>
        <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] pt-2 pb-10 sm:pb-14 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30">
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#30E1CE]/50 to-transparent"></div>
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-64 h-6 bg-[#30E1CE]/10 blur-xl rounded-full pointer-events-none"></div>

        <div className="max-w-7xl mx-auto">
          <SectionHeading 
            title="Website Services for Your Business" 
            subtitle="Our Services Showcase" 
          />
          <AnimatedDescription
            text="Explore our core website development services designed to help your business establish a powerful online presence."
            className="text-xs sm:text-sm text-[#66727D] leading-relaxed max-w-xl text-left -mt-6 mb-8"
          />

          <div className="max-w-xl mx-auto">
            <div className="relative bg-white/95 backdrop-blur-md rounded-tl-2xl rounded-br-2xl rounded-tr-none rounded-bl-none p-5 border border-[#30E1CE]/30 shadow-xl space-y-4 text-[#17202A]">
              {/* Card Header with Centered Services Title */}
              <div className="relative flex items-center justify-between border-b border-[#E2E8EA] pb-3">
                <div className="flex items-center gap-1.5 shrink-0 z-10">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-400"></div>
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-400"></div>
                  <div className="w-2.5 h-2.5 rounded-full bg-green-400"></div>
                </div>
                <div className="absolute inset-x-0 text-center pointer-events-none px-12">
                  <span className="text-xs font-bold text-[#17202A] tracking-tight truncate block">
                    Website Services Showcase
                  </span>
                </div>
                <span className="text-[11px] font-mono font-medium text-[#66727D] shrink-0 z-10">
                  {currentSlide + 1}/{slides.length}
                </span>
              </div>

              <div className="space-y-3">
                {/* Active Service Showcase Slide */}
                <div
                  onClick={() => navigate(slides[currentSlide].link)}
                  className="cursor-pointer group block"
                  title="Click to view full service details"
                >
                  <div className="relative h-[240px] rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none border border-[#1876C7]/20 overflow-hidden shadow-xs bg-white flex flex-col group-hover:border-[#1876C7] transition-all">
                    {/* Active Service Image with Smooth White Transition Effect */}
                    <div className="relative h-32 w-full overflow-hidden bg-white shrink-0">
                      <AnimatePresence mode="wait">
                        <motion.div
                          key={`service-img-${currentSlide}`}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.35, ease: 'easeInOut' }}
                          className="absolute inset-0 bg-white"
                        >
                          <img
                            src={slides[currentSlide].image}
                            alt={slides[currentSlide].title}
                            className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                            loading="eager"
                            decoding="sync"
                          />
                          <div className="absolute top-2.5 left-2.5">
                            <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#17202A]/85 backdrop-blur-xs text-white">
                              {slides[currentSlide].tagline}
                            </span>
                          </div>
                        </motion.div>
                      </AnimatePresence>
                    </div>

                    {/* Text Details Area with Smooth Crossfade */}
                    <div className="relative p-3.5 bg-white flex flex-col justify-between flex-grow min-h-[96px]">
                      {slides.map((slide, idx) => (
                        <div
                          key={slide.id}
                          className={`transition-opacity duration-200 ease-in-out ${
                            idx === currentSlide ? 'opacity-100 block' : 'opacity-0 hidden'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <h4 className="text-sm font-bold text-[#17202A] group-hover:text-[#1876C7] transition-colors text-left">
                              {slide.title}
                            </h4>
                            <span className="text-[11px] font-bold text-[#1876C7] inline-flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform shrink-0">
                              Details <ArrowRight className="w-3 h-3" />
                            </span>
                          </div>
                          <p className="text-[11px] text-[#66727D] leading-relaxed line-clamp-2 mt-1 text-left">
                            {slide.description}
                          </p>
                        </div>
                      ))}
                    </div>

                    {/* Slide Pagination Dots */}
                    <div className="absolute bottom-2.5 left-0 right-0 flex justify-center items-center gap-1.5 z-10">
                      {slides.map((_, idx) => (
                        <button
                          key={idx}
                          onClick={(e) => {
                            e.stopPropagation();
                            setCurrentSlide(idx);
                          }}
                          aria-label={`Slide ${idx + 1}`}
                          className={`h-1.5 rounded-full transition-all cursor-pointer ${
                            idx === currentSlide ? 'w-4 bg-[#1876C7]' : 'w-1.5 bg-gray-300 hover:bg-gray-400'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                {/* Interactive Service Selector Grid */}
                <div className="grid grid-cols-2 gap-2">
                  {slides.map((service, idx) => {
                    const isActive = idx === currentSlide;
                    return (
                      <button
                        key={service.id}
                        onClick={() => setCurrentSlide(idx)}
                        className={`px-3 py-2 rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none text-left border transition-all text-xs flex items-center justify-between cursor-pointer ${
                          isActive
                            ? 'bg-[#1876C7]/15 border-[#1876C7] text-[#1876C7] font-bold shadow-xs'
                            : 'bg-white border-[#E2E8EA] text-[#17202A] hover:bg-gray-50 hover:border-[#1876C7]/30'
                        }`}
                      >
                        <span className="truncate">{service.title}</span>
                        <span
                          className={`w-1.5 h-1.5 rounded-full shrink-0 ml-1.5 transition-all ${
                            isActive ? 'bg-[#1876C7] scale-125' : 'bg-transparent'
                          }`}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>

              <Button
                variant="navy-blue"
                onClick={() => navigate('/services')}
                className="w-full flex items-center justify-center gap-2"
              >
                <span>View All Services</span>
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#1876C7]/40 to-transparent"></div>
      </section>
      </AnimatedSection>

      {/* About Janah Studio Section */}
      <AnimatedSection>
        <section className="relative bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] pt-2 pb-10 sm:pb-14 overflow-hidden shadow-xl rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border border-[#30E1CE]/30">
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#30E1CE]/50 to-transparent"></div>
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-64 h-6 bg-[#30E1CE]/10 blur-xl rounded-full pointer-events-none"></div>

        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            <div className="lg:col-span-5 space-y-4 text-left">
              <AnimatedHeading
                text="About Janah Studio"
                as="h2"
                className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-[#17202A] leading-tight text-left"
              />
              <div className="w-36 h-3 mt-1 mb-2">
                <svg viewBox="0 0 160 12" fill="none" className="w-full h-3">
                  <path d="M0 3C20 3 20 9 40 9C60 9 60 3 80 3C100 3 100 9 120 9C140 9 140 3 160 3" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
                  <path d="M0 8C20 8 20 2 40 2C60 2 60 8 80 8C100 8 100 2 120 2C140 2 140 8 160 8" stroke="url(#wave-gradient)" strokeWidth="2.5" strokeLinecap="round" />
                  <defs>
                    <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#30E1CE" />
                      <stop offset="50%" stopColor="#1876C7" />
                      <stop offset="100%" stopColor="#A855F7" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>

              <div className="space-y-3 text-[#66727D] text-xs sm:text-sm leading-relaxed">
                <p>
                  Janah Studio is a web development studio focused on helping small businesses and individuals build a professional online presence. We create business websites, online stores, landing pages, and personal portfolio websites tailored to different needs and goals.
                </p>
                <p>
                  Our approach focuses on practical solutions, responsive design, clear communication, and user-friendly experiences. We aim to make the website development process straightforward while helping our clients present their work, services, and businesses professionally online.
                </p>
                <p>
                  Whether you are starting a new business, showcasing your skills, or improving your existing online presence, Janah Studio works with you to develop a website suited to your requirements.
                </p>
              </div>
              <div className="pt-2">
                <Button
                  variant="navy-blue"
                  onClick={() => navigate('/about')}
                  className="flex items-center gap-2"
                >
                  <span>About Janah Studio</span>
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* 01 */}
              <div className="relative overflow-hidden bg-white/90 backdrop-blur-md hover:bg-white border border-[#30E1CE]/30 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-5 transition-all group shadow-sm">
                <div className="absolute top-2 right-4 text-4xl sm:text-5xl font-extrabold text-[#1876C7]/10 select-none pointer-events-none font-mono group-hover:text-[#1876C7]/20 transition-colors">
                  01
                </div>
                <div className="relative z-10 space-y-1.5 text-left">
                  <h3 className="text-base font-bold text-[#17202A] flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#1876C7] shrink-0"></span>
                    Designed Around Your Goals
                  </h3>
                  <p className="text-xs text-[#66727D] leading-relaxed">
                    Every project starts with understanding your needs, audience, and objectives. We shape the website around your requirements rather than using a one-size-fits-all approach.
                  </p>
                </div>
              </div>

              {/* 02 */}
              <div className="relative overflow-hidden bg-white/90 backdrop-blur-md hover:bg-white border border-[#30E1CE]/30 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-5 transition-all group shadow-sm">
                <div className="absolute top-2 right-4 text-4xl sm:text-5xl font-extrabold text-[#1876C7]/10 select-none pointer-events-none font-mono group-hover:text-[#1876C7]/20 transition-colors">
                  02
                </div>
                <div className="relative z-10 space-y-1.5 text-left">
                  <h3 className="text-base font-bold text-[#17202A] flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#1876C7] shrink-0"></span>
                    Professional and User-Friendly
                  </h3>
                  <p className="text-xs text-[#66727D] leading-relaxed">
                    We focus on clear content, intuitive navigation, and a professional presentation to help visitors understand your business and find the information they need.
                  </p>
                </div>
              </div>

              {/* 03 */}
              <div className="relative overflow-hidden bg-white/90 backdrop-blur-md hover:bg-white border border-[#30E1CE]/30 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-5 transition-all group shadow-sm">
                <div className="absolute top-2 right-4 text-4xl sm:text-5xl font-extrabold text-[#1876C7]/10 select-none pointer-events-none font-mono group-hover:text-[#1876C7]/20 transition-colors">
                  03
                </div>
                <div className="relative z-10 space-y-1.5 text-left">
                  <h3 className="text-base font-bold text-[#17202A] flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#1876C7] shrink-0"></span>
                    Responsive Across Devices
                  </h3>
                  <p className="text-xs text-[#66727D] leading-relaxed">
                    Your website is developed to provide a usable experience across mobile phones, tablets, and desktop screens, so visitors can access your content on different devices.
                  </p>
                </div>
              </div>

              {/* 04 */}
              <div className="relative overflow-hidden bg-white/90 backdrop-blur-md hover:bg-white border border-[#30E1CE]/30 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-5 transition-all group shadow-sm">
                <div className="absolute top-2 right-4 text-4xl sm:text-5xl font-extrabold text-[#1876C7]/10 select-none pointer-events-none font-mono group-hover:text-[#1876C7]/20 transition-colors">
                  04
                </div>
                <div className="relative z-10 space-y-1.5 text-left">
                  <h3 className="text-base font-bold text-[#17202A] flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#1876C7] shrink-0"></span>
                    Built for Your Online Growth
                  </h3>
                  <p className="text-xs text-[#66727D] leading-relaxed">
                    We consider website structure, search engine fundamentals, performance, and usability to establish a practical foundation for your online presence.
                  </p>
                </div>
              </div>

              {/* 05 */}
              <div className="sm:col-span-2 relative overflow-hidden bg-white/90 backdrop-blur-md hover:bg-white border border-[#30E1CE]/30 rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-5 transition-all group shadow-sm">
                <div className="absolute top-2 right-4 text-4xl sm:text-5xl font-extrabold text-[#1876C7]/10 select-none pointer-events-none font-mono group-hover:text-[#1876C7]/20 transition-colors">
                  05
                </div>
                <div className="relative z-10 space-y-1.5 text-left">
                  <h3 className="text-base font-bold text-[#17202A] flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#1876C7] shrink-0"></span>
                    Clear Communication
                  </h3>
                  <p className="text-xs text-[#66727D] leading-relaxed">
                    We discuss your requirements, explain the project process, and keep you informed as your website progresses through development and review.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>

        <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#1876C7]/40 to-transparent"></div>
      </section>
      </AnimatedSection>

      {/* Portfolio Preview Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading 
          title="Our Portfolio" 
          subtitle="Portfolio Showcase" 
        />
        <AnimatedDescription
          text="Explore websites created for real clients and demonstration projects showcasing Janah Studio's work and capabilities."
          className="text-xs sm:text-sm text-[#66727D] leading-relaxed max-w-xl text-left -mt-6 mb-8"
        />

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-5">
          {portfolio.slice(0, 4).map((project, idx) => (
            <AnimatedSection key={project.id} direction={idx % 2 === 0 ? "left" : "right"} delay={idx * 0.06}>
              <div 
                className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 backdrop-blur-md rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none overflow-hidden border border-[#30E1CE]/30 shadow-lg hover:shadow-xl transition-all duration-300 group flex flex-col justify-between hover:-translate-y-0.5 h-full"
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-gray-100">
                  <img 
                    src={
                      project.id === 'port1' 
                        ? ecommerceProject 
                        : project.id === 'port2' 
                          ? heroImage 
                          : project.id === 'port3'
                            ? redesignProject
                            : project.id === 'port4'
                              ? featuredProject
                              : project.image_url
                    } 
                    alt={project.project_name} 
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                  />
                  <span 
                    className={`absolute top-2 left-2 px-2 py-0.5 rounded-full text-[9px] sm:text-[10px] font-bold shadow-xs ${
                      project.project_type === 'Demo' 
                        ? 'bg-[#30E1CE] text-[#17202A]' 
                        : 'bg-[#1876C7] text-white'
                    }`}
                  >
                    {project.project_type === 'Demo' ? 'Demo' : 'Client Project'}
                  </span>
                </div>

                <div className="p-3 sm:p-4 flex flex-col justify-between flex-grow space-y-2">
                  <div>
                    <div className="flex items-start justify-between gap-1.5">
                      <div className="space-y-0.5 min-w-0 text-left">
                        <span className="text-[10px] font-semibold text-[#1876C7] uppercase tracking-wider block truncate">
                          {project.category}
                        </span>
                        <h3 className="text-xs sm:text-sm font-bold text-[#17202A] leading-snug group-hover:text-[#1876C7] transition-colors truncate">
                          {project.project_name}
                        </h3>
                      </div>

                      {project.project_url && project.project_url !== '#' && project.project_url.startsWith('http') ? (
                        <a
                          href={project.project_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="shrink-0 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none bg-gradient-to-r from-[#30E1CE] to-[#1876C7] text-[#17202A] text-[10px] sm:text-xs font-bold shadow-md hover:opacity-95 active:scale-97 transition-all inline-flex items-center justify-center gap-1"
                          title="Visit Website"
                        >
                          <span>Visit</span>
                          <ExternalLink className="w-3 h-3 text-[#17202A]" />
                        </a>
                      ) : (
                        <button
                          onClick={() => navigate('/portfolio')}
                          className="shrink-0 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none bg-gradient-to-r from-[#30E1CE] to-[#1876C7] text-[#17202A] text-[10px] sm:text-xs font-bold shadow-md hover:opacity-95 active:scale-97 transition-all inline-flex items-center justify-center gap-1 cursor-pointer"
                          title="View Project"
                        >
                          <span>Visit</span>
                          <ExternalLink className="w-3 h-3 text-[#17202A]" />
                        </button>
                      )}
                    </div>

                    <p className="text-[11px] sm:text-xs text-[#66727D] leading-relaxed line-clamp-2 mt-1 text-left">
                      {project.short_description}
                    </p>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>

        {/* Centralized View Portfolio CTA Button */}
        <div className="flex justify-center pt-8">
          <Button
            variant="primary"
            onClick={() => navigate('/portfolio')}
          >
            <span>View Portfolio</span>
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </section>
      </AnimatedSection>

      {/* Pricing Preview Section */}
      <AnimatedSection>
        <section className="bg-[#F8FAFA] py-20 border-y border-[#E2E8EA]/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
          
          {/* Portfolio & One Page Website Pricing Table */}
          <PortfolioPricingTable />

          {/* Complete Pricing Packages Redirect Card */}
          <div className="relative overflow-hidden bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 backdrop-blur-md rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-6 sm:p-10 border border-[#30E1CE]/30 shadow-xl">
            {/* Ambient decorative lighting */}
            <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-[#30E1CE]/60 to-transparent"></div>
            <div className="absolute -top-12 -right-12 w-64 h-64 bg-[#30E1CE]/15 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-[#1876C7]/10 rounded-full blur-3xl pointer-events-none"></div>

            <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-8 text-left">
              <div className="max-w-2xl space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-[#30E1CE]/20 to-[#1876C7]/20 border border-[#1876C7]/25 text-xs font-bold text-[#1876C7]">
                  <Sparkles className="w-3.5 h-3.5 text-[#1876C7]" />
                  <span>Transparent Pricing • Complete Packages</span>
                </div>

                <AnimatedHeading
                  text="Looking for Business, E-commerce, or Redesign Pricing?"
                  as="h3"
                  className="text-2xl sm:text-3xl font-extrabold text-[#17202A] tracking-tight"
                />

                <AnimatedDescription
                  text="We offer transparent, fixed-price development packages tailored to your business goals. Explore detailed feature comparison tables, deliverables, and turnaround times for all our services:"
                  className="text-sm sm:text-base text-[#66727D] leading-relaxed"
                  delay={0.15}
                />

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-[#17202A]">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0" />
                    <span>Business Website Packages (Standard & Premium)</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-[#17202A]">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0" />
                    <span>E-commerce Stores with Admin Dashboard</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-[#17202A]">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0" />
                    <span>High-Converting Landing Pages</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-[#17202A]">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0" />
                    <span>Website Redesign & Rebuilding Plans</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-[#17202A]">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0" />
                    <span>Website Maintenance & Care Plans</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-[#17202A]">
                    <CheckCircle2 className="w-4 h-4 text-[#1876C7] shrink-0" />
                    <span>Free First-Year Hosting & Subdomain Included</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-row items-center gap-2 sm:gap-3 shrink-0 w-full sm:w-auto pt-2 lg:pt-0">
                <Button
                  variant="navy-blue"
                  onClick={() => navigate('/pricing')}
                  className="flex-1 sm:flex-initial px-3.5 sm:px-5 py-2.5 sm:py-3 flex items-center justify-center gap-1.5 sm:gap-2 text-xs sm:text-sm font-bold shadow-md whitespace-nowrap"
                >
                  <span>View Pricing</span>
                  <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
                </Button>

                <Button
                  variant="chat"
                  onClick={() => window.open(whatsappUrl, '_blank')}
                  className="flex-1 sm:flex-initial px-3.5 sm:px-5 py-2.5 sm:py-3 flex items-center justify-center gap-1.5 sm:gap-2 text-xs sm:text-sm font-bold shadow-md whitespace-nowrap"
                >
                  <MessageCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white shrink-0" />
                  <span>Custom Quote</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
      </AnimatedSection>

      {/* Process Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading 
          title="How We Build Your Website" 
          subtitle="Workflow" 
        />

        <div 
          className="max-w-xl mx-auto bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 backdrop-blur-md rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-6 sm:p-8 border border-[#30E1CE]/30 shadow-lg relative overflow-hidden transition-all text-left"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
        >
          {/* Step Header with Number & Navigation Buttons */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-[#1876C7] px-2.5 py-1 rounded-full bg-[#1876C7]/15">
                {howItWorksSteps[currentStepIndex].num} / 05
              </span>
              <span className="w-2 h-2 rounded-full bg-[#30E1CE] animate-pulse"></span>
            </div>
            
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setCurrentStepIndex((prev) => (prev - 1 + howItWorksSteps.length) % howItWorksSteps.length)}
                className="p-1.5 rounded-full hover:bg-white/80 text-gray-700 transition-colors border border-gray-200 cursor-pointer shadow-xs"
                aria-label="Previous Step"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setCurrentStepIndex((prev) => (prev + 1) % howItWorksSteps.length)}
                className="p-1.5 rounded-full hover:bg-white/80 text-gray-700 transition-colors border border-gray-200 cursor-pointer shadow-xs"
                aria-label="Next Step"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Step Content */}
          <div className="space-y-3 min-h-[110px]">
            <h3 className="text-lg sm:text-xl font-bold text-[#17202A] tracking-tight">
              {howItWorksSteps[currentStepIndex].title}
            </h3>
            <p className="text-xs sm:text-sm text-[#66727D] leading-relaxed">
              {howItWorksSteps[currentStepIndex].desc}
            </p>
          </div>

          {/* Slider Indicators directly below description inside card */}
          <div className="flex items-center justify-between pt-5 mt-5 border-t border-[#E2E8EA]">
            <div className="flex items-center gap-1.5">
              {howItWorksSteps.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentStepIndex(idx)}
                  className={`h-1.5 rounded-full transition-all cursor-pointer ${
                    idx === currentStepIndex ? 'w-6 bg-[#1876C7]' : 'w-1.5 bg-gray-300 hover:bg-gray-400'
                  }`}
                  aria-label={`Go to step ${idx + 1}`}
                />
              ))}
            </div>
            <span className="text-[11px] font-semibold text-gray-500">
              Auto-sliding active
            </span>
          </div>
        </div>
      </section>
      </AnimatedSection>

      {/* Testimonials Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading 
          title="What Our Clients Say" 
          subtitle="Testimonials" 
        />

        {testimonials.length > 0 && (
          <div 
            className="max-w-xl mx-auto bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 backdrop-blur-md rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none p-6 sm:p-8 border border-[#30E1CE]/30 shadow-lg relative overflow-hidden transition-all text-left"
            onMouseEnter={() => setIsTestimonialPaused(true)}
            onMouseLeave={() => setIsTestimonialPaused(false)}
            onTouchStart={onTestimonialTouchStart}
            onTouchMove={onTestimonialTouchMove}
            onTouchEnd={onTestimonialTouchEnd}
          >
            {/* Header with Counter & Navigation */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-[#1876C7] px-2.5 py-1 rounded-full bg-[#1876C7]/15">
                  {String(currentTestimonialIndex + 1).padStart(2, '0')} / {String(testimonials.length).padStart(2, '0')}
                </span>
                <span className="w-2 h-2 rounded-full bg-[#30E1CE] animate-pulse"></span>
              </div>
              
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setCurrentTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)}
                  className="p-1.5 rounded-full hover:bg-white/80 text-gray-700 transition-colors border border-gray-200 cursor-pointer shadow-xs"
                  aria-label="Previous Testimonial"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setCurrentTestimonialIndex((prev) => (prev + 1) % testimonials.length)}
                  className="p-1.5 rounded-full hover:bg-white/80 text-gray-700 transition-colors border border-gray-200 cursor-pointer shadow-xs"
                  aria-label="Next Testimonial"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Testimonial Content & Author */}
            <div className="space-y-4 min-h-[140px] flex flex-col justify-between">
              <p className="text-sm sm:text-base text-[#17202A] italic leading-relaxed">
                "{testimonials[currentTestimonialIndex].quote}"
              </p>

              <div className="flex items-center gap-3 pt-2">
                <div className="w-10 h-10 rounded-full bg-white border border-[#30E1CE]/40 flex items-center justify-center overflow-hidden shrink-0 text-gray-400 shadow-xs">
                  <User className="w-5 h-5 text-gray-500" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-bold text-[#17202A]">
                      {testimonials[currentTestimonialIndex].client_name}
                    </p>
                    <div className="flex items-center text-amber-500 text-xs gap-0.5 tracking-wider">
                      <span>★★★★★</span>
                    </div>
                  </div>
                  {testimonials[currentTestimonialIndex].role && (
                    <p className="text-xs text-[#66727D]">
                      {testimonials[currentTestimonialIndex].role}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Slider Indicators directly below description inside card */}
            <div className="flex items-center justify-between pt-5 mt-5 border-t border-[#E2E8EA]">
              <div className="flex items-center gap-1.5">
                {testimonials.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentTestimonialIndex(idx)}
                    className={`h-1.5 rounded-full transition-all cursor-pointer ${
                      idx === currentTestimonialIndex ? 'w-6 bg-[#1876C7]' : 'w-1.5 bg-gray-300 hover:bg-gray-400'
                    }`}
                    aria-label={`Go to testimonial ${idx + 1}`}
                  />
                ))}
              </div>
              <span className="text-[11px] font-semibold text-gray-500">
                Auto-sliding active
              </span>
            </div>
          </div>
        )}
      </section>
      </AnimatedSection>

      {/* Online Visibility Section */}
      <AnimatedSection>
        <section className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 backdrop-blur-md rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none max-w-7xl mx-auto px-6 lg:px-12 pt-2 pb-10 sm:pb-14 border border-[#30E1CE]/30 shadow-lg">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center text-left">
          <div className="lg:col-span-8 space-y-3">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#17202A]">Built to Be Found Online</h2>
            <p className="text-sm sm:text-base text-[#66727D] leading-relaxed">
              Website structure, content, performance and search-friendly foundations are incorporated into development from day one so your customers can discover you easily.
            </p>
          </div>
          <div className="lg:col-span-4 flex justify-lg-end">
            <Button
              variant="primary"
              onClick={() => navigate('/contact')}
              className="rounded-tl-xl rounded-br-xl rounded-tr-none rounded-bl-none"
            >
              <span>Start Your Project</span>
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </section>
      </AnimatedSection>

      {/* FAQ Preview Section */}
      <AnimatedSection>
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading 
          title="Frequently Asked Questions" 
          subtitle="FAQ" 
        />

        <div className="space-y-4">
          {faqs.map((faq) => {
            const isOpen = openFaqId === faq.id;
            return (
              <div 
                key={faq.id} 
                className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 backdrop-blur-md rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none border border-[#30E1CE]/30 shadow-lg overflow-hidden transition-all text-left"
              >
                <button
                  onClick={() => setOpenFaqId(isOpen ? null : faq.id)}
                  className="w-full p-6 text-left flex items-center justify-between gap-4 focus:outline-none cursor-pointer"
                >
                  <span className="text-base font-bold text-[#17202A]">{faq.question}</span>
                  <span className="w-8 h-8 rounded-full bg-[#1876C7]/15 text-[#1876C7] flex items-center justify-center shrink-0 transition-transform">
                    {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  </span>
                </button>
                {isOpen && (
                  <div className="px-6 pb-6 pt-0 text-sm text-[#66727D] leading-relaxed border-t border-[#E2E8EA]/60 mt-2">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="text-center mt-8">
          <Button
            variant="primary"
            onClick={() => navigate('/faq')}
          >
            <span>View All FAQs</span>
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </section>
      </AnimatedSection>

      {/* Final CTA Section */}
      <AnimatedSection>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 text-[#17202A] rounded-tl-3xl rounded-br-3xl rounded-tr-none rounded-bl-none pt-4 pb-10 sm:pb-14 px-8 sm:px-16 text-center space-y-3 shadow-2xl relative overflow-hidden border border-[#30E1CE]/30">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#30E1CE]/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <AnimatedHeading
            text="Ready to Build Your Website?"
            as="h2"
            className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#17202A]"
          />
          <AnimatedDescription
            text="Let’s discuss your business, goals, and project needs. Get started with Janah Studio today."
            className="text-sm sm:text-base text-[#66727D] max-w-xl mx-auto leading-relaxed"
            delay={0.15}
          />

          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <Button
              variant="primary"
              onClick={() => navigate('/contact')}
              className="px-6 shrink-0"
            >
              <span>Start Project</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>

            <Button
              variant="chat"
              onClick={() => window.open(whatsappUrl, '_blank')}
              className="px-6 shrink-0"
            >
              <MessageCircle className="w-4 h-4 text-white" />
              <span>Chat Us</span>
            </Button>
          </div>
        </div>
      </section>
      </AnimatedSection>

    </div>
  );
}
