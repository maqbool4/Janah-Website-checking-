import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  ShieldAlert, 
  LayoutDashboard, 
  Briefcase, 
  DollarSign, 
  FolderGit2, 
  HelpCircle, 
  Mail, 
  Settings, 
  LogOut, 
  Plus, 
  Edit3, 
  Check, 
  X, 
  Eye, 
  EyeOff, 
  ArrowUp, 
  ArrowDown, 
  Lock,
  User,
  CheckCircle2,
  Bell,
  Send,
  MessageCircle,
  ShoppingBag,
  Package,
  Trash2,
  ExternalLink,
  Tag,
  AlertTriangle,
  Search,
  Sparkles,
  Truck,
  CreditCard,
  FileSpreadsheet,
  Globe,
  Github,
  RotateCw
} from 'lucide-react';
import { dataStore } from '../lib/dataStore';
import { emailService, NotificationPreferences } from '../lib/emailService';
import { signInWithGoogleSheets, logoutGoogle } from '../lib/firebase';
import { 
  ServiceItem, 
  PricingPackage, 
  PortfolioProject, 
  FaqItem, 
  ContactSubmission, 
  SiteSettings,
  StoreProduct,
  StoreOrder,
  StoreCoupon,
  CareerApplication
} from '../lib/types';
import { Button } from '../components/ui/Button';

export default function Dashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('janah_admin_auth') === 'true';
  });
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const [generatingReplyId, setGeneratingReplyId] = useState<string | null>(null);
  const [draftReplies, setDraftReplies] = useState<Record<string, { content: string; type: 'email' | 'whatsapp' }>>({});

  const handleGenerateDraft = async (sub: ContactSubmission, type: 'email' | 'whatsapp') => {
    setGeneratingReplyId(`${sub.id}-${type}`);
    try {
      const response = await fetch('/api/generate-reply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: sub.name,
          business_name: sub.business_name,
          service: sub.service,
          project_description: sub.project_description,
          budget: sub.budget || '',
          type,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate reply draft');
      }

      const data = await response.json();
      setDraftReplies(prev => ({
        ...prev,
        [sub.id]: { content: data.draft, type }
      }));
      showNotification(`AI ${type === 'email' ? 'Email' : 'WhatsApp'} reply draft generated!`);
    } catch (err: any) {
      console.error(err);
      showNotification('Error generating reply. Please try again.');
    } finally {
      setGeneratingReplyId(null);
    }
  };

  const [activeTab, setActiveTab] = useState<'overview' | 'store-products' | 'store-orders' | 'services' | 'pricing' | 'portfolio' | 'faqs' | 'submissions' | 'careers' | 'notifications' | 'settings'>('overview');

  // Package Tier for Store Admin (allows experiencing Standard vs Premium tier capabilities)
  const [packageTier, setPackageTier] = useState<'standard' | 'premium'>('standard');

  const [services, setServices] = useState<ServiceItem[]>(() => dataStore.getServicesSync());
  const [pricing, setPricing] = useState<PricingPackage[]>(() => dataStore.getPricingSync());
  const [portfolio, setPortfolio] = useState<PortfolioProject[]>(() => dataStore.getPortfolioSync());
  const [faqs, setFaqs] = useState<FaqItem[]>(() => dataStore.getFaqsSync());
  const [submissions, setSubmissions] = useState<ContactSubmission[]>(() => dataStore.getSubmissionsSync());
  const [settings, setSettings] = useState<SiteSettings>(() => dataStore.getSettingsSync());

  // Careers & Google Sheets State
  const [applications, setApplications] = useState<CareerApplication[]>(() => dataStore.getApplicationsSync());
  const [sheetsConfig, setSheetsConfig] = useState<{
    isConnected: boolean;
    spreadsheetId: string;
    spreadsheetUrl: string;
    spreadsheetTitle?: string;
    userEmail?: string;
    totalSynced: number;
  }>({
    isConnected: false,
    spreadsheetId: '',
    spreadsheetUrl: '',
    totalSynced: 0
  });
  const [isConnectingSheets, setIsConnectingSheets] = useState(false);
  const [isSyncingPending, setIsSyncingPending] = useState(false);
  const [customSheetIdInput, setCustomSheetIdInput] = useState('');
  const [showSheetSetupGuide, setShowSheetSetupGuide] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState<CareerApplication | null>(null);

  // E-commerce Store State
  const [products, setProducts] = useState<StoreProduct[]>(() => dataStore.getProductsSync());
  const [orders, setOrders] = useState<StoreOrder[]>(() => dataStore.getOrdersSync());
  const [coupons, setCoupons] = useState<StoreCoupon[]>(() => dataStore.getCouponsSync());

  // Product Filters & Modal State
  const [productSearch, setProductSearch] = useState('');
  const [selectedProductCategory, setSelectedProductCategory] = useState<string>('All');
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [productForm, setProductForm] = useState({
    name: '',
    category: 'Electronics',
    price: 0,
    original_price: 0,
    description: '',
    image_url: '',
    stock_quantity: 20,
    sku: '',
    in_stock: true
  });

  // Coupon Form State
  const [isCouponModalOpen, setIsCouponModalOpen] = useState(false);
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponDiscount, setNewCouponDiscount] = useState(10);
  const [newCouponMinOrder, setNewCouponMinOrder] = useState(1500);

  // Order Filters
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('All');

  const [notifPrefs, setNotifPrefs] = useState<NotificationPreferences>(emailService.getPreferences());
  const [notifLogs, setNotifLogs] = useState(emailService.getNotificationLogs());
  const [notification, setNotification] = useState('');

  useEffect(() => {
    if (isAuthenticated) {
      loadData();

      const handleUpdate = () => {
        loadData();
      };

      window.addEventListener('janah_store_updated', handleUpdate);
      window.addEventListener('storage', handleUpdate);

      return () => {
        window.removeEventListener('janah_store_updated', handleUpdate);
        window.removeEventListener('storage', handleUpdate);
      };
    }
  }, [isAuthenticated]);

  const loadData = async () => {
    const s = await dataStore.getServices();
    const p = await dataStore.getPricing();
    const port = await dataStore.getPortfolio();
    const f = await dataStore.getFaqs();
    const sub = await dataStore.getSubmissions();
    const set = await dataStore.getSettings();
    const prods = await dataStore.getProducts();
    const ords = await dataStore.getOrders();
    const coups = await dataStore.getCoupons();
    const apps = await dataStore.getApplications();

    setServices(s);
    setPricing(p);
    setPortfolio(port);
    setFaqs(f);
    setSubmissions(sub);
    setSettings(set);
    setProducts(prods);
    setOrders(ords);
    setCoupons(coups);
    setApplications(apps);
    setNotifPrefs(emailService.getPreferences());
    setNotifLogs(emailService.getNotificationLogs());

    try {
      const sheetsRes = await fetch('/api/google-sheets/config');
      if (sheetsRes.ok) {
        const sData = await sheetsRes.json();
        setSheetsConfig(sData);
      }
    } catch (e) {
      console.warn('Could not fetch sheets config', e);
    }
  };

  const handleConnectGoogleSheets = async (createNew: boolean = true) => {
    setIsConnectingSheets(true);
    try {
      const authResult = await signInWithGoogleSheets();
      // If user closed popup or cancelled, exit cleanly
      if (!authResult) {
        return;
      }
      if (!authResult.accessToken) {
        throw new Error('Google Sign-in failed to issue an access token.');
      }

      const res = await fetch('/api/admin/google-sheets/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accessToken: authResult.accessToken,
          userEmail: authResult.user.email,
          spreadsheetId: customSheetIdInput || undefined,
          createNew
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to connect Google Sheets');
      }

      setSheetsConfig({
        isConnected: true,
        spreadsheetId: data.spreadsheetId,
        spreadsheetUrl: data.spreadsheetUrl,
        spreadsheetTitle: data.spreadsheetTitle,
        userEmail: authResult.user.email || 'Connected Account',
        totalSynced: sheetsConfig.totalSynced
      });

      showNotification('Google Sheets connected! All incoming applications will sync in real time.');
      setShowSheetSetupGuide(false);
    } catch (err: any) {
      if (err?.code === 'auth/popup-closed-by-user' || err?.code === 'auth/cancelled-popup-request') {
        return;
      }
      console.warn('Google Sheets connection error:', err);
      showNotification(err.message || 'Error connecting Google Sheets');
    } finally {
      setIsConnectingSheets(false);
    }
  };

  const handleDisconnectGoogleSheets = async () => {
    if (!window.confirm('Are you sure you want to disconnect Google Sheets?')) return;
    try {
      await fetch('/api/admin/google-sheets/disconnect', { method: 'POST' });
      await logoutGoogle();
      setSheetsConfig({
        isConnected: false,
        spreadsheetId: '',
        spreadsheetUrl: '',
        totalSynced: 0
      });
      showNotification('Google Sheets disconnected.');
    } catch (err) {
      console.error(err);
      showNotification('Error disconnecting Google Sheets');
    }
  };

  const handleSyncPendingApplications = async () => {
    setIsSyncingPending(true);
    try {
      const res = await fetch('/api/admin/google-sheets/sync-all', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Sync failed');
      showNotification(`Successfully synced ${data.syncedCount} application(s) to Google Sheets!`);
      await loadData();
    } catch (err: any) {
      console.error(err);
      showNotification(err.message || 'Failed to sync applications to Google Sheets');
    } finally {
      setIsSyncingPending(false);
    }
  };

  const handleUpdateApplicationStatus = async (id: string, status: CareerApplication['status']) => {
    try {
      await dataStore.updateApplicationStatus(id, status);
      const updated = await dataStore.getApplications();
      setApplications(updated);
      showNotification(`Application status updated to ${status}.`);
    } catch (err) {
      console.error(err);
    }
  };

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(''), 3500);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      email.trim().toLowerCase() === 'janahstudio.ai@gmail.com' &&
      password === 'Janah@128'
    ) {
      setIsAuthenticated(true);
      localStorage.setItem('janah_admin_auth', 'true');
      setLoginError('');
    } else {
      setLoginError('Invalid administrator email address or password.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('janah_admin_auth');
  };

  // Product Actions
  const handleOpenAddProduct = () => {
    setEditingProductId(null);
    setProductForm({
      name: '',
      category: 'Electronics',
      price: 2999,
      original_price: 3999,
      description: '',
      image_url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
      stock_quantity: 25,
      sku: `SKU-${Math.floor(100 + Math.random() * 900)}`,
      in_stock: true
    });
    setIsProductModalOpen(true);
  };

  const handleOpenEditProduct = (prod: StoreProduct) => {
    setEditingProductId(prod.id);
    setProductForm({
      name: prod.name,
      category: prod.category,
      price: prod.price,
      original_price: prod.original_price || 0,
      description: prod.description,
      image_url: prod.image_url,
      stock_quantity: prod.stock_quantity,
      sku: prod.sku || '',
      in_stock: prod.in_stock
    });
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.name.trim() || productForm.price <= 0) {
      showNotification('Please provide a valid product name and price.');
      return;
    }

    try {
      const stockStatus = productForm.stock_quantity <= 0 
        ? 'Out of Stock' 
        : productForm.stock_quantity < 10 
          ? 'Low Stock' 
          : 'In Stock';

      if (editingProductId) {
        await dataStore.updateProduct(editingProductId, {
          ...productForm,
          in_stock: productForm.stock_quantity > 0 && productForm.in_stock,
          stock_status: stockStatus
        });
        showNotification('Product updated successfully! Live store updated.');
      } else {
        await dataStore.addProduct({
          ...productForm,
          in_stock: productForm.stock_quantity > 0 && productForm.in_stock,
          stock_status: stockStatus,
          is_active: true
        });
        showNotification('New product published! Live store updated.');
      }
      setIsProductModalOpen(false);
      const updated = await dataStore.getProducts();
      setProducts(updated);
    } catch (err) {
      console.error(err);
      showNotification('Failed to save product.');
    }
  };

  const handleDeleteProduct = async (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}"?`)) {
      await dataStore.deleteProduct(id);
      const updated = await dataStore.getProducts();
      setProducts(updated);
      showNotification('Product deleted from store.');
    }
  };

  const handleToggleProductStatus = async (prod: StoreProduct) => {
    const updatedInStock = !prod.in_stock;
    await dataStore.updateProduct(prod.id, {
      in_stock: updatedInStock,
      stock_status: updatedInStock ? 'In Stock' : 'Out of Stock'
    });
    const updated = await dataStore.getProducts();
    setProducts(updated);
    showNotification(`Product "${prod.name}" marked as ${updatedInStock ? 'In Stock' : 'Out of Stock'}.`);
  };

  // Order Actions
  const handleUpdateOrderStatus = async (orderId: string, status: StoreOrder['status']) => {
    await dataStore.updateOrderStatus(orderId, status);
    const updated = await dataStore.getOrders();
    setOrders(updated);
    showNotification(`Order status updated to ${status}.`);
  };

  const handleUpdateOrderTracking = async (orderId: string, trackingNumber: string, courier: string) => {
    await dataStore.updateOrderStatus(orderId, 'Shipped', trackingNumber, courier);
    const updated = await dataStore.getOrders();
    setOrders(updated);
    showNotification(`Courier tracking updated for order.`);
  };

  // Coupon Actions
  const handleAddCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;
    await dataStore.addCoupon({
      code: newCouponCode.trim().toUpperCase(),
      discount_percentage: Number(newCouponDiscount),
      is_active: true,
      min_order_amount: Number(newCouponMinOrder)
    });
    const updated = await dataStore.getCoupons();
    setCoupons(updated);
    setNewCouponCode('');
    setIsCouponModalOpen(false);
    showNotification('Discount coupon created successfully.');
  };

  const handleDeleteCoupon = async (id: string) => {
    await dataStore.deleteCoupon(id);
    const updated = await dataStore.getCoupons();
    setCoupons(updated);
    showNotification('Coupon deleted.');
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 bg-[#F8FAFA]">
        <div className="max-w-md w-full bg-white rounded-3xl p-8 sm:p-12 border border-[#E2E8EA] shadow-xl space-y-6">
          <div className="w-14 h-14 rounded-2xl bg-[#1876C7]/10 text-[#1876C7] flex items-center justify-center mx-auto">
            <Lock className="w-7 h-7" />
          </div>

          <div className="text-center space-y-2">
            <h1 className="text-2xl font-bold text-[#17202A]">Admin Dashboard</h1>
            <p className="text-xs text-[#66727D]">Enter your administrator email address and secure password to sign in.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            {loginError && (
              <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs font-semibold">
                {loginError}
              </div>
            )}

            <div className="space-y-2">
              <label className="text-xs font-bold text-[#17202A]">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="janahstudio.ai@gmail.com"
                className="w-full px-4 py-3 rounded-xl border border-[#E2E8EA] text-sm text-[#17202A] focus:outline-none focus:border-[#1876C7]"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-[#17202A]">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 rounded-xl border border-[#E2E8EA] text-sm text-[#17202A] focus:outline-none focus:border-[#1876C7]"
              />
            </div>

            <Button variant="navy-blue" className="w-full py-3 text-sm font-bold">
              Sign In to Dashboard
            </Button>
          </form>
        </div>
      </div>
    );
  }

  const productCategories = ['All', ...Array.from(new Set(products.map(p => p.category)))];
  const filteredDashboardProducts = products.filter(p => {
    const matchesCat = selectedProductCategory === 'All' || p.category === selectedProductCategory;
    const matchesSearch = p.name.toLowerCase().includes(productSearch.toLowerCase()) || 
                          (p.sku && p.sku.toLowerCase().includes(productSearch.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  const filteredOrders = orders.filter(o => {
    const matchesStatus = orderStatusFilter === 'All' || o.status === orderStatusFilter;
    const matchesSearch = o.order_number.toLowerCase().includes(orderSearch.toLowerCase()) || 
                          o.customer_name.toLowerCase().includes(orderSearch.toLowerCase()) ||
                          o.customer_phone.includes(orderSearch);
    return matchesStatus && matchesSearch;
  });

  const pendingOrdersCount = orders.filter(o => o.status === 'Pending').length;

  return (
    <div className="min-h-screen bg-[#F8FAFA] flex flex-col lg:flex-row">
      
      {/* Sidebar */}
      <aside className="w-full lg:w-72 bg-white border-r border-[#E2E8EA] p-6 flex flex-col justify-between shrink-0">
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#30E1CE] to-[#1876C7] flex items-center justify-center text-white font-bold">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#17202A]">Janah CMS</h2>
              <span className="text-xs text-[#66727D]">Admin Control Panel</span>
            </div>
          </div>

          {/* Package Tier Indicator */}
          <div className="p-3 rounded-xl bg-gradient-to-br from-[#30E1CE]/10 to-blue-50 border border-[#1876C7]/20 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-[#66727D] uppercase tracking-wider">Package Mode</span>
              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                packageTier === 'premium' ? 'bg-[#1876C7] text-white' : 'bg-emerald-600 text-white'
              }`}>
                {packageTier === 'premium' ? 'PREMIUM (PKR 45K)' : 'STANDARD (PKR 25K)'}
              </span>
            </div>
            <div className="flex gap-1.5 pt-1">
              <button 
                onClick={() => setPackageTier('standard')}
                className={`flex-1 py-1 text-[10px] font-bold rounded-lg transition-colors ${
                  packageTier === 'standard' ? 'bg-[#1876C7] text-white' : 'bg-white border text-gray-600'
                }`}
              >
                Standard
              </button>
              <button 
                onClick={() => setPackageTier('premium')}
                className={`flex-1 py-1 text-[10px] font-bold rounded-lg transition-colors ${
                  packageTier === 'premium' ? 'bg-[#1876C7] text-white' : 'bg-white border text-gray-600'
                }`}
              >
                Premium
              </button>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            {[
              { id: 'overview', label: 'Overview', icon: LayoutDashboard },
              { id: 'store-products', label: 'Store Products', icon: ShoppingBag, badge: products.length },
              { id: 'store-orders', label: 'Store Orders', icon: Package, badge: pendingOrdersCount },
              { id: 'services', label: 'Services', icon: Briefcase },
              { id: 'pricing', label: 'Pricing Packages', icon: DollarSign },
              { id: 'portfolio', label: 'Portfolio', icon: FolderGit2 },
              { id: 'faqs', label: 'FAQs', icon: HelpCircle },
              { id: 'submissions', label: 'Contact Submissions', icon: Mail, badge: submissions.filter(s => s.status === 'New').length },
              { id: 'careers', label: 'Careers & Sheets', icon: FileSpreadsheet, badge: applications.length },
              { id: 'notifications', label: 'Email Notifications', icon: Bell },
              { id: 'settings', label: 'Site Settings', icon: Settings },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive ? 'bg-[#1876C7] text-white shadow-md' : 'text-[#66727D] hover:bg-[#F8FAFA] hover:text-[#17202A]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </div>
                  {tab.badge ? (
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-white text-[#1876C7]' : tab.id === 'store-orders' ? 'bg-amber-500 text-white' : 'bg-[#1876C7]/15 text-[#1876C7]'
                    }`}>
                      {tab.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </nav>

          {/* Live Store Quick Link */}
          <div className="pt-2">
            <Link 
              to="/shop" 
              className="flex items-center justify-between p-3 rounded-xl bg-sky-50 border border-sky-200 text-xs font-bold text-[#1876C7] hover:bg-sky-100 transition-colors"
            >
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4" />
                <span>View Live Store</span>
              </div>
              <ExternalLink className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        <div className="pt-6 border-t border-[#E2E8EA]">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-50 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-grow p-6 lg:p-10 space-y-8 overflow-y-auto">
        
        {notification && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{notification}</span>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB: OVERVIEW */}
        {/* ========================================================= */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-[#17202A]">Dashboard Overview</h1>
                <p className="text-xs text-[#66727D]">Manage and monitor your Janah Studio website content, store inventory, and customer orders.</p>
              </div>

              <div className="flex items-center gap-2">
                <Link to="/shop">
                  <Button variant="outline" className="text-xs h-[38px] flex items-center gap-1.5 bg-white">
                    <span>Live Store Demo</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </Button>
                </Link>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              <div className="bg-white p-5 rounded-2xl border border-[#E2E8EA] shadow-sm space-y-2">
                <div className="flex items-center justify-between text-[#66727D]">
                  <span className="text-xs font-bold uppercase">Store Products</span>
                  <ShoppingBag className="w-4 h-4 text-[#1876C7]" />
                </div>
                <p className="text-3xl font-extrabold text-[#17202A]">{products.length}</p>
                <p className="text-xs text-[#66727D]">{products.filter(p => p.in_stock).length} In Stock • Subject to Hosting/DB limits</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-[#E2E8EA] shadow-sm space-y-2">
                <div className="flex items-center justify-between text-[#66727D]">
                  <span className="text-xs font-bold uppercase">Customer Orders</span>
                  <Package className="w-4 h-4 text-emerald-600" />
                </div>
                <p className="text-3xl font-extrabold text-emerald-600">{orders.length}</p>
                <p className="text-xs text-[#66727D]">{pendingOrdersCount} Pending fulfillment</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-[#E2E8EA] shadow-sm space-y-2">
                <div className="flex items-center justify-between text-[#66727D]">
                  <span className="text-xs font-bold uppercase">New Enquiries</span>
                  <Mail className="w-4 h-4 text-[#1876C7]" />
                </div>
                <p className="text-3xl font-extrabold text-[#1876C7]">{submissions.filter(s => s.status === 'New').length}</p>
                <p className="text-xs text-[#66727D]">Contact submissions awaiting reply</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-[#E2E8EA] shadow-sm space-y-2">
                <div className="flex items-center justify-between text-[#66727D]">
                  <span className="text-xs font-bold uppercase">Store Revenue (PKR)</span>
                  <DollarSign className="w-4 h-4 text-amber-600" />
                </div>
                <p className="text-2xl font-extrabold text-[#17202A]">
                  PKR {orders.reduce((sum, o) => sum + o.total_amount, 0).toLocaleString()}
                </p>
                <p className="text-xs text-[#66727D]">From completed and pending orders</p>
              </div>
            </div>

            {/* Quick Actions Card */}
            <div className="bg-gradient-to-br from-[#30E1CE]/15 via-blue-50/70 to-purple-50/70 p-6 rounded-2xl border border-[#30E1CE]/30 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#1876C7]" />
                  <h3 className="text-sm font-bold text-[#17202A]">Working E-commerce Architecture</h3>
                </div>
                <p className="text-xs text-[#66727D] leading-relaxed max-w-2xl">
                  Add, edit, or delete products and manage customer orders right here. Both <strong>Standard (PKR 25,000)</strong> and <strong>Premium (PKR 45,000)</strong> packages provide a working dashboard to add and manage products, subject to selected hosting and database limits.
                </p>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => { setActiveTab('store-products'); handleOpenAddProduct(); }}
                  className="px-4 py-2.5 rounded-xl bg-[#1876C7] text-white text-xs font-bold flex items-center gap-1.5 shadow-sm hover:bg-[#1565a7]"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Product</span>
                </button>
                <button 
                  onClick={() => setActiveTab('store-orders')}
                  className="px-4 py-2.5 rounded-xl bg-white border border-[#E2E8EA] text-xs font-bold text-[#17202A] hover:bg-gray-50"
                >
                  <span>View Orders</span>
                </button>
              </div>
            </div>

            {/* Recent Orders Overview */}
            <div className="bg-white rounded-2xl p-6 border border-[#E2E8EA] space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-[#17202A]">Recent Store Orders</h3>
                <button onClick={() => setActiveTab('store-orders')} className="text-xs font-bold text-[#1876C7] hover:underline">
                  View All Orders →
                </button>
              </div>
              <div className="space-y-3">
                {orders.slice(0, 4).map(ord => (
                  <div key={ord.id} className="p-4 rounded-xl border border-[#E2E8EA] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[#1876C7]">{ord.order_number}</span>
                        <span>•</span>
                        <span className="font-bold text-[#17202A]">{ord.customer_name}</span>
                        <span className="text-gray-400">({ord.city})</span>
                      </div>
                      <p className="text-[#66727D] mt-0.5">
                        {ord.items.map(i => `${i.product_name} (x${i.quantity})`).join(', ')}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-extrabold text-[#17202A]">PKR {ord.total_amount.toLocaleString()}</span>
                      <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                        ord.status === 'Delivered' ? 'bg-emerald-100 text-emerald-800' :
                        ord.status === 'Shipped' ? 'bg-purple-100 text-purple-800' :
                        ord.status === 'Processing' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {ord.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB: STORE PRODUCTS (Add, Edit, Stock, Categories, Prices) */}
        {/* ========================================================= */}
        {activeTab === 'store-products' && (
          <div className="space-y-6">
            
            {/* Header with Mode Banner */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-bold text-[#17202A]">E-commerce Products</h1>
                  <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                    packageTier === 'premium' ? 'bg-purple-50 text-purple-700 border-purple-200' : 'bg-blue-50 text-blue-700 border-blue-200'
                  }`}>
                    {packageTier === 'premium' ? 'Premium Package Mode (100 Initial Products + Dashboard Management)' : 'Standard Package Mode (50 Initial Products + Dashboard Management)'}
                  </span>
                </div>
                <p className="text-xs text-[#66727D] mt-1">
                  Add, edit, manage product images, prices, descriptions, categories, and inventory. All modifications update the live store immediately.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <Link to="/shop" target="_blank">
                  <Button variant="outline" className="text-xs h-[38px] flex items-center gap-1.5 bg-white">
                    <span>Preview Store</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </Button>
                </Link>
                <Button 
                  variant="primary" 
                  onClick={handleOpenAddProduct} 
                  className="text-xs h-[38px] flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Product</span>
                </Button>
              </div>
            </div>

            {/* Inventory Status & Tier Info */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-xl border border-[#E2E8EA] space-y-1">
                <span className="text-[11px] text-[#66727D] font-bold uppercase">Product Count Capacity</span>
                <p className="text-lg font-bold text-[#17202A]">
                  {products.length} Products <span className="text-xs font-normal text-[#1876C7]">(Add via Dashboard)</span>
                </p>
                <p className="text-[10px] text-gray-500">
                  Initial added by Janah: {packageTier === 'premium' ? '100' : '50'} products • Capacity subject to hosting/DB limits
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#E2E8EA] space-y-1">
                <span className="text-[11px] text-[#66727D] font-bold uppercase">Stock Management</span>
                <p className="text-lg font-bold text-[#1876C7]">
                  {packageTier === 'premium' ? 'Enhanced Stock Tracking' : 'Basic Stock Tracking'}
                </p>
                <p className="text-[10px] text-gray-500">
                  {packageTier === 'premium' ? 'Low stock threshold & inventory alerts active' : 'Quantity & In/Out-of-Stock controls'}
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#E2E8EA] space-y-1">
                <span className="text-[11px] text-[#66727D] font-bold uppercase">Coupons & Payments</span>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#17202A]">
                    {packageTier === 'premium' ? `${coupons.length} Active Coupons` : 'COD & Bank Transfer Only'}
                  </span>
                  {packageTier === 'premium' ? (
                    <button onClick={() => setIsCouponModalOpen(true)} className="text-[11px] text-[#1876C7] font-bold hover:underline">
                      + Manage Coupons
                    </button>
                  ) : (
                    <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md font-bold">
                      Coupons locked to Premium
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-gray-500">
                  {packageTier === 'premium' ? 'Online Gateway & Discount Vouchers enabled' : 'Online Gateway & Coupons require Premium tier'}
                </p>
              </div>
            </div>

            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto">
                {productCategories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedProductCategory(cat)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                      selectedProductCategory === cat ? 'bg-[#1876C7] text-white' : 'bg-white border border-[#E2E8EA] text-gray-600'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input 
                  type="text"
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  placeholder="Search products or SKU..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-[#E2E8EA] bg-white text-[#17202A] focus:outline-none focus:border-[#1876C7]"
                />
              </div>
            </div>

            {/* Products Table */}
            <div className="bg-white rounded-2xl border border-[#E2E8EA] overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-[#E2E8EA] bg-[#F8FAFA] text-[#66727D] font-bold uppercase text-[10px] tracking-wider">
                      <th className="py-3 px-4">Product</th>
                      <th className="py-3 px-3">Category</th>
                      <th className="py-3 px-3">Price (PKR)</th>
                      <th className="py-3 px-3">Stock Units</th>
                      <th className="py-3 px-3">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E2E8EA]">
                    {filteredDashboardProducts.map((prod) => (
                      <tr key={prod.id} className="hover:bg-gray-50/50 transition-colors">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <img 
                              src={prod.image_url} 
                              alt={prod.name} 
                              className="w-12 h-12 rounded-lg object-cover bg-gray-100 border border-gray-200 shrink-0" 
                            />
                            <div>
                              <span className="font-bold text-[#17202A] block text-xs">{prod.name}</span>
                              <span className="text-[10px] text-[#66727D] font-mono">{prod.sku || 'NO-SKU'}</span>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-[#17202A] font-medium">{prod.category}</td>
                        <td className="py-3 px-3 font-bold text-[#1876C7]">
                          PKR {prod.price.toLocaleString()}
                          {prod.original_price && prod.original_price > prod.price && (
                            <span className="text-[10px] text-gray-400 line-through block">
                              PKR {prod.original_price.toLocaleString()}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3">
                          <span className={`font-bold ${prod.stock_quantity < 10 ? 'text-amber-600' : 'text-gray-700'}`}>
                            {prod.stock_quantity} units
                          </span>
                          {packageTier === 'premium' && prod.stock_quantity < 10 && (
                            <span className="text-[9px] text-amber-600 block flex items-center gap-0.5">
                              <AlertTriangle className="w-2.5 h-2.5 inline" /> Restock Alert
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3">
                          <button
                            onClick={() => handleToggleProductStatus(prod)}
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold border transition-colors ${
                              prod.in_stock && prod.stock_quantity > 0
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                : 'bg-red-50 text-red-700 border-red-200 hover:bg-red-100'
                            }`}
                          >
                            {prod.in_stock && prod.stock_quantity > 0 ? '✓ In Stock' : '✗ Out of Stock'}
                          </button>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleOpenEditProduct(prod)}
                              className="p-1.5 rounded-lg border border-gray-200 hover:bg-sky-50 hover:text-[#1876C7] text-gray-600"
                              title="Edit Product"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(prod.id, prod.name)}
                              className="p-1.5 rounded-lg border border-gray-200 hover:bg-red-50 hover:text-red-600 text-gray-600"
                              title="Delete Product"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Add / Edit Product Modal */}
            {isProductModalOpen && (
              <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 relative shadow-2xl border border-[#E2E8EA] space-y-5 max-h-[90vh] overflow-y-auto">
                  <div className="flex items-center justify-between border-b pb-3">
                    <h3 className="text-base font-bold text-[#17202A]">
                      {editingProductId ? 'Edit Store Product' : 'Add New Store Product'}
                    </h3>
                    <button onClick={() => setIsProductModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
                    <div className="space-y-1">
                      <label className="font-bold text-[#17202A]">Product Name *</label>
                      <input 
                        type="text"
                        required
                        value={productForm.name}
                        onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                        placeholder="e.g. Wireless Smart Headset"
                        className="w-full px-3 py-2 rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="font-bold text-[#17202A]">Category *</label>
                        <select
                          value={productForm.category}
                          onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
                          className="w-full px-3 py-2 rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                        >
                          <option value="Electronics">Electronics</option>
                          <option value="Fashion">Fashion</option>
                          <option value="Accessories">Accessories</option>
                          <option value="Home & Living">Home & Living</option>
                          <option value="Health & Beauty">Health & Beauty</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-[#17202A]">SKU Code</label>
                        <input 
                          type="text"
                          value={productForm.sku}
                          onChange={(e) => setProductForm({ ...productForm, sku: e.target.value })}
                          placeholder="e.g. EL-HP-109"
                          className="w-full px-3 py-2 rounded-xl border border-[#E2E8EA] font-mono focus:outline-none focus:border-[#1876C7]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="font-bold text-[#17202A]">Price (PKR) *</label>
                        <input 
                          type="number"
                          required
                          min={1}
                          value={productForm.price}
                          onChange={(e) => setProductForm({ ...productForm, price: Number(e.target.value) })}
                          className="w-full px-3 py-2 rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-[#17202A]">Original Price (PKR, optional)</label>
                        <input 
                          type="number"
                          value={productForm.original_price}
                          onChange={(e) => setProductForm({ ...productForm, original_price: Number(e.target.value) })}
                          className="w-full px-3 py-2 rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="font-bold text-[#17202A]">Stock Quantity *</label>
                        <input 
                          type="number"
                          required
                          min={0}
                          value={productForm.stock_quantity}
                          onChange={(e) => setProductForm({ ...productForm, stock_quantity: Number(e.target.value) })}
                          className="w-full px-3 py-2 rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="font-bold text-[#17202A]">Availability Toggle</label>
                        <label className="flex items-center gap-2 mt-2 cursor-pointer">
                          <input 
                            type="checkbox"
                            checked={productForm.in_stock}
                            onChange={(e) => setProductForm({ ...productForm, in_stock: e.target.checked })}
                            className="rounded text-[#1876C7]"
                          />
                          <span className="font-semibold text-gray-700">Available for Sale</span>
                        </label>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="font-bold text-[#17202A]">Product Image URL *</label>
                      <input 
                        type="url"
                        required
                        value={productForm.image_url}
                        onChange={(e) => setProductForm({ ...productForm, image_url: e.target.value })}
                        placeholder="https://images.unsplash.com/..."
                        className="w-full px-3 py-2 rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                      />
                      {productForm.image_url && (
                        <div className="mt-2 flex items-center gap-3 p-2 rounded-xl bg-gray-50 border">
                          <img src={productForm.image_url} alt="Preview" className="w-10 h-10 object-cover rounded-lg" />
                          <span className="text-[10px] text-gray-500">Live Image Preview Verified</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-1">
                      <label className="font-bold text-[#17202A]">Product Description *</label>
                      <textarea 
                        required
                        rows={3}
                        value={productForm.description}
                        onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                        placeholder="Detailed specification, materials, features..."
                        className="w-full px-3 py-2 rounded-xl border border-[#E2E8EA] focus:outline-none focus:border-[#1876C7]"
                      />
                    </div>

                    <div className="pt-2 flex justify-end gap-2 border-t">
                      <button 
                        type="button" 
                        onClick={() => setIsProductModalOpen(false)}
                        className="px-4 py-2 rounded-xl border border-[#E2E8EA] font-bold text-gray-600 hover:bg-gray-100"
                      >
                        Cancel
                      </button>
                      <button 
                        type="submit"
                        className="px-6 py-2 rounded-xl bg-[#1876C7] text-white font-bold hover:bg-[#1565a7] shadow-sm"
                      >
                        {editingProductId ? 'Save Product Updates' : 'Publish Product to Live Store'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* Coupons Management Modal (Premium only) */}
            {isCouponModalOpen && (
              <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-md w-full p-6 relative shadow-2xl border border-[#E2E8EA] space-y-4">
                  <div className="flex items-center justify-between border-b pb-3">
                    <div className="flex items-center gap-2">
                      <Tag className="w-4 h-4 text-[#1876C7]" />
                      <h3 className="text-sm font-bold text-[#17202A]">Manage Discount Coupons (Premium)</h3>
                    </div>
                    <button onClick={() => setIsCouponModalOpen(false)} className="text-gray-400">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Existing Coupons List */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-bold text-gray-500 uppercase">Active Promo Codes</span>
                    {coupons.map(c => (
                      <div key={c.id} className="flex items-center justify-between p-2.5 rounded-xl border bg-gray-50 text-xs">
                        <div>
                          <span className="font-mono font-bold text-[#1876C7]">{c.code}</span>
                          <span className="text-gray-600 ml-2">({c.discount_percentage}% OFF)</span>
                          {c.min_order_amount && <span className="text-[10px] text-gray-400 block">Min PKR {c.min_order_amount}</span>}
                        </div>
                        <button onClick={() => handleDeleteCoupon(c.id)} className="text-red-600 text-[10px] font-bold hover:underline">
                          Delete
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Add New Coupon Form */}
                  <form onSubmit={handleAddCoupon} className="space-y-3 pt-3 border-t text-xs">
                    <span className="font-bold text-[#17202A] block">Add New Coupon</span>
                    <input 
                      type="text" 
                      required
                      placeholder="Coupon Code (e.g. FLASH25)"
                      value={newCouponCode}
                      onChange={(e) => setNewCouponCode(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-xl border uppercase font-mono"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <input 
                        type="number" 
                        required
                        min={1}
                        max={90}
                        placeholder="Discount %"
                        value={newCouponDiscount}
                        onChange={(e) => setNewCouponDiscount(Number(e.target.value))}
                        className="w-full px-3 py-1.5 rounded-xl border"
                      />
                      <input 
                        type="number" 
                        min={0}
                        placeholder="Min Order PKR"
                        value={newCouponMinOrder}
                        onChange={(e) => setNewCouponMinOrder(Number(e.target.value))}
                        className="w-full px-3 py-1.5 rounded-xl border"
                      />
                    </div>
                    <button 
                      type="submit"
                      className="w-full py-2 rounded-xl bg-[#1876C7] text-white font-bold"
                    >
                      Create Coupon Code
                    </button>
                  </form>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ========================================================= */}
        {/* TAB: STORE ORDERS (View, Manage, Status, Courier Tracking) */}
        {/* ========================================================= */}
        {activeTab === 'store-orders' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-[#17202A]">Customer Orders</h1>
                <p className="text-xs text-[#66727D]">
                  Review and fulfill customer orders placed through the live store checkout. Protected behind admin access control.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#66727D]">Filter:</span>
                {['All', 'Pending', 'Processing', 'Shipped', 'Delivered'].map(st => (
                  <button
                    key={st}
                    onClick={() => setOrderStatusFilter(st)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      orderStatusFilter === st ? 'bg-[#1876C7] text-white' : 'bg-white border text-gray-600'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {/* Orders List */}
            {filteredOrders.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-[#E2E8EA] space-y-3">
                <Package className="w-12 h-12 text-gray-300 mx-auto" />
                <h3 className="text-sm font-bold text-[#17202A]">No orders found</h3>
                <p className="text-xs text-[#66727D]">Orders placed by customers on the live store (/shop) will appear here.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredOrders.map(order => (
                  <div key={order.id} className="bg-white rounded-2xl p-5 border border-[#E2E8EA] shadow-sm space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-100 pb-3">
                      <div className="flex items-center gap-2.5">
                        <span className="text-sm font-mono font-extrabold text-[#1876C7]">{order.order_number}</span>
                        <span className="text-gray-300">•</span>
                        <span className="text-xs text-gray-500">{new Date(order.created_at).toLocaleString()}</span>
                        <span className="text-gray-300">•</span>
                        <span className="text-xs font-bold text-[#17202A]">{order.payment_method}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-gray-500">Status:</span>
                        <select
                          value={order.status}
                          onChange={(e) => handleUpdateOrderStatus(order.id, e.target.value as any)}
                          className="px-2.5 py-1 text-xs font-bold rounded-lg border border-[#E2E8EA] bg-white text-[#17202A] focus:outline-none focus:border-[#1876C7]"
                        >
                          <option value="Pending">Pending</option>
                          <option value="Processing">Processing</option>
                          <option value="Shipped">Shipped</option>
                          <option value="Delivered">Delivered</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                      {/* Customer Info */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Customer Details</span>
                        <p className="font-bold text-[#17202A]">{order.customer_name}</p>
                        <p className="text-gray-600">{order.customer_phone}</p>
                        <p className="text-gray-600">{order.customer_email}</p>
                        <p className="text-gray-500 text-[11px] mt-1">{order.shipping_address}, {order.city}</p>
                      </div>

                      {/* Ordered Items */}
                      <div className="space-y-1.5 md:col-span-2">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Order Items</span>
                        <div className="space-y-2">
                          {order.items.map((it, idx) => (
                            <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-[#F8FAFA] border border-gray-100">
                              <div className="flex items-center gap-2">
                                {it.image_url && <img src={it.image_url} alt="" className="w-8 h-8 rounded object-cover" />}
                                <span className="font-semibold text-[#17202A]">{it.product_name}</span>
                                <span className="text-gray-500">x{it.quantity}</span>
                              </div>
                              <span className="font-bold text-[#1876C7]">PKR {(it.price * it.quantity).toLocaleString()}</span>
                            </div>
                          ))}
                        </div>

                        {/* Totals & Courier Details */}
                        <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-t border-gray-100">
                          <div>
                            {order.coupon_code && (
                              <span className="text-[11px] text-emerald-600 font-bold block">
                                Coupon Applied: {order.coupon_code} (-PKR {order.discount_amount})
                              </span>
                            )}
                            {order.tracking_number && (
                              <span className="text-[11px] text-purple-700 font-mono font-bold flex items-center gap-1">
                                <Truck className="w-3 h-3" /> {order.courier}: {order.tracking_number}
                              </span>
                            )}
                          </div>
                          <div className="text-right">
                            <span className="text-xs text-gray-500 mr-2">Grand Total:</span>
                            <span className="text-sm font-extrabold text-[#17202A]">PKR {order.total_amount.toLocaleString()}</span>
                          </div>
                        </div>

                        {/* Premium Courier Assignment Tool */}
                        {packageTier === 'premium' && (
                          <div className="mt-2 pt-2 border-t border-dashed border-gray-200 flex items-center gap-2 text-[11px]">
                            <span className="font-bold text-purple-700">Assign Courier (Premium):</span>
                            <input 
                              type="text" 
                              placeholder="e.g. TCS Express"
                              defaultValue={order.courier || 'TCS Express'}
                              id={`courier-${order.id}`}
                              className="px-2 py-1 rounded border text-[11px] w-28"
                            />
                            <input 
                              type="text" 
                              placeholder="Tracking #"
                              defaultValue={order.tracking_number || ''}
                              id={`track-${order.id}`}
                              className="px-2 py-1 rounded border text-[11px] w-32"
                            />
                            <button
                              onClick={() => {
                                const cInput = document.getElementById(`courier-${order.id}`) as HTMLInputElement;
                                const tInput = document.getElementById(`track-${order.id}`) as HTMLInputElement;
                                if (tInput && cInput) {
                                  handleUpdateOrderTracking(order.id, tInput.value, cInput.value);
                                }
                              }}
                              className="px-2.5 py-1 rounded bg-purple-600 text-white font-bold text-[10px]"
                            >
                              Save Tracking
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* EXISTING TABS PRESERVED (Services, Pricing, Portfolio, etc.) */}
        {/* ========================================================= */}
        {activeTab === 'services' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-[#17202A]">Manage Services</h1>
                <p className="text-xs text-[#66727D]">Activate, deactivate, or edit service offerings.</p>
              </div>
            </div>

            <div className="space-y-4">
              {services.map((service, index) => (
                <div key={service.id} className="bg-white p-6 rounded-2xl border border-[#E2E8EA] flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-[#1876C7]">#{index + 1}</span>
                      <h3 className="text-base font-bold text-[#17202A]">{service.title}</h3>
                    </div>
                    <p className="text-xs text-[#66727D]">{service.short_description}</p>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={async () => {
                        const updated = services.map(s => s.id === service.id ? { ...s, is_active: !s.is_active } : s);
                        setServices(updated);
                        await dataStore.saveServices(updated);
                        showNotification('Service status updated successfully.');
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 ${service.is_active ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-gray-100 text-gray-600 border border-gray-200'}`}
                    >
                      {service.is_active ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                      <span>{service.is_active ? 'Active' : 'Hidden'}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'pricing' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-[#17202A]">Manage Pricing Packages</h1>
                <p className="text-xs text-[#66727D]">Update package names, starting prices, and features.</p>
              </div>
            </div>

            <div className="space-y-4">
              {pricing.map((pkg) => (
                <div key={pkg.id} className="bg-white p-6 rounded-2xl border border-[#E2E8EA] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-[#17202A]">{pkg.package_name}</h3>
                      <span className="text-xs font-bold px-2 py-0.5 rounded bg-[#1876C7]/10 text-[#1876C7]">{pkg.starting_price}</span>
                    </div>
                    <p className="text-xs text-[#66727D]">{pkg.description}</p>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={async () => {
                        const updated = pricing.map(p => p.id === pkg.id ? { ...p, is_active: !p.is_active } : p);
                        setPricing(updated);
                        await dataStore.savePricing(updated);
                        showNotification('Pricing package status updated.');
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 ${pkg.is_active ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-gray-100 text-gray-600 border border-gray-200'}`}
                    >
                      {pkg.is_active ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                      <span>{pkg.is_active ? 'Active' : 'Hidden'}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'portfolio' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-[#17202A]">Manage Portfolio Projects</h1>
                <p className="text-xs text-[#66727D]">Add, edit, or toggle visibility of portfolio items.</p>
              </div>
            </div>

            <div className="space-y-4">
              {portfolio.map((proj) => (
                <div key={proj.id} className="bg-white p-6 rounded-2xl border border-[#E2E8EA] flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <img src={proj.image_url} alt="" className="w-16 h-12 object-cover rounded-lg border border-[#E2E8EA]" />
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-bold text-[#17202A]">{proj.project_name}</h3>
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-[#30E1CE]/20 text-[#17202A]">{proj.project_type}</span>
                      </div>
                      <p className="text-xs text-[#66727D]">{proj.category} • {proj.short_description}</p>
                    </div>
                  </div>

                  <button
                    onClick={async () => {
                      const updated = portfolio.map(p => p.id === proj.id ? { ...p, is_active: !p.is_active } : p);
                      setPortfolio(updated);
                      await dataStore.savePortfolio(updated);
                      showNotification('Portfolio item status updated.');
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 ${proj.is_active ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-gray-100 text-gray-600 border border-gray-200'}`}
                  >
                    {proj.is_active ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    <span>{proj.is_active ? 'Active' : 'Hidden'}</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'faqs' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-[#17202A]">Manage FAQs</h1>
                <p className="text-xs text-[#66727D]">Update answers or activate/deactivate questions.</p>
              </div>
            </div>

            <div className="space-y-4">
              {faqs.map((faq) => (
                <div key={faq.id} className="bg-white p-6 rounded-2xl border border-[#E2E8EA] flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-[#1876C7] uppercase">{faq.category}</span>
                    <h3 className="text-sm font-bold text-[#17202A]">{faq.question}</h3>
                    <p className="text-xs text-[#66727D]">{faq.answer}</p>
                  </div>

                  <button
                    onClick={async () => {
                      const updated = faqs.map(f => f.id === faq.id ? { ...f, is_active: !f.is_active } : f);
                      setFaqs(updated);
                      await dataStore.saveFaqs(updated);
                      showNotification('FAQ status updated.');
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 ${faq.is_active ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-gray-100 text-gray-600 border border-gray-200'}`}
                  >
                    {faq.is_active ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    <span>{faq.is_active ? 'Active' : 'Hidden'}</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'submissions' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-2xl font-bold text-[#17202A]">Contact Submissions</h1>
                <p className="text-xs text-[#66727D]">Review website enquiries, customer project requests, and generate AI replies.</p>
              </div>
              <span className="text-xs font-bold px-3 py-1 bg-gray-100 rounded-full text-gray-600 self-start sm:self-auto">
                Total Enquiries: {submissions.length}
              </span>
            </div>

            {submissions.length === 0 ? (
              <div className="bg-white p-12 rounded-3xl border border-[#E2E8EA] text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-blue-50 text-[#1876C7] flex items-center justify-center mx-auto mb-2">
                  <Mail className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-[#17202A]">No Enquiries Yet</h3>
                <p className="text-xs text-[#66727D] max-w-sm mx-auto">
                  New enquiries submitted through the Contact Form will automatically appear here.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {submissions.map((sub) => {
                  const goalsArr = Array.isArray(sub.goals) ? sub.goals : (sub.goals ? [sub.goals] : []);
                  const featuresArr = Array.isArray(sub.features_needed) ? sub.features_needed : (sub.features_needed ? [sub.features_needed] : []);

                  return (
                    <div key={sub.id} className="bg-white p-6 rounded-2xl border border-[#E2E8EA] shadow-xs space-y-4">
                      {/* Top Header */}
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-gray-100 pb-3">
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-bold text-[#17202A]">{sub.name}</span>
                            {sub.business_name && (
                              <span className="text-xs font-semibold text-gray-600 bg-gray-100 px-2 py-0.5 rounded">
                                {sub.business_name}
                              </span>
                            )}
                            {sub.enquiry_type && (
                              <span className="text-[11px] font-bold text-[#1876C7] bg-[#1876C7]/10 px-2.5 py-0.5 rounded-full border border-[#1876C7]/20">
                                {sub.enquiry_type}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-3 text-xs text-gray-500 mt-1 flex-wrap">
                            <span>Email: <strong className="text-gray-700">{sub.email}</strong></span>
                            {sub.whatsapp_phone && (
                              <span>WhatsApp: <strong className="text-gray-700">{sub.whatsapp_phone}</strong></span>
                            )}
                            <span className="text-gray-400">• {new Date(sub.created_at).toLocaleDateString()}</span>
                          </div>
                        </div>

                        {/* Status selector & Delete */}
                        <div className="flex items-center gap-2 shrink-0">
                          <select
                            value={sub.status}
                            onChange={async (e) => {
                              const newStatus = e.target.value as any;
                              await dataStore.updateSubmissionStatus(sub.id, newStatus);
                              setSubmissions(prev => prev.map(s => s.id === sub.id ? { ...s, status: newStatus } : s));
                              showNotification(`Status updated to ${newStatus}`);
                            }}
                            className="text-xs font-bold py-1 px-2.5 rounded-xl border border-gray-200 bg-gray-50 text-gray-700 focus:outline-none"
                          >
                            <option value="New">New</option>
                            <option value="Contacted">Contacted</option>
                            <option value="In Discussion">In Discussion</option>
                            <option value="Converted">Converted</option>
                            <option value="Closed">Closed</option>
                          </select>

                          <button
                            onClick={async () => {
                              if (window.confirm(`Delete enquiry from ${sub.name}?`)) {
                                await dataStore.deleteSubmission(sub.id);
                                setSubmissions(prev => prev.filter(s => s.id !== sub.id));
                                showNotification('Enquiry deleted');
                              }
                            }}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                            title="Delete enquiry"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Service / Details */}
                      {sub.service && (
                        <div className="text-xs">
                          <span className="text-gray-400 font-semibold uppercase text-[10px] block">Service Needed</span>
                          <span className="font-bold text-[#1876C7]">{sub.service}</span>
                          {sub.service_other_description && (
                            <span className="text-gray-600 block mt-0.5 italic">Note: {sub.service_other_description}</span>
                          )}
                        </div>
                      )}

                      {/* Project Description */}
                      {sub.project_description && (
                        <div className="text-xs bg-[#F8FAFA] p-3.5 rounded-xl border border-[#E2E8EA]">
                          <span className="text-gray-400 font-semibold uppercase text-[10px] block mb-1">Description / Message</span>
                          <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{sub.project_description}</p>
                        </div>
                      )}

                      {/* Badges for Goals & Features */}
                      {(goalsArr.length > 0 || featuresArr.length > 0) && (
                        <div className="space-y-2 pt-1">
                          {goalsArr.length > 0 && (
                            <div className="flex items-center gap-1.5 flex-wrap text-[11px]">
                              <span className="text-gray-400 font-bold text-[10px] uppercase mr-1">Goals:</span>
                              {goalsArr.map((g, idx) => (
                                <span key={idx} className="bg-purple-50 text-purple-700 border border-purple-100 px-2 py-0.5 rounded-md font-medium">
                                  {g}
                                </span>
                              ))}
                              {sub.goals_other && (
                                <span className="bg-purple-50 text-purple-700 border border-purple-100 px-2 py-0.5 rounded-md italic">
                                  Other: {sub.goals_other}
                                </span>
                              )}
                            </div>
                          )}

                          {featuresArr.length > 0 && (
                            <div className="flex items-center gap-1.5 flex-wrap text-[11px]">
                              <span className="text-gray-400 font-bold text-[10px] uppercase mr-1">Features:</span>
                              {featuresArr.map((f, idx) => (
                                <span key={idx} className="bg-emerald-50 text-emerald-700 border border-emerald-100 px-2 py-0.5 rounded-md font-medium">
                                  {f}
                                </span>
                              ))}
                              {sub.features_other && (
                                <span className="bg-emerald-50 text-emerald-700 border border-emerald-100 px-2 py-0.5 rounded-md italic">
                                  Other: {sub.features_other}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Website, Budget, Timeline Info Grid */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1 border-t border-gray-100">
                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-semibold">Existing Website</span>
                          <span className="font-bold text-gray-800">{sub.has_existing_website || 'Not specified'}</span>
                          {sub.existing_website_url && (
                            <a
                              href={sub.existing_website_url.startsWith('http') ? sub.existing_website_url : `https://${sub.existing_website_url}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[#1876C7] underline block truncate text-[11px] mt-0.5"
                            >
                              {sub.existing_website_url}
                            </a>
                          )}
                        </div>

                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-semibold">Estimated Budget</span>
                          <span className="font-bold text-gray-800">
                            {sub.custom_budget || sub.budget || 'Not specified'}
                          </span>
                        </div>

                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-semibold">Preferred Timeline</span>
                          <span className="font-bold text-gray-800">
                            {sub.timeline_other || sub.timeline || 'Flexible'}
                          </span>
                        </div>

                        <div>
                          <span className="text-gray-400 block text-[10px] uppercase font-semibold">Direct Action</span>
                          <div className="flex items-center gap-2 mt-1">
                            {sub.whatsapp_phone && (
                              <a
                                href={`https://wa.me/${sub.whatsapp_phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hi ${sub.name}, thank you for contacting Janah Studio regarding ${sub.service || sub.enquiry_type}...`)}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-emerald-600 hover:text-emerald-700 font-bold text-[11px] flex items-center gap-1"
                              >
                                <MessageCircle className="w-3.5 h-3.5" /> Chat
                              </a>
                            )}
                            <a
                              href={`mailto:${sub.email}?subject=${encodeURIComponent(`Janah Studio Enquiry: ${sub.service || sub.enquiry_type}`)}`}
                              className="text-[#1876C7] hover:underline font-bold text-[11px] flex items-center gap-1"
                            >
                              <Mail className="w-3.5 h-3.5" /> Email
                            </a>
                          </div>
                        </div>
                      </div>

                      {/* Additional Information */}
                      {sub.additional_info && (
                        <div className="text-xs text-gray-600 bg-amber-50/50 p-2.5 rounded-lg border border-amber-100">
                          <span className="font-bold text-amber-900 block text-[10px] uppercase">Additional Notes:</span>
                          <p className="mt-0.5">{sub.additional_info}</p>
                        </div>
                      )}

                      {/* AI Reply Buttons */}
                      <div className="flex items-center gap-2 pt-2 border-t border-gray-100">
                        <button
                          disabled={!!generatingReplyId}
                          onClick={() => handleGenerateDraft(sub, 'whatsapp')}
                          className="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 text-xs font-bold flex items-center gap-1 hover:bg-emerald-100 transition-colors"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>{generatingReplyId === `${sub.id}-whatsapp` ? 'Drafting...' : 'AI WhatsApp Draft'}</span>
                        </button>
                        <button
                          disabled={!!generatingReplyId}
                          onClick={() => handleGenerateDraft(sub, 'email')}
                          className="px-3 py-1.5 rounded-lg bg-sky-50 text-[#1876C7] text-xs font-bold flex items-center gap-1 hover:bg-sky-100 transition-colors"
                        >
                          <Mail className="w-3.5 h-3.5" />
                          <span>{generatingReplyId === `${sub.id}-email` ? 'Drafting...' : 'AI Email Draft'}</span>
                        </button>
                      </div>

                      {draftReplies[sub.id] && (
                        <div className="p-3 bg-gray-50 rounded-xl border text-xs text-gray-700 font-mono whitespace-pre-wrap">
                          {draftReplies[sub.id].content}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {activeTab === 'careers' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-[#17202A] flex items-center gap-2">
                  <FileSpreadsheet className="w-6 h-6 text-emerald-600" />
                  <span>Careers & Google Sheets Gateway</span>
                </h1>
                <p className="text-xs text-[#66727D]">
                  Manage candidate applications and configure direct Google Sheets synchronization.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <Link
                  to="/careers"
                  target="_blank"
                  className="px-4 py-2 rounded-xl border border-[#E2E8EA] bg-white text-xs font-semibold text-[#1876C7] hover:bg-gray-50 flex items-center gap-1.5 transition-all shadow-xs"
                >
                  <span>View Public Form</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>

            {/* Google Sheets Integration Status & Setup Card */}
            <div className={`p-6 rounded-2xl border transition-all ${
              sheetsConfig.isConnected 
                ? 'bg-gradient-to-br from-emerald-50/60 to-white border-emerald-200' 
                : 'bg-gradient-to-br from-amber-50/70 to-white border-amber-200'
            }`}>
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="flex items-start gap-3.5">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    sheetsConfig.isConnected ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {sheetsConfig.isConnected ? <CheckCircle2 className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-[#17202A]">
                        {sheetsConfig.isConnected ? 'Google Sheets Sync Active' : 'Google Sheets Connection Required'}
                      </h3>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        sheetsConfig.isConnected ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'
                      }`}>
                        {sheetsConfig.isConnected ? 'LIVE SYNC' : 'OFFLINE QUEUE'}
                      </span>
                    </div>

                    <p className="text-xs text-[#66727D] mt-1">
                      {sheetsConfig.isConnected ? (
                        <>Connected to Google Account: <strong>{sheetsConfig.userEmail}</strong> • Synchronized to <strong>{sheetsConfig.spreadsheetTitle || 'Janah Studio - Careers Applications'}</strong></>
                      ) : (
                        <>Applications are currently stored safely in local database queue. Connect your Google account to auto-sync submissions to your Google Spreadsheet.</>
                      )}
                    </p>
                  </div>
                </div>

                {/* Status Actions */}
                <div className="flex flex-wrap items-center gap-2">
                  {sheetsConfig.isConnected ? (
                    <>
                      {sheetsConfig.spreadsheetUrl && (
                        <a
                          href={sheetsConfig.spreadsheetUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3.5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 transition-colors flex items-center gap-1.5 shadow-xs"
                        >
                          <FileSpreadsheet className="w-3.5 h-3.5" />
                          <span>Open Google Sheet</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}

                      <button
                        onClick={handleSyncPendingApplications}
                        disabled={isSyncingPending}
                        className="px-3.5 py-2 rounded-xl border border-[#E2E8EA] bg-white text-xs font-semibold text-[#17202A] hover:bg-gray-50 transition-colors flex items-center gap-1.5 disabled:opacity-50"
                      >
                        <RotateCw className={`w-3.5 h-3.5 ${isSyncingPending ? 'animate-spin' : ''}`} />
                        <span>Sync Pending ({applications.filter(a => !a.saved_to_google_sheets).length})</span>
                      </button>

                      <button
                        onClick={handleDisconnectGoogleSheets}
                        className="px-3 py-2 rounded-xl border border-red-200 text-red-600 text-xs font-semibold hover:bg-red-50 transition-colors"
                      >
                        Disconnect
                      </button>
                    </>
                  ) : (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleConnectGoogleSheets(true)}
                        disabled={isConnectingSheets}
                        className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-[#1876C7] text-white text-xs font-bold hover:opacity-95 transition-all flex items-center gap-2 shadow-sm disabled:opacity-50"
                      >
                        {isConnectingSheets ? (
                          <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <FileSpreadsheet className="w-4 h-4" />
                        )}
                        <span>Connect Google Account & Auto-Create Sheet</span>
                      </button>

                      <button
                        onClick={() => setShowSheetSetupGuide(!showSheetSetupGuide)}
                        className="px-3 py-2 rounded-xl border border-[#E2E8EA] bg-white text-xs font-semibold text-[#66727D] hover:text-[#17202A]"
                      >
                        Setup Details
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Collapsible Setup Guide (Required if Google API unavailable or manual config needed) */}
              {(!sheetsConfig.isConnected || showSheetSetupGuide) && (
                <div className="mt-5 pt-4 border-t border-amber-200/60 space-y-3 text-xs text-[#17202A]">
                  <h4 className="font-bold text-[#17202A] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                    <span>How Google Sheets Integration Works (Setup Guide):</span>
                  </h4>
                  <ol className="list-decimal pl-5 space-y-1.5 text-[#66727D]">
                    <li>
                      <strong>Google Authorization:</strong> Click <em>"Connect Google Account"</em> to authorize Janah Studio with the Google Sheets scope (<code>https://www.googleapis.com/auth/spreadsheets</code>).
                    </li>
                    <li>
                      <strong>Automatic Header Formatting:</strong> The system automatically creates a sheet named <em>"Janah Studio - Careers Applications"</em> and pre-fills all 22 required columns (Candidate Name, Role, Skills, Portfolio, Bank/Payment details, Cover letter).
                    </li>
                    <li>
                      <strong>Zero Frontend Token Exposure:</strong> All write requests are secured through the server endpoint <code>/api/careers/apply</code>, ensuring tokens and keys are never leaked to public visitors.
                    </li>
                  </ol>

                  <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 max-w-xl">
                    <input
                      type="text"
                      value={customSheetIdInput}
                      onChange={e => setCustomSheetIdInput(e.target.value)}
                      placeholder="Existing Google Spreadsheet ID or URL (Optional)"
                      className="flex-1 px-3.5 py-2 rounded-xl border border-[#E2E8EA] bg-white text-xs focus:outline-none focus:ring-2 focus:ring-[#1876C7]/20"
                    />
                    <button
                      onClick={() => handleConnectGoogleSheets(false)}
                      disabled={isConnectingSheets || !customSheetIdInput.trim()}
                      className="px-4 py-2 rounded-xl bg-[#1876C7] text-white text-xs font-semibold hover:bg-[#0F5A9B] transition-colors disabled:opacity-50"
                    >
                      Connect Existing Sheet
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Applications List */}
            <div className="bg-white rounded-2xl border border-[#E2E8EA] overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-[#E2E8EA] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-base font-bold text-[#17202A]">
                    Submitted Candidate Applications ({applications.length})
                  </h2>
                  <p className="text-xs text-[#66727D]">
                    Click on any applicant to view full portfolio, bank account info, and recruitment notes.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">Total Synced:</span>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                    {applications.filter(a => a.saved_to_google_sheets).length} / {applications.length} to Sheets
                  </span>
                </div>
              </div>

              {applications.length === 0 ? (
                <div className="p-12 text-center text-gray-500 text-xs">
                  <Briefcase className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                  <p>No job applications received yet.</p>
                  <p className="text-gray-400 mt-1">Applications submitted on the /careers page will appear here instantly.</p>
                </div>
              ) : (
                <div className="divide-y divide-[#E2E8EA]">
                  {applications.map((app) => (
                    <div key={app.id} className="p-4 sm:p-6 hover:bg-[#F8FAFA] transition-colors space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-mono text-xs font-bold text-[#1876C7]">
                              {app.reference_id}
                            </span>
                            <h3 className="text-sm font-bold text-[#17202A]">
                              {app.full_name}
                            </h3>
                            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                              {app.position}
                            </span>
                            {app.saved_to_google_sheets ? (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                                <Check className="w-3 h-3" />
                                <span>Saved in Sheets</span>
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                                Queued Locally
                              </span>
                            )}
                          </div>

                          <p className="text-xs text-[#66727D] flex flex-wrap items-center gap-2 pt-0.5">
                            <span>{app.email}</span>
                            <span>•</span>
                            <span>{app.phone}</span>
                            <span>•</span>
                            <span>{app.location}</span>
                            <span>•</span>
                            <span>{app.experience_level} ({app.years_experience} yrs)</span>
                          </p>
                        </div>

                        {/* Status Select & Quick Actions */}
                        <div className="flex items-center gap-2">
                          <select
                            value={app.status}
                            onChange={(e) => handleUpdateApplicationStatus(app.id, e.target.value as any)}
                            className="px-2.5 py-1.5 rounded-xl border border-[#E2E8EA] bg-white text-xs font-semibold text-[#17202A] focus:outline-none focus:ring-1 focus:ring-[#1876C7]"
                          >
                            <option value="Pending">Pending</option>
                            <option value="Reviewing">Reviewing</option>
                            <option value="Shortlisted">Shortlisted</option>
                            <option value="Interviewed">Interviewed</option>
                            <option value="Hired">Hired</option>
                            <option value="Rejected">Rejected</option>
                          </select>

                          <button
                            onClick={() => setSelectedApplication(app)}
                            className="px-3 py-1.5 rounded-xl border border-[#E2E8EA] bg-white text-xs font-medium text-[#17202A] hover:bg-gray-100 transition-colors"
                          >
                            View Details
                          </button>
                        </div>
                      </div>

                      {/* Skills & Payment Service Info Badge */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-gray-100 text-xs">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-[11px] text-gray-500 font-medium">Skills:</span>
                          {(app.skills || []).map((s) => (
                            <span key={s} className="text-[10px] px-2 py-0.5 rounded bg-gray-100 text-gray-700">
                              {s}
                            </span>
                          ))}
                        </div>

                        <div className="flex items-center gap-3 text-[11px] text-[#66727D]">
                          {app.bank_name ? <span>Payment / Bank: <strong className="text-[#17202A]">{app.bank_name}</strong></span> : null}
                          {app.expected_rate ? <span>Rate: <strong className="text-[#17202A]">{app.expected_rate}</strong></span> : null}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Application Detail Modal */}
            {selectedApplication && (
              <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
                <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto">
                  <div className="flex items-center justify-between border-b border-[#E2E8EA] pb-3">
                    <div>
                      <span className="font-mono text-xs font-bold text-[#1876C7]">
                        {selectedApplication.reference_id}
                      </span>
                      <h2 className="text-xl font-bold text-[#17202A]">
                        {selectedApplication.full_name}
                      </h2>
                      <span className="text-xs text-[#66727D]">
                        Applied for {selectedApplication.position}
                      </span>
                    </div>

                    <button
                      onClick={() => setSelectedApplication(null)}
                      className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Detail Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div className="p-3 rounded-xl bg-[#F8FAFA] border border-[#E2E8EA]">
                      <span className="text-gray-500 block mb-0.5">Email</span>
                      <strong className="text-[#17202A]">{selectedApplication.email}</strong>
                    </div>

                    <div className="p-3 rounded-xl bg-[#F8FAFA] border border-[#E2E8EA]">
                      <span className="text-gray-500 block mb-0.5">WhatsApp / Phone</span>
                      <strong className="text-[#17202A]">{selectedApplication.phone}</strong>
                    </div>

                    <div className="p-3 rounded-xl bg-[#F8FAFA] border border-[#E2E8EA]">
                      <span className="text-gray-500 block mb-0.5">Location</span>
                      <strong className="text-[#17202A]">{selectedApplication.location}</strong>
                    </div>

                    <div className="p-3 rounded-xl bg-[#F8FAFA] border border-[#E2E8EA]">
                      <span className="text-gray-500 block mb-0.5">Experience & Years</span>
                      <strong className="text-[#17202A]">{selectedApplication.experience_level} ({selectedApplication.years_experience} yrs)</strong>
                    </div>

                    <div className="p-3 rounded-xl bg-[#F8FAFA] border border-[#E2E8EA]">
                      <span className="text-gray-500 block mb-0.5">Portfolio URL</span>
                      <a 
                        href={selectedApplication.portfolio_url} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="text-[#1876C7] font-semibold hover:underline flex items-center gap-1"
                      >
                        <Globe className="w-3.5 h-3.5" />
                        <span className="truncate">{selectedApplication.portfolio_url}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    </div>

                    <div className="p-3 rounded-xl bg-[#F8FAFA] border border-[#E2E8EA]">
                      <span className="text-gray-500 block mb-0.5">GitHub / Profiles</span>
                      <a 
                        href={selectedApplication.github_url} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="text-[#1876C7] font-semibold hover:underline flex items-center gap-1"
                      >
                        <Github className="w-3.5 h-3.5" />
                        <span className="truncate">{selectedApplication.github_url}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    </div>

                    {selectedApplication.linkedin_url && (
                      <div className="p-3 rounded-xl bg-[#F8FAFA] border border-[#E2E8EA]">
                        <span className="text-gray-500 block mb-0.5">LinkedIn</span>
                        <a 
                          href={selectedApplication.linkedin_url} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-[#1876C7] font-semibold hover:underline flex items-center gap-1"
                        >
                          <span className="truncate">{selectedApplication.linkedin_url}</span>
                          <ExternalLink className="w-3 h-3 shrink-0" />
                        </a>
                      </div>
                    )}

                    <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                      <span className="text-emerald-800 font-semibold block mb-0.5">Payment / Bank Details</span>
                      <p className="text-[#17202A]"><strong>Bank:</strong> {selectedApplication.bank_name}</p>
                      <p className="text-[#17202A]"><strong>Title:</strong> {selectedApplication.account_holder_name}</p>
                      <p className="font-mono text-emerald-900 font-bold mt-0.5">{selectedApplication.account_number}</p>
                    </div>
                  </div>

                  {/* Cover Letter Box */}
                  <div>
                    <h4 className="text-xs font-bold text-[#17202A] mb-1.5">Standout Project & Cover Message:</h4>
                    <div className="p-4 rounded-xl bg-gray-50 border border-gray-200 text-xs text-[#17202A] leading-relaxed whitespace-pre-wrap">
                      {selectedApplication.cover_letter}
                    </div>
                  </div>

                  {/* Modal Footer */}
                  <div className="pt-2 border-t border-[#E2E8EA] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <a
                        href={`https://wa.me/${selectedApplication.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hi ${selectedApplication.full_name}, regarding your application at Janah Studio for ${selectedApplication.position}...`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3.5 py-2 rounded-xl bg-[#25D366] text-white text-xs font-bold hover:brightness-105 flex items-center gap-1.5"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>WhatsApp Candidate</span>
                      </a>
                      <a
                        href={`mailto:${selectedApplication.email}?subject=${encodeURIComponent(`Janah Studio Application: ${selectedApplication.position}`)}`}
                        className="px-3.5 py-2 rounded-xl bg-[#1876C7] text-white text-xs font-bold hover:bg-[#0F5A9B] flex items-center gap-1.5"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>Email Candidate</span>
                      </a>
                    </div>

                    <button
                      onClick={() => setSelectedApplication(null)}
                      className="px-4 py-2 rounded-xl border border-[#E2E8EA] text-xs font-medium text-gray-600 hover:bg-gray-100"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

        {activeTab === 'notifications' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-[#17202A]">Email Notifications</h1>
              <p className="text-xs text-[#66727D]">Configure automated notifications on new project enquiries.</p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-[#E2E8EA] space-y-4 max-w-xl">
              <label className="flex items-center gap-3 cursor-pointer">
                <input 
                  type="checkbox"
                  checked={notifPrefs.email_on_new_submission}
                  onChange={(e) => {
                    const updated = { ...notifPrefs, email_on_new_submission: e.target.checked };
                    setNotifPrefs(updated);
                    emailService.savePreferences(updated);
                    showNotification('Notification preferences saved.');
                  }}
                  className="rounded text-[#1876C7]"
                />
                <span className="text-xs font-bold text-[#17202A]">Send Email Notification on New Submission</span>
              </label>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold text-[#17202A]">Site Settings</h1>
              <p className="text-xs text-[#66727D]">Configure global business name, email, WhatsApp, and CTAs.</p>
            </div>

            <div className="bg-white p-8 rounded-2xl border border-[#E2E8EA] space-y-6 max-w-2xl">
              <div className="space-y-2">
                <label className="text-xs font-bold text-[#17202A]">Business Name</label>
                <input
                  type="text"
                  value={settings.business_name}
                  onChange={(e) => setSettings({ ...settings, business_name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-[#E2E8EA] text-sm text-[#17202A]"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-[#17202A]">Contact Email</label>
                <input
                  type="email"
                  value={settings.contact_email}
                  onChange={(e) => setSettings({ ...settings, contact_email: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-[#E2E8EA] text-sm text-[#17202A]"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-[#17202A]">WhatsApp Number</label>
                <input
                  type="text"
                  value={settings.whatsapp_number}
                  onChange={(e) => setSettings({ ...settings, whatsapp_number: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-[#E2E8EA] text-sm text-[#17202A]"
                />
              </div>

              <button
                onClick={async () => {
                  await dataStore.saveSettings(settings);
                  showNotification('Site settings saved successfully.');
                }}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#30E1CE] to-[#1876C7] text-white font-bold text-xs shadow-md"
              >
                Save Changes
              </button>
            </div>
          </div>
        )}

      </main>

    </div>
  );
}
